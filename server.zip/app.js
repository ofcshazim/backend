import express from "express";
import cors from "cors";
import path from "path";
import { env } from "./config/env.js";
import apiRoutes from "./routes/index.js";
import { getHealthLiveness } from "./controllers/health.controller.js";
import { securityMiddleware } from "./middleware/security.js";
import { httpsRedirectMiddleware } from "./middleware/https-redirect.js";
import { requestIdMiddleware } from "./middleware/request-id.js";
import { ipBanMiddleware } from "./middleware/ip-ban.js";
import { antiBotMiddleware } from "./middleware/anti-bot.js";
import { requestLogger } from "./middleware/request-logger.js";
import { apiRateLimit } from "./middleware/rate-limit.js";
import { notFoundHandler, errorHandler } from "./middleware/error-handler.js";

const corsOptions = {
  origin: (origin, callback) => {
    if (!origin) return callback(null, true);
    if (env.corsOrigins.includes(origin)) return callback(null, true);
    if (env.nodeEnv === "development") return callback(null, true);
    if (/checkinproperty\.pk/i.test(origin)) return callback(null, true);
    if (/^https?:\/\/93\.115\.101\.102(:\d+)?$/.test(origin)) return callback(null, true);
    if (process.env.CORS_ALLOW_ALL === "true") return callback(null, true);
    callback(new Error(`Not allowed by CORS: ${origin}`));
  },
  methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
  allowedHeaders: ["Content-Type", "X-Session-Id", "x-session-id", "X-Request-Id", "Authorization"],
  exposedHeaders: ["X-Request-Id", "X-Session-Id", "x-session-id"],
  optionsSuccessStatus: 204,
};

export const createApp = () => {
  const app = express();

  app.set("trust proxy", 1);
  app.disable("x-powered-by");

  app.use(cors(corsOptions));

  // Liveness — before rate limits, IP ban, and integration-heavy middleware
  app.get("/api/health", getHealthLiveness);

  app.use(httpsRedirectMiddleware);
  app.use(requestIdMiddleware);
  app.use(ipBanMiddleware);
  app.use(securityMiddleware);
  app.use(requestLogger);
  app.use(antiBotMiddleware);

  app.use(express.json({ limit: "2mb" }));
  app.use("/uploads", express.static(path.join(process.cwd(), "uploads")));
  app.use("/api", apiRateLimit, apiRoutes);

  app.get("/", (_req, res) => {
    res.json({
      name: "Check In Property API",
      version: "3.0.0",
      docs: "/api/health",
      contact: "POST /api/contact",
      admin: "POST /api/admin/login",
    });
  });

  app.use(notFoundHandler);
  app.use(errorHandler);

  return app;
};
