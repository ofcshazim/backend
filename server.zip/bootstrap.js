import { initDatabase, closeDatabase, getStorePath } from "./db/database.js";
import { seedDatabase } from "./db/seed.js";
import { verifySmtpConnection } from "./utils/mail-transport.js";
import { verifyWapiConnection } from "./services/whatsappService.js";
import { startWhatsAppScheduler, stopWhatsAppScheduler } from "./services/whatsapp-scheduler.service.js";
import { validateStartup } from "./utils/startupValidator.js";
import { startDailyBackupSchedule } from "./services/backup.service.js";
import { logger } from "./utils/logger.js";
import { flushQueue } from "./db/write-queue.js";

let backupTimer = null;

/** Fast path — DB + validation only; must complete before accepting traffic */
export const bootstrapCore = () => {
  logger.info("[BOOT] Core bootstrap…", { node: process.version });

  validateStartup();

  initDatabase();
  seedDatabase();
  logger.info("[BOOT] Database ready");

  const storePath = getStorePath();
  backupTimer = startDailyBackupSchedule(storePath);

  logger.info("[BOOT] Routes ready — /api/health, /api/admin, /api/contact");
};

/** SMTP / WhatsApp — runs after listen so /api/health is never blocked */
export const bootstrapIntegrations = async () => {
  const smtpOk = await verifySmtpConnection();
  if (!smtpOk) {
    logger.warn("[BOOT] SMTP not ready — contact emails may fail until SMTP is fixed");
  }

  const wapiOk = await verifyWapiConnection();
  if (!wapiOk) {
    logger.warn("[BOOT] Authkey WhatsApp not ready — messages will queue until configured");
  }

  startWhatsAppScheduler();

  return { smtpOk, wapiOk };
};

export const bootstrap = async () => {
  bootstrapCore();
  return bootstrapIntegrations();
};

export const shutdown = async () => {
  if (backupTimer) clearInterval(backupTimer);
  stopWhatsAppScheduler();
  await flushQueue();
  await closeDatabase();
};
