import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: path.join(__dirname, "..", ".env") });

const num = (value, fallback) => {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
};

const bool = (value, fallback = false) => {
  if (value === undefined || value === "") return fallback;
  return value === "true" || value === "1";
};

const list = (value, fallback = []) =>
  value ? value.split(",").map((s) => s.trim()).filter(Boolean) : fallback;

export const env = {
  nodeEnv: process.env.NODE_ENV || "development",
  host: process.env.HOST || "0.0.0.0",
  port: num(process.env.PORT, 12176),
  frontendUrl: process.env.FRONTEND_URL || "https://checkinproperty.pk",
  corsOrigins: list(process.env.CORS_ORIGIN, [
    "https://checkinproperty.pk",
    "https://www.checkinproperty.pk",
    "http://93.115.101.102",
    "http://93.115.101.102:8080",
  ]),
  rateLimitWindowMs: num(process.env.RATE_LIMIT_WINDOW_MS, 15 * 60 * 1000),
  rateLimitMax: num(process.env.RATE_LIMIT_MAX, 10),
  siteName: process.env.SITE_NAME || "Check In Property",
  siteUrl: process.env.SITE_URL || "https://checkinproperty.pk",
  companyPhone: process.env.COMPANY_PHONE || "+923137255556",
  companyEmail: process.env.COMPANY_EMAIL || "info@checkinproperty.pk",
  companyAddress: process.env.COMPANY_ADDRESS || "F-11 Markaz, Islamabad, Pakistan",
  logoUrl:
    process.env.COMPANY_LOGO_URL ||
    `${process.env.SITE_URL || "https://checkinproperty.pk"}/favicon.ico`,
  internalCopyEmail: process.env.INTERNAL_COPY_EMAIL || process.env.COMPANY_EMAIL || "info@checkinproperty.pk",
  dbPath: process.env.DATABASE_PATH || path.join(__dirname, "..", "data", "app.db"),
  admin: {
    email: process.env.ADMIN_EMAIL || "admin@checkinproperty.pk",
    password: process.env.ADMIN_PASSWORD || "ChangeMe123!",
    name: process.env.ADMIN_NAME || "Administrator",
  },
  smtp: {
    host: process.env.SMTP_HOST || "",
    port: num(process.env.SMTP_PORT, 587),
    secure: (() => {
      const port = num(process.env.SMTP_PORT, 587);
      if (process.env.SMTP_SECURE !== undefined && process.env.SMTP_SECURE !== "") {
        return bool(process.env.SMTP_SECURE, false);
      }
      return port === 465;
    })(),
    user: process.env.SMTP_USER || "",
    pass: process.env.SMTP_PASS || "",
    from: process.env.SMTP_FROM || process.env.SMTP_USER || "",
    connectionTimeout: num(process.env.SMTP_CONNECTION_TIMEOUT, 20000),
    greetingTimeout: num(process.env.SMTP_GREETING_TIMEOUT, 20000),
    socketTimeout: num(process.env.SMTP_SOCKET_TIMEOUT, 30000),
    tlsRejectUnauthorized: bool(process.env.SMTP_TLS_REJECT_UNAUTHORIZED, true),
  },
  contactReceiver: process.env.CONTACT_RECEIVER || "",
  sendAutoReplyEmail: bool(process.env.SEND_AUTO_REPLY_EMAIL, true),
  wapiEnabled: bool(process.env.WAPI_ENABLED, true),
  whatsapp: {
    provider: (() => {
      if (process.env.WAPI_ENABLED === "false") return "none";
      return (process.env.WHATSAPP_PROVIDER || "wapi").toLowerCase();
    })(),
    adminPhones: list(process.env.WHATSAPP_ADMIN_PHONES),
    sendCustomerAutoReply: bool(process.env.WHATSAPP_SEND_AUTO_REPLY, false),
    wapi: {
      apiKey: process.env.WAPI_API_KEY || "",
      instanceId: process.env.WAPI_INSTANCE_ID || "",
      phoneNumber: process.env.WAPI_PHONE_NUMBER || "",
      baseUrl: (process.env.WAPI_URL || "https://waapi.app/api").replace(/\/$/, ""),
    },
    cloudToken: process.env.WHATSAPP_CLOUD_TOKEN || "",
    cloudPhoneId: process.env.WHATSAPP_CLOUD_PHONE_ID || "",
    twilioSid: process.env.TWILIO_ACCOUNT_SID || "",
    twilioToken: process.env.TWILIO_AUTH_TOKEN || "",
    twilioFrom: process.env.TWILIO_WHATSAPP_FROM || "",
    ultramsgInstance: process.env.ULTRAMSG_INSTANCE_ID || "",
    ultramsgToken: process.env.ULTRAMSG_TOKEN || "",
  },
};

export const isSmtpConfigured = () =>
  Boolean(env.smtp.host && env.smtp.user && env.smtp.pass && env.contactReceiver && env.smtp.from);

export const isWapiConfigured = () =>
  Boolean(env.whatsapp.wapi.apiKey && env.whatsapp.wapi.instanceId);

export const isWhatsAppConfigured = () => {
  const p = env.whatsapp.provider;
  if (p === "wapi") return isWapiConfigured();
  if (p === "cloud-api") return Boolean(env.whatsapp.cloudToken && env.whatsapp.cloudPhoneId);
  if (p === "twilio") return Boolean(env.whatsapp.twilioSid && env.whatsapp.twilioToken && env.whatsapp.twilioFrom);
  if (p === "ultramsg") return Boolean(env.whatsapp.ultramsgInstance && env.whatsapp.ultramsgToken);
  return p !== "none" && p !== "";
};

export const getApiBaseUrl = (req) => {
  if (process.env.API_PUBLIC_URL) {
    const url = process.env.API_PUBLIC_URL.replace(/\/$/, "");
    return url.endsWith("/api") ? url : `${url}/api`;
  }
  const protocol = req?.protocol || "http";
  return process.env.API_PUBLIC_URL?.replace(/\/$/, "") || `http://93.115.101.102:${env.port}/api`;
};
