import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: path.join(__dirname, "..", ".env") });

const num = (value, fallback) => {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
};

const bool = (value, fallback = false) => {
  if (value === undefined || value === "") return fallback;
  return value === "true" || value === "1";
};

const list = (value, fallback = []) =>
  value ? value.split(",").map((s) => s.trim()).filter(Boolean) : fallback;

export const env = {
  nodeEnv: process.env.NODE_ENV || "development",
  host: process.env.HOST || "0.0.0.0",
  port: num(process.env.PORT || process.env.BACKEND_PORT, 12176),
  apiPublicUrl:
    process.env.API_PUBLIC_URL ||
    process.env.API_BASE_URL?.replace(/\/api\/?$/, "") ||
    "http://13.63.14.162:12176",
  frontendUrl: process.env.FRONTEND_URL || "https://checkinproperty.pk",
  corsOrigins: list(process.env.CORS_ORIGIN, [
    "https://checkinproperty.pk",
    "https://www.checkinproperty.pk",
    "http://13.63.14.162",
    "http://13.63.14.162:8080",
  ]),
  rateLimitWindowMs: num(process.env.RATE_LIMIT_WINDOW_MS, 15 * 60 * 1000),
  rateLimitMax: num(process.env.RATE_LIMIT_MAX, 10),
  siteName: process.env.SITE_NAME || "Check In Property",
  siteUrl: process.env.SITE_URL || "https://checkinproperty.pk",
  companyPhone: process.env.COMPANY_PHONE || "+923137255556",
  companyEmail: process.env.COMPANY_EMAIL || "info@checkinproperty.pk",
  companyAddress: process.env.COMPANY_ADDRESS || "F-11 Markaz, Islamabad, Pakistan",
  logoUrl:
    process.env.COMPANY_LOGO_URL ||
    `${process.env.SITE_URL || "https://checkinproperty.pk"}/favicon.ico`,
  internalCopyEmail: process.env.INTERNAL_COPY_EMAIL || process.env.COMPANY_EMAIL || "info@checkinproperty.pk",
  dbPath: process.env.DATABASE_PATH || path.join(__dirname, "..", "data", "app.db"),
  admin: {
    email: process.env.ADMIN_EMAIL || "admin@checkinproperty.pk",
    password: process.env.ADMIN_PASSWORD || "ChangeMe123!",
    name: process.env.ADMIN_NAME || "Administrator",
  },
  smtp: {
    host: process.env.SMTP_HOST || "",
    port: num(process.env.SMTP_PORT, 587),
    secure: (() => {
      const port = num(process.env.SMTP_PORT, 587);
      if (process.env.SMTP_SECURE !== undefined && process.env.SMTP_SECURE !== "") {
        return bool(process.env.SMTP_SECURE, false);
      }
      return port === 465;
    })(),
    user: process.env.SMTP_USER || "",
    pass: process.env.SMTP_PASS || "",
    from: process.env.SMTP_FROM || process.env.SMTP_USER || "",
    connectionTimeout: num(process.env.SMTP_CONNECTION_TIMEOUT, 20000),
    greetingTimeout: num(process.env.SMTP_GREETING_TIMEOUT, 20000),
    socketTimeout: num(process.env.SMTP_SOCKET_TIMEOUT, 30000),
    tlsRejectUnauthorized: bool(process.env.SMTP_TLS_REJECT_UNAUTHORIZED, true),
  },
  contactReceiver: process.env.CONTACT_RECEIVER || "",
  sendAutoReplyEmail: bool(process.env.SEND_AUTO_REPLY_EMAIL, true),
  authkey: {
    enabled: bool(process.env.WHATSAPP_ENABLED ?? process.env.AUTHKEY_ENABLED, true),
    authKey: process.env.AUTHKEY_AUTH_KEY || "",
    baseUrl: (process.env.AUTHKEY_BASE_URL || "https://console.authkey.io/restapi").replace(/\/$/, ""),
    apiUrl: process.env.AUTHKEY_API_URL || "https://console.authkey.io/restapi/requestjson.php",
    bulkApiUrl: process.env.AUTHKEY_BULK_API_URL || "https://console.authkey.io/restapi/requestjson_v2.0.php",
    balanceUrl: process.env.AUTHKEY_BALANCE_URL || "https://console.authkey.io/restapi/getbalance.php",
    lowBalanceThreshold: num(process.env.AUTHKEY_LOW_BALANCE_THRESHOLD, 50),
  },
  whatsapp: {
    provider: "authkey",
    adminPhones: list(process.env.WHATSAPP_ADMIN_PHONES),
    sendCustomerAutoReply: bool(process.env.WHATSAPP_SEND_AUTO_REPLY, false),
    defaultCountryCode: process.env.WHATSAPP_DEFAULT_COUNTRY || "92",
    defaultTextWid: process.env.AUTHKEY_DEFAULT_TEXT_WID || "",
    defaultMediaWid: process.env.AUTHKEY_DEFAULT_MEDIA_WID || "",
  },
};

export const isSmtpConfigured = () =>
  Boolean(env.smtp.host && env.smtp.user && env.smtp.pass && env.contactReceiver && env.smtp.from);

export const isAuthkeyConfigured = () => Boolean(env.authkey.authKey);

export const isWhatsAppConfigured = () => env.authkey.enabled && isAuthkeyConfigured();

export const getApiBaseUrl = () => {
  const url = process.env.API_PUBLIC_URL || process.env.API_BASE_URL || `http://13.63.14.162:${env.port}/api`;
  const normalized = url.replace(/\/$/, "");
  return normalized.endsWith("/api") ? normalized : `${normalized}/api`;
};
