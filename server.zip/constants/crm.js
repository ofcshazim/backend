export const CRM_STATUSES = [
  "new",
  "contacted",
  "interested",
  "site_visit",
  "negotiation",
  "converted",
  "closed",
  "lost",
];

export const LEAD_SOURCES = [
  "website",
  "whatsapp",
  "facebook",
  "instagram",
  "organic",
  "referral",
  "walk_in",
  "other",
];

export const LEAD_PRIORITIES = ["low", "medium", "high", "urgent"];

export const PIPELINE_STAGES = [
  { key: "new", label: "New", color: "#3b82f6" },
  { key: "contacted", label: "Contacted", color: "#8b5cf6" },
  { key: "interested", label: "Interested", color: "#06b6d4" },
  { key: "site_visit", label: "Site Visit", color: "#f59e0b" },
  { key: "negotiation", label: "Negotiation", color: "#f97316" },
  { key: "converted", label: "Converted", color: "#22c55e" },
  { key: "closed", label: "Closed", color: "#64748b" },
  { key: "lost", label: "Lost", color: "#ef4444" },
];

export const normalizeLead = (row) => ({
  id: row.id,
  name: row.name || "",
  phone: row.phone || "",
  email: row.email || "",
  message: row.message || "",
  project: row.project || "",
  budget: row.budget || "",
  timeline: row.timeline || "",
  city: row.city || "Islamabad",
  source: row.source || "website",
  status: CRM_STATUSES.includes(row.status) ? row.status : "new",
  assigned_agent: row.assigned_agent || "",
  priority: LEAD_PRIORITIES.includes(row.priority) ? row.priority : "medium",
  score: Number(row.score) || 0,
  follow_up_at: row.follow_up_at || null,
  converted_at: row.converted_at || null,
  notes_summary: row.notes_summary || "",
  ip: row.ip || "",
  user_agent: row.user_agent || "",
  created_at: row.created_at,
  updated_at: row.updated_at,
});
