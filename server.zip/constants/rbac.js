/** Role keys */
export const ROLES = {
  SUPER_ADMIN: "super_admin",
  ADMIN: "admin",
  SALES_MANAGER: "sales_manager",
  SALES_AGENT: "sales_agent",
  MARKETING_MANAGER: "marketing_manager",
  CONTENT_MANAGER: "content_manager",
  SUPPORT_STAFF: "support_staff",
};

/** Permission keys */
export const PERMISSIONS = {
  VIEW_LEADS: "view_leads",
  EDIT_LEADS: "edit_leads",
  EXPORT_LEADS: "export_leads",
  MANAGE_USERS: "manage_users",
  MANAGE_CAMPAIGNS: "manage_campaigns",
  MANAGE_PROPERTIES: "manage_properties",
  EDIT_WEBSITE: "edit_website",
  ANALYTICS: "analytics",
  SETTINGS: "settings",
  VIEW_AUDIT: "view_audit",
  MANAGE_NOTIFICATIONS: "manage_notifications",
};

export const ALL_PERMISSIONS = Object.values(PERMISSIONS);

export const DEFAULT_ROLE_DEFINITIONS = [
  {
    key: ROLES.SUPER_ADMIN,
    name: "Super Admin",
    is_system: true,
    permissions: [...ALL_PERMISSIONS],
  },
  {
    key: ROLES.ADMIN,
    name: "Admin",
    is_system: true,
    permissions: ALL_PERMISSIONS.filter((p) => p !== PERMISSIONS.VIEW_AUDIT),
  },
  {
    key: ROLES.SALES_MANAGER,
    name: "Sales Manager",
    is_system: true,
    permissions: [
      PERMISSIONS.VIEW_LEADS,
      PERMISSIONS.EDIT_LEADS,
      PERMISSIONS.EXPORT_LEADS,
      PERMISSIONS.MANAGE_CAMPAIGNS,
      PERMISSIONS.MANAGE_PROPERTIES,
      PERMISSIONS.ANALYTICS,
    ],
  },
  {
    key: ROLES.SALES_AGENT,
    name: "Sales Agent",
    is_system: true,
    permissions: [PERMISSIONS.VIEW_LEADS, PERMISSIONS.EDIT_LEADS, PERMISSIONS.MANAGE_PROPERTIES],
  },
  {
    key: ROLES.MARKETING_MANAGER,
    name: "Marketing Manager",
    is_system: true,
    permissions: [
      PERMISSIONS.VIEW_LEADS,
      PERMISSIONS.EXPORT_LEADS,
      PERMISSIONS.MANAGE_CAMPAIGNS,
      PERMISSIONS.EDIT_WEBSITE,
      PERMISSIONS.ANALYTICS,
    ],
  },
  {
    key: ROLES.CONTENT_MANAGER,
    name: "Content Manager",
    is_system: true,
    permissions: [PERMISSIONS.EDIT_WEBSITE, PERMISSIONS.MANAGE_PROPERTIES],
  },
  {
    key: ROLES.SUPPORT_STAFF,
    name: "Support Staff",
    is_system: true,
    permissions: [PERMISSIONS.VIEW_LEADS, PERMISSIONS.EDIT_LEADS, PERMISSIONS.MANAGE_NOTIFICATIONS],
  },
];
