import { dbTemplates } from "../db/database.js";
import { authenticateTeamMember } from "../services/team.service.js";
import { notifyLogin } from "../services/notification.service.js";
import { env, isSmtpConfigured, isWhatsAppConfigured } from "../config/env.js";
import {
  getClientIp,
  isLoginLocked,
  isIpBanned,
  recordLoginFailure,
  recordLoginSuccess,
  clearLoginAttempts,
} from "../services/security.service.js";
import { createSession, destroySession, getSession, updateSession } from "../services/session.service.js";
import { resolveAdminUser, toPublicAdminUser } from "../utils/admin-user.js";
import { logger } from "../utils/logger.js";
import { smtpStatus } from "../utils/mail-transport.js";
import { wapiStatus } from "../services/whatsappService.js";
import { getUptimeSeconds } from "../utils/uptime.js";
import { getQueueStats } from "../services/whatsappQueue.service.js";
import { listAuditLogs } from "../services/audit.service.js";
import { dbSecurityLogs } from "../db/database.js";
import {
  listInquiries,
  updateInquiry,
  deleteInquiry,
  countInquiries,
  countInquiriesByStatus,
} from "../services/inquiry.service.js";
import { getCrmAnalytics } from "../services/crm.service.js";
import { listTemplates, updateTemplate, buildFromTemplate } from "../services/template.service.js";
import { sendCustomEmail } from "../services/email.service.js";
import { sendWhatsAppMessage, sendTemplateMessage } from "../services/whatsappService.js";
import { getAllSettings, updateSettings } from "../services/settings.service.js";
import { listEmailLogs, listWhatsAppLogs, countEmailLogs, countWhatsAppLogs } from "../services/log.service.js";
import { listWhatsAppTemplateKeys } from "../templates/whatsapp/messages.js";
import { dbEmailLogs } from "../db/database.js";

export const adminLogin = async (req, res) => {
  const { email, password } = req.body;
  const ip = getClientIp(req);

  if (env.nodeEnv === "development") {
    logger.info("[ADMIN] Login attempt", { email: email?.trim(), ip });
  }

  if (isIpBanned(ip)) {
    return res.status(403).json({ success: false, message: "Too many failed attempts. Try again later." });
  }

  if (isLoginLocked(ip)) {
    return res.status(429).json({
      success: false,
      message: "Too many login attempts. Please wait 10 minutes.",
    });
  }

  if (!email || !password) {
    return res.status(400).json({ success: false, message: "Email and password required." });
  }

  const result = authenticateTeamMember(email, password);
  if (!result.ok) {
    const attempt = recordLoginFailure(ip, email.trim().toLowerCase());
    const message =
      result.reason === "suspended"
        ? "This account has been suspended."
        : "Invalid email or password.";
    return res.status(401).json({
      success: false,
      message,
      attemptsRemaining: Math.max(0, 10 - attempt.attempts),
    });
  }

  clearLoginAttempts(ip);
  recordLoginSuccess(ip, result.user.email);
  notifyLogin(result.user, ip);

  const fullUser = resolveAdminUser({
    userId: result.user.id,
    email: result.user.email,
    name: result.user.name,
    role_key: result.user.role_key,
  });
  const publicUser = toPublicAdminUser(fullUser || result.user);

  const sessionId = createSession(publicUser);

  logger.info("[AUTH] Login successful", {
    email: publicUser.email,
    role: publicUser.role_key,
    permissions: publicUser.permissions?.length,
    sessionIdPrefix: sessionId.slice(0, 8),
    ip,
  });

  res.json({
    success: true,
    sessionId,
    user: publicUser,
  });
};

export const adminLogout = (req, res) => {
  const sessionId = req.headers["x-session-id"]?.toString().trim();
  destroySession(sessionId);
  res.json({ success: true, message: "Logged out." });
};

export const adminProfile = (req, res) => {
  const sessionId = req.headers["x-session-id"]?.toString().trim();
  const session = getSession(sessionId);
  if (!session) return res.status(401).json({ success: false, message: "Not authenticated." });

  const fullUser = resolveAdminUser(session);
  const publicUser = toPublicAdminUser(fullUser);

  updateSession(sessionId, {
    role_key: publicUser.role_key,
    permissions: publicUser.permissions,
  });

  res.json({ success: true, user: publicUser });
};

export const adminDashboard = (_req, res) => {
  const analytics = getCrmAnalytics();
  res.json({
    success: true,
    stats: {
      ...analytics,
      totalInquiries: analytics.totalLeads,
      newInquiries: analytics.byStatus?.new || 0,
      contacted: analytics.byStatus?.contacted || 0,
      emailsSent: analytics.emailsSent,
      emailsFailed: countEmailLogs("failed"),
      whatsappSent: countWhatsAppLogs("sent"),
      recentInquiries: listInquiries({ limit: 8 }),
    },
  });
};

export const adminListInquiries = (req, res) => {
  const items = listInquiries({ q: req.query.q, status: req.query.status });
  res.json({ success: true, items });
};

export const adminPatchInquiry = (req, res) => {
  try {
    const item = updateInquiry(req.params.id, req.body, req.admin?.email || "admin");
    if (!item) return res.status(404).json({ success: false, message: "Not found." });
    res.json({ success: true, item });
  } catch (err) {
    res.status(err.statusCode || 400).json({ success: false, message: err.message });
  }
};

export const adminRemoveInquiry = (req, res) => {
  deleteInquiry(req.params.id);
  res.json({ success: true });
};

export const adminListTemplates = (_req, res) => {
  res.json({ success: true, items: listTemplates() });
};

export const adminPutTemplate = (req, res) => {
  const item = updateTemplate(req.params.id, req.body);
  if (!item) return res.status(404).json({ success: false, message: "Not found." });
  res.json({ success: true, item });
};

export const adminPreviewTemplate = (req, res) => {
  const tpl = dbTemplates.findById(req.params.id);
  if (!tpl) return res.status(404).json({ success: false, message: "Not found." });

  const vars = req.body.vars || {
    name: "Sample User",
    phone: "+92 300 1234567",
    email: "sample@email.com",
    message: "Sample message",
    project: "Faisal Hills",
    budget: "50L – 1Cr",
    timeline: "3–6 months",
    inquiry_id: "lead_sample",
    submitted_at: new Date().toLocaleString(),
    source: "/contact",
  };
  const built = buildFromTemplate(tpl.key, vars);
  res.json({ success: true, subject: built?.subject, html: built?.html });
};

export const adminSendEmail = async (req, res) => {
  const { to, subject, html, templateKey, vars, inquiryId, cc, bcc, replyTo } = req.body;
  let finalSubject = subject;
  let finalHtml = html;

  if (templateKey) {
    const built = buildFromTemplate(templateKey, vars || {});
    if (!built) return res.status(400).json({ success: false, message: "Template not found." });
    finalSubject = built.subject;
    finalHtml = built.html;
  }

  if (!to || !finalSubject || !finalHtml) {
    return res.status(400).json({ success: false, message: "to, subject, and html required." });
  }

  await sendCustomEmail({
    to,
    subject: finalSubject,
    html: finalHtml,
    templateKey,
    inquiryId,
    cc,
    bcc,
    replyTo: replyTo || env.companyEmail,
  });
  res.json({ success: true, message: "Email sent." });
};

export const adminEmailLogs = (_req, res) => {
  res.json({ success: true, items: listEmailLogs(100) });
};

export const adminResendEmail = async (req, res) => {
  const { logId } = req.body;
  const log = dbEmailLogs.list(500).find((l) => l.id === Number(logId));
  if (!log) return res.status(404).json({ success: false, message: "Log entry not found." });
  if (log.status === "sent") {
    return res.status(400).json({ success: false, message: "Email already sent successfully." });
  }

  await sendCustomEmail({
    to: log.to_address,
    subject: log.subject,
    html: `<p>Resent inquiry notification.</p>`,
    templateKey: log.template_key,
    inquiryId: log.inquiry_id,
  });
  res.json({ success: true, message: "Resend queued." });
};

export const adminSendWhatsApp = async (req, res) => {
  const { to, message, inquiryId, templateKey, variables } = req.body;

  if (templateKey && !message) {
    await sendTemplateMessage({ to, templateKey, variables, inquiryId });
    return res.json({ success: true, message: "WhatsApp template sent." });
  }

  if (!to || !message) {
    return res.status(400).json({ success: false, message: "to and message required (or templateKey)." });
  }

  await sendWhatsAppMessage({ to, message, inquiryId, templateKey });
  res.json({ success: true, message: "WhatsApp message sent." });
};

export const adminWhatsAppLogs = (_req, res) => {
  res.json({ success: true, items: listWhatsAppLogs(100) });
};

export const adminWhatsAppTemplates = (_req, res) => {
  res.json({ success: true, keys: listWhatsAppTemplateKeys() });
};

export const adminGetSettings = (_req, res) => {
  res.json({ success: true, settings: getAllSettings() });
};

export const adminPutSettings = (req, res) => {
  const settings = updateSettings(req.body);
  res.json({ success: true, settings });
};

export const adminSystemStatus = (_req, res) => {
  res.json({
    success: true,
    version: "3.0.0",
    uptimeSeconds: getUptimeSeconds(),
    environment: env.nodeEnv,
    services: {
      database: { status: "connected" },
      smtp: {
        status: smtpStatus.ready ? "online" : "offline",
        configured: isSmtpConfigured(),
        error: smtpStatus.lastError,
      },
      whatsapp: {
        status: wapiStatus.ready ? "online" : "offline",
        configured: isWhatsAppConfigured(),
        error: wapiStatus.lastError,
        queue: getQueueStats(),
      },
    },
    memory: process.memoryUsage(),
  });
};

export const adminActivity = (_req, res) => {
  const failedEmails = listEmailLogs(20).filter((l) => l.status === "failed");
  const failedWhatsApp = listWhatsAppLogs(20).filter((l) => l.status === "failed");

  res.json({
    success: true,
    live: {
      recentInquiries: listInquiries({ limit: 10 }),
      emailLogs: listEmailLogs(15),
      whatsappLogs: listWhatsAppLogs(15),
      failedAlerts: [
        ...failedEmails.map((e) => ({ type: "email", ...e })),
        ...failedWhatsApp.map((w) => ({ type: "whatsapp", ...w })),
      ],
      securityLogs: dbSecurityLogs.list(10),
      auditLogs: listAuditLogs(10),
    },
  });
};
