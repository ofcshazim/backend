import { contactBodySchema } from "../validation/contact.schema.js";
import { sanitizeEmail, sanitizePhone, sanitizeText } from "../utils/sanitize.js";
import { createInquiry } from "../services/inquiry.service.js";
import { deliverInquiryEmails, smtpStatus } from "../services/email.service.js";
import { notifyLeadViaWhatsApp } from "../services/whatsappService.js";
import { isSmtpConfigured } from "../config/env.js";
import { logger } from "../utils/logger.js";

const userMessageForError = (err) => {
  if (err.code === "SMTP_NOT_READY" || err.code === "SMTP_NOT_CONFIGURED") {
    return "Our email service is temporarily unavailable. Please call +92 313 7255556 or try again shortly.";
  }
  if (err.code === "ECONNECTION" || err.code === "ETIMEDOUT" || err.code === "ESOCKET") {
    return "We could not connect to our mail server. Your inquiry was saved—we will follow up manually.";
  }
  if (err.code === "EAUTH") {
    return "Email authentication failed on our server. Please contact us by phone.";
  }
  return err.message || "Unable to send your message right now.";
};

export const submitContact = async (req, res) => {
  if (req.body?.website) {
    return res.status(200).json({ success: true, message: "Inquiry received." });
  }

  if (!isSmtpConfigured()) {
    return res.status(503).json({
      success: false,
      code: "SMTP_NOT_CONFIGURED",
      message: "Contact service is not configured. Please call +92 313 7255556.",
    });
  }

  const parsed = contactBodySchema.parse(req.body);

  const lead = createInquiry({
    name: sanitizeText(parsed.name, 120),
    phone: sanitizePhone(parsed.phone),
    email: sanitizeEmail(parsed.email),
    budget: sanitizeText(parsed.budget, 80),
    project: sanitizeText(parsed.project, 120),
    timeline: sanitizeText(parsed.timeline, 80),
    message: sanitizeText(parsed.message, 2000),
    source: sanitizeText(parsed.source, 120) || "website",
    city: sanitizeText(parsed.city, 80) || "Islamabad",
    ip:
      req.headers["x-forwarded-for"]?.toString().split(",")[0]?.trim() ||
      req.socket.remoteAddress ||
      "",
    user_agent: sanitizeText(req.headers["user-agent"], 300),
  });

  let emailSent = false;
  try {
    await deliverInquiryEmails(lead);
    emailSent = true;
  } catch (err) {
    logger.error("Contact email failed", { leadId: lead.id, error: err.message, code: err.code });

    try {
      await notifyLeadViaWhatsApp(lead);
    } catch (waErr) {
      logger.warn("WhatsApp failed", { leadId: lead.id, error: waErr.message });
    }

    if (err.code === "EAUTH") {
      return res.status(502).json({
        success: false,
        code: err.code,
        message: userMessageForError(err),
        id: lead.id,
        saved: true,
      });
    }

    return res.status(201).json({
      success: true,
      message:
        "We received your inquiry. Email delivery is delayed—our team will contact you within one business day.",
      id: lead.id,
      emailPending: true,
    });
  }

  try {
    await notifyLeadViaWhatsApp(lead);
  } catch (err) {
    logger.warn("WhatsApp failed", { leadId: lead.id, error: err.message });
  }

  if (!emailSent) {
    return res.status(201).json({
      success: true,
      message: "We received your inquiry and will respond within one business day.",
      id: lead.id,
    });
  }

  return res.status(201).json({
    success: true,
    message:
      "Thank you—we received your inquiry and will respond within one business day.",
    id: lead.id,
  });
};
