import {
  listInquiries,
  getInquiryById,
  updateInquiry,
  deleteInquiry,
} from "../services/inquiry.service.js";
import { getPipeline, getCrmAnalytics, getMonthlyReport } from "../services/crm.service.js";
import { addLeadNote, listLeadNotes, deleteLeadNote } from "../services/lead-notes.service.js";
import { dbLeadActivities } from "../db/database.js";
import { exportLeads, leadsToPdfHtml } from "../services/export.service.js";
import {
  listCampaigns,
  getCampaign,
  createCampaign,
  updateCampaign,
  deleteCampaign,
  sendCampaign,
  sendTestCampaign,
} from "../services/campaign.service.js";
import { CRM_STATUSES, LEAD_SOURCES, LEAD_PRIORITIES, PIPELINE_STAGES } from "../constants/crm.js";
import { getAllSettings } from "../services/settings.service.js";

const parseFilters = (query) => ({
  q: query.q,
  status: query.status,
  source: query.source,
  project: query.project,
  assigned_agent: query.assigned_agent,
  priority: query.priority,
  from: query.from,
  to: query.to,
  limit: Number(query.limit) || 500,
  offset: Number(query.offset) || 0,
});

export const crmMeta = (_req, res) => {
  const settings = getAllSettings();
  let agents = [];
  try {
    agents = JSON.parse(settings.crm_agents || "[]");
  } catch {
    agents = [];
  }
  res.json({
    success: true,
    statuses: CRM_STATUSES,
    sources: LEAD_SOURCES,
    priorities: LEAD_PRIORITIES,
    pipeline: PIPELINE_STAGES,
    agents,
  });
};

export const crmListLeads = (req, res) => {
  const items = listInquiries(parseFilters(req.query));
  res.json({ success: true, items, total: items.length });
};

export const crmGetLead = (req, res) => {
  const lead = getInquiryById(req.params.id);
  if (!lead) return res.status(404).json({ success: false, message: "Lead not found." });
  const notes = listLeadNotes(lead.id);
  const activities = dbLeadActivities.listByLead(lead.id);
  res.json({ success: true, lead, notes, activities });
};

export const crmUpdateLead = (req, res) => {
  try {
    const lead = updateInquiry(req.params.id, req.body, req.admin?.email || "admin");
    if (!lead) return res.status(404).json({ success: false, message: "Lead not found." });
    res.json({ success: true, lead });
  } catch (err) {
    res.status(err.statusCode || 400).json({ success: false, message: err.message });
  }
};

export const crmDeleteLead = (req, res) => {
  deleteInquiry(req.params.id);
  res.json({ success: true });
};

export const crmAddNote = (req, res) => {
  const { text } = req.body;
  if (!text?.trim()) return res.status(400).json({ success: false, message: "Note text required." });
  const note = addLeadNote(req.params.id, text, req.admin?.email || "admin");
  res.json({ success: true, note });
};

export const crmDeleteNote = (req, res) => {
  deleteLeadNote(Number(req.params.noteId), req.params.id);
  res.json({ success: true });
};

export const crmPipeline = (_req, res) => {
  res.json({ success: true, ...getPipeline() });
};

export const crmAnalytics = (_req, res) => {
  res.json({ success: true, analytics: getCrmAnalytics() });
};

export const crmMonthlyReport = (_req, res) => {
  res.json({ success: true, report: getMonthlyReport() });
};

export const crmExportCsv = (req, res) => {
  const { csv } = exportLeads(parseFilters(req.query));
  res.setHeader("Content-Type", "text/csv; charset=utf-8");
  res.setHeader("Content-Disposition", `attachment; filename="leads-${Date.now()}.csv"`);
  res.send(csv);
};

export const crmExportExcel = (req, res) => {
  const { csv } = exportLeads(parseFilters(req.query));
  res.setHeader("Content-Type", "application/vnd.ms-excel; charset=utf-8");
  res.setHeader("Content-Disposition", `attachment; filename="leads-${Date.now()}.xls"`);
  res.send(csv);
};

export const crmExportPdf = (req, res) => {
  const { leads } = exportLeads(parseFilters(req.query));
  const html = leadsToPdfHtml(leads);
  res.setHeader("Content-Type", "text/html; charset=utf-8");
  res.setHeader("Content-Disposition", `attachment; filename="leads-${Date.now()}.html"`);
  res.send(html);
};

// Campaigns
export const crmListCampaigns = (_req, res) => {
  res.json({ success: true, items: listCampaigns() });
};

export const crmGetCampaign = (req, res) => {
  const item = getCampaign(req.params.id);
  if (!item) return res.status(404).json({ success: false, message: "Not found." });
  res.json({ success: true, item });
};

export const crmCreateCampaign = (req, res) => {
  const item = createCampaign(req.body);
  res.status(201).json({ success: true, item });
};

export const crmUpdateCampaign = (req, res) => {
  const item = updateCampaign(req.params.id, req.body);
  if (!item) return res.status(404).json({ success: false, message: "Not found." });
  res.json({ success: true, item });
};

export const crmDeleteCampaign = (req, res) => {
  deleteCampaign(req.params.id);
  res.json({ success: true });
};

export const crmSendCampaign = async (req, res) => {
  try {
    const item = await sendCampaign(req.params.id);
    res.json({ success: true, item });
  } catch (err) {
    res.status(err.statusCode || 500).json({ success: false, message: err.message });
  }
};

export const crmTestEmail = async (req, res) => {
  try {
    await sendTestCampaign(req.body);
    res.json({ success: true, message: "Test email sent." });
  } catch (err) {
    res.status(502).json({ success: false, message: err.message });
  }
};
