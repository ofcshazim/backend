import { listTeamMembers, getTeamMember, createTeamMember, updateTeamMember, resetTeamPassword, suspendTeamMember, reactivateTeamMember } from "../services/team.service.js";
import { listRoles, updateRolePermissions } from "../services/rbac.service.js";
import { listCmsSections, getCmsSection, upsertCmsSection, publishCmsSection, listMedia, addMedia, deleteMedia } from "../services/cms.service.js";
import { listProperties, getProperty, createProperty, updateProperty, deleteProperty } from "../services/property.service.js";
import { listNotifications, markNotificationRead, markAllRead, countUnread } from "../services/notification.service.js";
import { getEnterpriseAnalytics, getSocialAnalytics } from "../services/analytics.service.js";
import { listAuditLogs } from "../services/audit.service.js";
import { saveBase64Image } from "../services/media.service.js";
import { getAllSettings, updateSettings } from "../services/settings.service.js";

// ─── Team ──────────────────────────────────────────────────────────

export const teamList = (_req, res) => {
  res.json({ success: true, members: listTeamMembers(), roles: listRoles() });
};

export const teamGet = (req, res) => {
  const member = getTeamMember(req.params.id);
  if (!member) return res.status(404).json({ success: false, message: "User not found." });
  res.json({ success: true, member });
};

export const teamCreate = (req, res) => {
  try {
    const member = createTeamMember(req.body, req.admin);
    res.status(201).json({ success: true, member });
  } catch (e) {
    res.status(400).json({ success: false, message: e.message });
  }
};

export const teamUpdate = (req, res) => {
  const member = updateTeamMember(Number(req.params.id), req.body, req.admin);
  if (!member) return res.status(404).json({ success: false, message: "User not found." });
  res.json({ success: true, member });
};

export const teamResetPassword = (req, res) => {
  try {
    const member = resetTeamPassword(Number(req.params.id), req.body.password, req.admin);
    res.json({ success: true, member });
  } catch (e) {
    res.status(400).json({ success: false, message: e.message });
  }
};

export const teamSuspend = (req, res) => {
  const member = suspendTeamMember(Number(req.params.id), req.admin);
  if (!member) return res.status(404).json({ success: false, message: "User not found." });
  res.json({ success: true, member });
};

export const teamReactivate = (req, res) => {
  const member = reactivateTeamMember(Number(req.params.id), req.admin);
  if (!member) return res.status(404).json({ success: false, message: "User not found." });
  res.json({ success: true, member });
};

export const rolesList = (_req, res) => {
  res.json({ success: true, roles: listRoles() });
};

export const rolesUpdate = (req, res) => {
  const role = updateRolePermissions(req.params.key, req.body.permissions || []);
  if (!role) return res.status(404).json({ success: false, message: "Role not found." });
  res.json({ success: true, role });
};

// ─── CMS ─────────────────────────────────────────────────────────────

export const cmsList = (_req, res) => {
  res.json({ success: true, sections: listCmsSections() });
};

export const cmsGet = (req, res) => {
  const section = getCmsSection(req.params.key);
  if (!section) return res.status(404).json({ success: false, message: "Section not found." });
  res.json({ success: true, section });
};

export const cmsPut = (req, res) => {
  const section = upsertCmsSection(req.params.key, req.body, req.admin);
  res.json({ success: true, section });
};

export const cmsPublish = (req, res) => {
  const section = publishCmsSection(req.params.key, req.admin);
  if (!section) return res.status(404).json({ success: false, message: "Section not found." });
  res.json({ success: true, section });
};

export const cmsMediaList = (_req, res) => {
  res.json({ success: true, media: listMedia() });
};

export const cmsMediaUpload = (req, res) => {
  try {
    const saved = saveBase64Image(req.body.data, req.body.filename || "media");
    const record = addMedia(
      { ...saved, alt: req.body.alt || "" },
      req.admin
    );
    res.status(201).json({ success: true, media: record });
  } catch (e) {
    res.status(400).json({ success: false, message: e.message });
  }
};

export const cmsMediaDelete = (req, res) => {
  deleteMedia(Number(req.params.id), req.admin);
  res.json({ success: true });
};

// ─── Properties ──────────────────────────────────────────────────────

export const propertiesList = (req, res) => {
  res.json({
    success: true,
    properties: listProperties({
      publish_status: req.query.publish_status,
      featured: req.query.featured === "true" ? true : undefined,
      q: req.query.q,
    }),
  });
};

export const propertiesGet = (req, res) => {
  const property = getProperty(req.params.id);
  if (!property) return res.status(404).json({ success: false, message: "Property not found." });
  res.json({ success: true, property });
};

export const propertiesCreate = (req, res) => {
  const property = createProperty(req.body, req.admin);
  res.status(201).json({ success: true, property });
};

export const propertiesUpdate = (req, res) => {
  const property = updateProperty(req.params.id, req.body, req.admin);
  if (!property) return res.status(404).json({ success: false, message: "Property not found." });
  res.json({ success: true, property });
};

export const propertiesDelete = (req, res) => {
  deleteProperty(req.params.id, req.admin);
  res.json({ success: true });
};

// ─── Notifications ───────────────────────────────────────────────────

export const notificationsList = (req, res) => {
  res.json({
    success: true,
    notifications: listNotifications({
      userId: req.admin.id,
      unreadOnly: req.query.unread === "true",
      limit: Number(req.query.limit) || 50,
    }),
    unread: countUnread(req.admin.id),
  });
};

export const notificationsRead = (req, res) => {
  markNotificationRead(Number(req.params.id));
  res.json({ success: true });
};

export const notificationsReadAll = (req, res) => {
  markAllRead(req.admin.id);
  res.json({ success: true });
};

// ─── Analytics ───────────────────────────────────────────────────────

export const analyticsDashboard = (_req, res) => {
  res.json({ success: true, analytics: getEnterpriseAnalytics() });
};

export const analyticsSocial = (_req, res) => {
  res.json({ success: true, social: getSocialAnalytics() });
};

// ─── Audit ───────────────────────────────────────────────────────────

export const auditList = (req, res) => {
  res.json({
    success: true,
    logs: listAuditLogs(Number(req.query.limit) || 150),
  });
};

// ─── Extended settings ─────────────────────────────────────────────────

export const settingsGetExtended = (_req, res) => {
  res.json({ success: true, settings: getAllSettings() });
};

export const settingsPutExtended = (req, res) => {
  updateSettings(req.body);
  res.json({ success: true, settings: getAllSettings() });
};
