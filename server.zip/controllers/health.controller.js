import os from "os";
import { env, isSmtpConfigured, isWhatsAppConfigured } from "../config/env.js";
import { smtpStatus } from "../utils/mail-transport.js";
import { wapiStatus } from "../services/whatsappService.js";
import { getUptimeSeconds } from "../utils/uptime.js";
import { API_VERSION } from "../utils/banner.js";
import { getStorePath } from "../db/database.js";
import { getQueueStats } from "../services/whatsappQueue.service.js";

const statusLabel = (ready, configured) => {
  if (!configured) return "disabled";
  return ready ? "connected" : "offline";
};

/** Liveness probe — no DB, SMTP, or auth; must stay fast and always 200 when process is up */
export const getHealthLiveness = (_req, res) => {
  res.status(200).json({ status: "ok" });
};

export const getHealth = getHealthLiveness;

export const getHealthDetails = (req, res) => {
  const start = Date.now();
  const mem = process.memoryUsage();
  const load = os.loadavg();

  res.json({
    status: "ok",
    ok: true,
    service: "check-in-property-api",
    version: API_VERSION,
    environment: env.nodeEnv,
    node: process.version,
    uptime: `${getUptimeSeconds()}s`,
    uptimeSeconds: getUptimeSeconds(),
    timestamp: new Date().toISOString(),
    responseTimeMs: Date.now() - start,
    database: {
      status: "connected",
    },
    smtp: statusLabel(smtpStatus.ready, isSmtpConfigured()),
    whatsapp: statusLabel(wapiStatus.ready, isWhatsAppConfigured()),
    integrations: {
      smtp: {
        configured: isSmtpConfigured(),
        ready: smtpStatus.ready,
        status: statusLabel(smtpStatus.ready, isSmtpConfigured()),
        error: smtpStatus.lastError,
        verifiedAt: smtpStatus.verifiedAt,
      },
      whatsapp: {
        configured: isWhatsAppConfigured(),
        provider: env.whatsapp.provider,
        ready: wapiStatus.ready,
        status: statusLabel(wapiStatus.ready, isWhatsAppConfigured()),
        error: wapiStatus.lastError,
        verifiedAt: wapiStatus.verifiedAt,
        queue: getQueueStats(),
      },
    },
    memoryUsage: {
      rss: mem.rss,
      heapUsed: mem.heapUsed,
      heapTotal: mem.heapTotal,
      external: mem.external,
    },
    cpuUsage: {
      load1m: load[0],
      load5m: load[1],
      cores: os.cpus().length,
    },
  });
};

/** Readiness — integrations status only; never returns 503 (use /health for liveness) */
export const getReady = (_req, res) => {
  res.status(200).json({
    status: "ok",
    ready: true,
    smtpReady: smtpStatus.ready,
    smtpConfigured: isSmtpConfigured(),
    wapiReady: wapiStatus.ready,
    whatsappConfigured: isWhatsAppConfigured(),
  });
};
