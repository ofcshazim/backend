import { asyncHandler } from "../utils/async-handler.js";
import {
  buildSystemHealth,
  getSystemPing,
  getSystemStats,
  getSystemUptime,
  getAuthkeyStatus,
  getErrorLogs,
  exportErrorLogs,
} from "../services/system-monitor.service.js";

export const systemHealth = asyncHandler(async (_req, res) => {
  const data = await buildSystemHealth();
  res.json({ success: true, ...data });
});

export const systemPing = asyncHandler(async (_req, res) => {
  const data = await getSystemPing();
  res.json({ success: true, ...data });
});

export const systemStats = asyncHandler(async (_req, res) => {
  res.json({ success: true, ...getSystemStats() });
});

export const systemUptime = asyncHandler(async (_req, res) => {
  res.json({ success: true, ...getSystemUptime() });
});

export const systemAuthkeyStatus = asyncHandler(async (_req, res) => {
  res.json({ success: true, ...getAuthkeyStatus() });
});

export const systemErrors = asyncHandler(async (req, res) => {
  const { q, type, limit, export: doExport } = req.query;
  if (doExport === "1" || doExport === "true") {
    const items = exportErrorLogs();
    res.setHeader("Content-Type", "application/json");
    res.setHeader("Content-Disposition", `attachment; filename="api-errors-${Date.now()}.json"`);
    return res.send(JSON.stringify(items, null, 2));
  }
  const items = getErrorLogs({
    q: q?.toString(),
    type: type?.toString(),
    limit: limit ? Number(limit) : 50,
  });
  res.json({ success: true, items });
});
