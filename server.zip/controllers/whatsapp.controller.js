import { z } from "zod";
import { env, isWhatsAppConfigured } from "../config/env.js";
import {
  authkeyStatus,
  getBalance,
  sendTextTemplate,
  sendMediaTemplate,
  sendBulkInChunks,
  sendDynamicButtonTemplate,
  sendCopyCodeTemplate,
  sendLimitedTimeOfferTemplate,
} from "../services/authkey.service.js";
import {
  sendWhatsAppMessage,
  sendBulkCampaign,
  sendMediaMessage,
} from "../services/whatsappService.js";
import { getQueueStats } from "../services/whatsappQueue.service.js";
import {
  getWhatsAppStats,
  listMessageHistory,
  listCampaigns,
  getCampaign,
  createCampaign,
  updateCampaign,
  duplicateCampaign,
  listLocalTemplates,
  saveLocalTemplate,
  deleteLocalTemplate,
  listContacts,
  saveContact,
  updateContact,
  deleteContact,
  importContacts,
  exportContacts,
  recordUploadedMedia,
  listUploadedMedia,
  scheduleMessage,
  listScheduledMessages,
} from "../services/whatsapp-data.service.js";
import { getUploadMeta } from "../middleware/whatsapp-upload.js";
import { validatePhoneNumber } from "../utils/sanitize.js";

const phoneSchema = z.string().min(10).max(20);

const sendSchema = z.object({
  to: phoneSchema,
  wid: z.string().min(1),
  bodyValues: z.record(z.string()).optional(),
  type: z.enum(["text", "media", "button", "copy_code", "lto"]).optional(),
  headerValues: z
    .object({
      headerFileName: z.string().optional(),
      headerData: z.string().url().optional(),
    })
    .optional(),
  button_param_value: z.string().optional(),
  copy_code_value: z.string().optional(),
  expiration_time_ms: z.number().optional(),
  templateKey: z.string().optional(),
  campaignId: z.number().optional(),
});

const bulkSchema = z.object({
  wid: z.string().min(1),
  country_code: z.string().default("92"),
  type: z.enum(["text", "media"]).default("text"),
  data: z.array(z.record(z.unknown())).min(1).max(2000),
  button_param_value: z.string().optional(),
  copy_code_value: z.string().optional(),
  expiration_time_ms: z.number().optional(),
  campaignId: z.number().optional(),
  name: z.string().optional(),
});

const scheduleSchema = z.object({
  scheduled_at: z.string().datetime(),
  payload: z.record(z.unknown()),
});

const templateSchema = z.object({
  key: z.string().min(1),
  name: z.string().min(1),
  wid: z.string().min(1),
  type: z.enum(["text", "media"]).default("text"),
  variables: z.array(z.string()).optional(),
  description: z.string().optional(),
});

const contactSchema = z.object({
  name: z.string().min(1),
  phone: phoneSchema,
  email: z.string().email().optional().or(z.literal("")),
  tags: z.array(z.string()).optional(),
  notes: z.string().optional(),
});

export const whatsappDashboard = async (_req, res) => {
  const stats = getWhatsAppStats();
  const queue = getQueueStats();
  res.json({
    success: true,
    stats: {
      ...stats,
      queue,
      authkey: {
        ready: authkeyStatus.ready,
        balance: authkeyStatus.balance,
        balanceCheckedAt: authkeyStatus.balanceCheckedAt,
        lowBalance: Number(authkeyStatus.balance) < env.authkey.lowBalanceThreshold,
        error: authkeyStatus.lastError,
      },
    },
  });
};

export const whatsappBalance = async (_req, res) => {
  if (!isWhatsAppConfigured()) {
    return res.status(503).json({ success: false, message: "Authkey not configured" });
  }
  const balance = await getBalance();
  res.json({
    success: true,
    balance,
    lowBalance: Number(balance?.balance ?? balance?.credits ?? authkeyStatus.balance) < env.authkey.lowBalanceThreshold,
    threshold: env.authkey.lowBalanceThreshold,
  });
};

export const whatsappSend = async (req, res) => {
  const body = sendSchema.parse(req.body);
  const validation = validatePhoneNumber(body.to);
  if (!validation.valid) {
    return res.status(400).json({ success: false, message: validation.error });
  }

  let result;
  if (body.type === "media") {
    result = await sendMediaMessage(body);
  } else if (body.type === "button") {
    result = await sendDynamicButtonTemplate({ ...body, phone: body.to });
  } else if (body.type === "copy_code") {
    result = await sendCopyCodeTemplate({ ...body, phone: body.to });
  } else if (body.type === "lto") {
    result = await sendLimitedTimeOfferTemplate({ ...body, phone: body.to });
  } else {
    result = await sendWhatsAppMessage({ ...body, to: body.to });
  }

  res.json({ success: true, result });
};

export const whatsappSendMedia = async (req, res) => {
  const body = sendSchema.extend({ type: z.literal("media").default("media") }).parse({
    ...req.body,
    type: "media",
  });
  const result = await sendMediaMessage(body);
  res.json({ success: true, result });
};

export const whatsappBulkSend = async (req, res) => {
  const body = bulkSchema.parse(req.body);
  let campaignId = body.campaignId;

  if (body.name && !campaignId) {
    const campaign = createCampaign({
      name: body.name,
      wid: body.wid,
      type: body.type,
      status: "running",
      recipient_count: body.data.length,
      payload: body,
      created_by: req.admin?.email,
    });
    campaignId = campaign.id;
  }

  const result = await sendBulkCampaign({ ...body, campaignId });
  if (campaignId) {
    updateCampaign(campaignId, {
      status: result.ok ? "completed" : "failed",
      sent_count: body.data.length,
    });
  }

  res.json({ success: true, campaignId, result });
};

export const whatsappSchedule = async (req, res) => {
  const body = scheduleSchema.parse(req.body);
  const scheduled = scheduleMessage({
    ...body,
    created_by: req.admin?.email,
  });
  res.json({ success: true, scheduled });
};

export const whatsappHistory = async (req, res) => {
  const { status, campaign_id, q, limit, offset } = req.query;
  const items = listMessageHistory({
    status: status?.toString(),
    campaign_id: campaign_id ? Number(campaign_id) : undefined,
    q: q?.toString(),
    limit: limit ? Number(limit) : 100,
    offset: offset ? Number(offset) : 0,
  });
  res.json({ success: true, items, total: items.length });
};

export const whatsappCampaigns = async (req, res) => {
  const status = req.query.status?.toString();
  const items = listCampaigns({ status, limit: 100 });
  res.json({ success: true, items });
};

export const whatsappCreateCampaign = async (req, res) => {
  const campaign = createCampaign({
    ...req.body,
    created_by: req.admin?.email,
  });
  res.json({ success: true, campaign });
};

export const whatsappUpdateCampaign = async (req, res) => {
  const campaign = updateCampaign(Number(req.params.id), req.body);
  if (!campaign) return res.status(404).json({ success: false, message: "Campaign not found" });
  res.json({ success: true, campaign });
};

export const whatsappDuplicateCampaign = async (req, res) => {
  const campaign = duplicateCampaign(Number(req.params.id));
  if (!campaign) return res.status(404).json({ success: false, message: "Campaign not found" });
  res.json({ success: true, campaign });
};

export const whatsappTemplates = async (_req, res) => {
  res.json({ success: true, items: listLocalTemplates() });
};

export const whatsappSaveTemplate = async (req, res) => {
  const data = templateSchema.parse(req.body);
  const template = saveLocalTemplate(data);
  res.json({ success: true, template });
};

export const whatsappDeleteTemplate = async (req, res) => {
  deleteLocalTemplate(Number(req.params.id));
  res.json({ success: true });
};

export const whatsappContacts = async (req, res) => {
  const { q, tag, limit, offset } = req.query;
  const items = listContacts({
    q: q?.toString(),
    tag: tag?.toString(),
    limit: limit ? Number(limit) : 500,
    offset: offset ? Number(offset) : 0,
  });
  res.json({ success: true, items, total: items.length });
};

export const whatsappCreateContact = async (req, res) => {
  const data = contactSchema.parse(req.body);
  const contact = saveContact(data);
  res.json({ success: true, contact });
};

export const whatsappUpdateContact = async (req, res) => {
  const contact = updateContact(Number(req.params.id), req.body);
  if (!contact) return res.status(404).json({ success: false, message: "Contact not found" });
  res.json({ success: true, contact });
};

export const whatsappDeleteContact = async (req, res) => {
  deleteContact(Number(req.params.id));
  res.json({ success: true });
};

export const whatsappImportContacts = async (req, res) => {
  const rows = Array.isArray(req.body.contacts) ? req.body.contacts : [];
  const parsed = rows
    .map((row) => {
      try {
        return contactSchema.parse(row);
      } catch {
        return null;
      }
    })
    .filter(Boolean);
  const created = importContacts(parsed);
  res.json({ success: true, imported: created.length, items: created });
};

export const whatsappExportContacts = async (_req, res) => {
  const items = exportContacts();
  res.json({ success: true, items });
};

export const whatsappUpload = async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ success: false, message: "No file uploaded" });
  }
  const meta = getUploadMeta(req.file);
  const record = recordUploadedMedia({
    ...meta,
    uploaded_by: req.admin?.email,
  });
  res.json({ success: true, file: record });
};

export const whatsappMediaList = async (_req, res) => {
  res.json({ success: true, items: listUploadedMedia(200) });
};

export const whatsappScheduledList = async (_req, res) => {
  res.json({ success: true, items: listScheduledMessages("pending") });
};
