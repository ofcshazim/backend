/**
 * Pure-JSON persistence with write queue, backups, and corruption recovery.
 */
import fs from "fs";
import path from "path";
import { env } from "../config/env.js";
import { logger } from "../utils/logger.js";
import { runExclusive } from "./write-queue.js";
import { createBackup, restoreLatestBackup } from "../services/backup.service.js";

const defaultStore = () => ({
  inquiries: [],
  lead_notes: [],
  lead_activities: [],
  email_logs: [],
  whatsapp_logs: [],
  email_templates: [],
  email_campaigns: [],
  site_settings: {},
  admin_users: [],
  roles: [],
  cms_sections: [],
  cms_media: [],
  properties: [],
  notifications: [],
  admin_audit_logs: [],
  security_logs: [],
  _counters: {
    email_logs: 0,
    whatsapp_logs: 0,
    admin_users: 0,
    admin_audit_logs: 0,
    security_logs: 0,
    lead_notes: 0,
    lead_activities: 0,
    email_campaigns: 0,
    roles: 0,
    cms_media: 0,
    properties: 0,
    notifications: 0,
  },
});

let store = null;
let storePath = null;
let writeCount = 0;

const validateStoreShape = (data) => {
  if (!data || typeof data !== "object") return false;
  return Array.isArray(data.inquiries) && typeof data._counters === "object";
};

const loadFromFile = (filePath) => {
  const raw = fs.readFileSync(filePath, "utf8");
  const data = JSON.parse(raw);
  if (!validateStoreShape(data)) throw new Error("Invalid store shape");
  return data;
};

const persistUnsafe = () => {
  const tmp = `${storePath}.tmp`;
  const payload = JSON.stringify(store, null, 2);
  fs.writeFileSync(tmp, payload, "utf8");
  fs.renameSync(tmp, storePath);
  writeCount += 1;
  if (writeCount % 50 === 0) createBackup(storePath, "auto-50-writes");
};

export const persist = () =>
  runExclusive(async () => {
    persistUnsafe();
  });

const nextId = (table) => {
  store._counters[table] = (store._counters[table] || 0) + 1;
  return store._counters[table];
};

export const initDatabase = () => {
  storePath = path.isAbsolute(env.dbPath)
    ? env.dbPath.replace(/\.db$/i, ".json")
    : path.join(process.cwd(), env.dbPath.replace(/\.db$/i, ".json"));

  fs.mkdirSync(path.dirname(storePath), { recursive: true });

  if (fs.existsSync(storePath)) {
    try {
      store = loadFromFile(storePath);
      store._counters = { ...defaultStore()._counters, ...store._counters };
      if (!Array.isArray(store.admin_audit_logs)) store.admin_audit_logs = [];
      if (!Array.isArray(store.security_logs)) store.security_logs = [];
      if (!Array.isArray(store.lead_notes)) store.lead_notes = [];
      if (!Array.isArray(store.lead_activities)) store.lead_activities = [];
      if (!Array.isArray(store.email_campaigns)) store.email_campaigns = [];
      if (!Array.isArray(store.roles)) store.roles = [];
      if (!Array.isArray(store.cms_sections)) store.cms_sections = [];
      if (!Array.isArray(store.cms_media)) store.cms_media = [];
      if (!Array.isArray(store.properties)) store.properties = [];
      if (!Array.isArray(store.notifications)) store.notifications = [];
    } catch (err) {
      logger.error("[DB] Corrupt store — attempting backup recovery", { error: err.message });
      const corruptPath = `${storePath}.corrupt-${Date.now()}`;
      try {
        fs.renameSync(storePath, corruptPath);
      } catch {
        /* ignore */
      }
      try {
        restoreLatestBackup(storePath);
        store = loadFromFile(storePath);
        logger.warn("[DB] Recovered from latest backup");
      } catch {
        store = defaultStore();
        persistUnsafe();
        logger.error("[DB] No backup — initialized empty store");
      }
    }
  } else {
    store = defaultStore();
    persistUnsafe();
  }

  logger.info("[DB] Database connected", {
    path: storePath,
    node: process.version,
    inquiries: store.inquiries.length,
  });

  return store;
};

export const getStorePath = () => storePath;

export const closeDatabase = async () => {
  if (store && storePath) {
    await runExclusive(async () => {
      persistUnsafe();
      createBackup(storePath, "shutdown");
    });
  }
  store = null;
};

export const getStore = () => {
  if (!store) throw new Error("Database not initialized");
  return store;
};

export const getDb = getStore;

// ─── Inquiries ───────────────────────────────────────────────────

export const dbInquiries = {
  insert(row) {
    store.inquiries.push(row);
    persist();
    return row;
  },
  get(id) {
    return store.inquiries.find((r) => r.id === id) || null;
  },
  list({
    q,
    status,
    source,
    project,
    assigned_agent,
    priority,
    from,
    to,
    limit = 500,
    offset = 0,
  } = {}) {
    let rows = [...store.inquiries];
    if (status) rows = rows.filter((r) => r.status === status);
    if (source) rows = rows.filter((r) => (r.source || "website") === source);
    if (project) rows = rows.filter((r) => (r.project || "").toLowerCase().includes(project.toLowerCase()));
    if (assigned_agent) rows = rows.filter((r) => r.assigned_agent === assigned_agent);
    if (priority) rows = rows.filter((r) => r.priority === priority);
    if (from) rows = rows.filter((r) => r.created_at >= from);
    if (to) rows = rows.filter((r) => r.created_at <= to);
    if (q) {
      const needle = q.toLowerCase();
      rows = rows.filter(
        (r) =>
          r.name?.toLowerCase().includes(needle) ||
          r.email?.toLowerCase().includes(needle) ||
          r.phone?.includes(needle) ||
          r.message?.toLowerCase().includes(needle) ||
          r.project?.toLowerCase().includes(needle) ||
          r.city?.toLowerCase().includes(needle)
      );
    }
    const sorted = rows.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
    return sorted.slice(offset, offset + limit);
  },
  countFiltered(filters = {}) {
    return this.list({ ...filters, limit: 100000 }).length;
  },
  update(id, patch) {
    const idx = store.inquiries.findIndex((r) => r.id === id);
    if (idx < 0) return null;
    store.inquiries[idx] = { ...store.inquiries[idx], ...patch, updated_at: new Date().toISOString() };
    persist();
    return store.inquiries[idx];
  },
  delete(id) {
    const before = store.inquiries.length;
    store.inquiries = store.inquiries.filter((r) => r.id !== id);
    if (store.inquiries.length !== before) persist();
  },
  count(status) {
    if (status) return store.inquiries.filter((r) => r.status === status).length;
    return store.inquiries.length;
  },
};

// ─── Email logs ────────────────────────────────────────────────────

export const dbEmailLogs = {
  insert(row) {
    const record = {
      id: nextId("email_logs"),
      delivered_at: row.status === "sent" ? new Date().toISOString() : null,
      ...row,
    };
    store.email_logs.unshift(record);
    if (store.email_logs.length > 5000) store.email_logs.length = 5000;
    persist();
    return record;
  },
  list(limit = 50) {
    return store.email_logs.slice(0, limit);
  },
  count(status) {
    if (status) return store.email_logs.filter((r) => r.status === status).length;
    return store.email_logs.length;
  },
};

// ─── WhatsApp logs ─────────────────────────────────────────────────

export const dbWhatsAppLogs = {
  insert(row) {
    const record = {
      id: nextId("whatsapp_logs"),
      delivered_at: row.status === "sent" ? new Date().toISOString() : null,
      delivery_status: row.delivery_status || row.status,
      ...row,
    };
    store.whatsapp_logs.unshift(record);
    if (store.whatsapp_logs.length > 5000) store.whatsapp_logs.length = 5000;
    persist();
    return record;
  },
  list(limit = 50) {
    return store.whatsapp_logs.slice(0, limit);
  },
  count(status) {
    if (status) return store.whatsapp_logs.filter((r) => r.status === status).length;
    return store.whatsapp_logs.length;
  },
};

// ─── Templates ─────────────────────────────────────────────────────

export const dbTemplates = {
  findByKey(key) {
    return store.email_templates.find((t) => t.key === key) || null;
  },
  findById(id) {
    return store.email_templates.find((t) => t.id === id) || null;
  },
  list() {
    return [...store.email_templates].sort((a, b) => a.name.localeCompare(b.name));
  },
  insert(row) {
    if (store.email_templates.some((t) => t.key === row.key)) return null;
    store.email_templates.push(row);
    persist();
    return row;
  },
  update(id, patch) {
    const idx = store.email_templates.findIndex((t) => t.id === id);
    if (idx < 0) return null;
    store.email_templates[idx] = { ...store.email_templates[idx], ...patch };
    persist();
    return store.email_templates[idx];
  },
};

// ─── Settings ──────────────────────────────────────────────────────

export const dbSettings = {
  all() {
    return { ...store.site_settings };
  },
  set(key, value) {
    store.site_settings[key] = String(value);
    persist();
  },
  setMany(entries) {
    for (const [key, value] of Object.entries(entries)) {
      store.site_settings[key] = String(value);
    }
    persist();
  },
};

// ─── Admin users ───────────────────────────────────────────────────

export const dbAdminUsers = {
  findByEmail(email) {
    return store.admin_users.find((u) => u.email === email.toLowerCase()) || null;
  },
  findById(id) {
    return store.admin_users.find((u) => u.id === Number(id)) || null;
  },
  list() {
    return [...store.admin_users].sort((a, b) => a.name.localeCompare(b.name));
  },
  insert(row) {
    if (dbAdminUsers.findByEmail(row.email)) return null;
    const record = {
      id: nextId("admin_users"),
      role_key: "sales_agent",
      status: "active",
      avatar_url: "",
      phone: "",
      title: "",
      permissions_override: [],
      ...row,
      email: row.email.toLowerCase(),
    };
    store.admin_users.push(record);
    persist();
    return record;
  },
  update(id, patch) {
    const idx = store.admin_users.findIndex((u) => u.id === Number(id));
    if (idx < 0) return null;
    store.admin_users[idx] = { ...store.admin_users[idx], ...patch };
    persist();
    return store.admin_users[idx];
  },
};

// ─── Audit & security logs ─────────────────────────────────────────

export const dbAuditLogs = {
  insert(row) {
    const record = { id: nextId("admin_audit_logs"), created_at: new Date().toISOString(), ...row };
    store.admin_audit_logs.unshift(record);
    if (store.admin_audit_logs.length > 2000) store.admin_audit_logs.length = 2000;
    persist();
    return record;
  },
  list(limit = 100) {
    return store.admin_audit_logs.slice(0, limit);
  },
};

export const dbSecurityLogs = {
  insert(row) {
    const record = { id: nextId("security_logs"), created_at: new Date().toISOString(), ...row };
    store.security_logs.unshift(record);
    if (store.security_logs.length > 2000) store.security_logs.length = 2000;
    persist();
    return record;
  },
  list(limit = 100) {
    return store.security_logs.slice(0, limit);
  },
};

// ─── Lead notes ────────────────────────────────────────────────────

export const dbLeadNotes = {
  insert(row) {
    const record = { id: nextId("lead_notes"), created_at: new Date().toISOString(), ...row };
    store.lead_notes.unshift(record);
    persist();
    return record;
  },
  listByLead(leadId) {
    return store.lead_notes
      .filter((n) => n.lead_id === leadId)
      .sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
  },
  delete(id) {
    store.lead_notes = store.lead_notes.filter((n) => n.id !== id);
    persist();
  },
};

// ─── Lead activities (timeline) ────────────────────────────────────

export const dbLeadActivities = {
  insert(row) {
    const record = { id: nextId("lead_activities"), created_at: new Date().toISOString(), ...row };
    store.lead_activities.unshift(record);
    if (store.lead_activities.length > 10000) store.lead_activities.length = 10000;
    persist();
    return record;
  },
  listByLead(leadId, limit = 50) {
    return store.lead_activities
      .filter((a) => a.lead_id === leadId)
      .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
      .slice(0, limit);
  },
  listRecent(limit = 30) {
    return [...store.lead_activities]
      .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
      .slice(0, limit);
  },
};

// ─── Email campaigns ─────────────────────────────────────────────────

export const dbCampaigns = {
  insert(row) {
    const record = {
      id: `camp_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      status: "draft",
      sent_count: 0,
      open_count: 0,
      click_count: 0,
      ...row,
    };
    store.email_campaigns.unshift(record);
    persist();
    return record;
  },
  get(id) {
    return store.email_campaigns.find((c) => c.id === id) || null;
  },
  list(limit = 100) {
    return store.email_campaigns.slice(0, limit);
  },
  update(id, patch) {
    const idx = store.email_campaigns.findIndex((c) => c.id === id);
    if (idx < 0) return null;
    store.email_campaigns[idx] = {
      ...store.email_campaigns[idx],
      ...patch,
      updated_at: new Date().toISOString(),
    };
    persist();
    return store.email_campaigns[idx];
  },
  delete(id) {
    store.email_campaigns = store.email_campaigns.filter((c) => c.id !== id);
    persist();
  },
};

// ─── Roles (RBAC) ──────────────────────────────────────────────────

export const dbRoles = {
  findByKey(key) {
    return store.roles.find((r) => r.key === key) || null;
  },
  list() {
    return [...store.roles].sort((a, b) => a.name.localeCompare(b.name));
  },
  insert(row) {
    if (dbRoles.findByKey(row.key)) return null;
    const record = { id: nextId("roles"), created_at: new Date().toISOString(), ...row };
    store.roles.push(record);
    persist();
    return record;
  },
  update(key, patch) {
    const idx = store.roles.findIndex((r) => r.key === key);
    if (idx < 0) return null;
    store.roles[idx] = { ...store.roles[idx], ...patch, updated_at: new Date().toISOString() };
    persist();
    return store.roles[idx];
  },
};

// ─── CMS sections ────────────────────────────────────────────────────

export const dbCmsSections = {
  findByKey(key) {
    return store.cms_sections.find((s) => s.key === key) || null;
  },
  list() {
    return [...store.cms_sections].sort((a, b) => a.key.localeCompare(b.key));
  },
  insert(row) {
    if (dbCmsSections.findByKey(row.key)) return null;
    store.cms_sections.push(row);
    persist();
    return row;
  },
  update(key, patch) {
    const idx = store.cms_sections.findIndex((s) => s.key === key);
    if (idx < 0) return null;
    store.cms_sections[idx] = { ...store.cms_sections[idx], ...patch };
    persist();
    return store.cms_sections[idx];
  },
};

// ─── CMS media ───────────────────────────────────────────────────────

export const dbCmsMedia = {
  insert(row) {
    const record = { id: nextId("cms_media"), created_at: new Date().toISOString(), ...row };
    store.cms_media.unshift(record);
    if (store.cms_media.length > 500) store.cms_media.length = 500;
    persist();
    return record;
  },
  list(limit = 100) {
    return store.cms_media.slice(0, limit);
  },
  delete(id) {
    store.cms_media = store.cms_media.filter((m) => m.id !== Number(id));
    persist();
  },
};

// ─── Properties ──────────────────────────────────────────────────────

export const dbProperties = {
  insert(row) {
    const record = {
      id: `prop_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      inquiry_count: 0,
      ...row,
    };
    store.properties.unshift(record);
    persist();
    return record;
  },
  get(idOrSlug) {
    return (
      store.properties.find((p) => p.id === idOrSlug || p.slug === idOrSlug) || null
    );
  },
  findBySlug(slug) {
    return store.properties.find((p) => p.slug === slug) || null;
  },
  findByNameMatch(name) {
    if (!name) return null;
    const n = name.toLowerCase();
    return store.properties.find((p) => p.name?.toLowerCase().includes(n)) || null;
  },
  list({ status, publish_status, featured, type, q, limit = 200, offset = 0 } = {}) {
    let rows = [...store.properties];
    if (publish_status) rows = rows.filter((p) => p.publish_status === publish_status);
    if (status) rows = rows.filter((p) => p.availability === status);
    if (featured !== undefined) rows = rows.filter((p) => Boolean(p.featured) === featured);
    if (type) rows = rows.filter((p) => p.type === type);
    if (q) {
      const needle = q.toLowerCase();
      rows = rows.filter(
        (p) =>
          p.name?.toLowerCase().includes(needle) ||
          p.location?.toLowerCase().includes(needle) ||
          p.slug?.toLowerCase().includes(needle)
      );
    }
    return rows.slice(offset, offset + limit);
  },
  update(id, patch) {
    const idx = store.properties.findIndex((p) => p.id === id);
    if (idx < 0) return null;
    store.properties[idx] = {
      ...store.properties[idx],
      ...patch,
      updated_at: new Date().toISOString(),
    };
    persist();
    return store.properties[idx];
  },
  delete(id) {
    store.properties = store.properties.filter((p) => p.id !== id);
    persist();
  },
};

// ─── Notifications ───────────────────────────────────────────────────

export const dbNotifications = {
  insert(row) {
    const record = {
      id: nextId("notifications"),
      created_at: new Date().toISOString(),
      read: false,
      ...row,
    };
    store.notifications.unshift(record);
    if (store.notifications.length > 2000) store.notifications.length = 2000;
    persist();
    return record;
  },
  list({ userId, unreadOnly, limit = 50 } = {}) {
    let rows = [...store.notifications];
    if (userId) rows = rows.filter((n) => !n.user_id || n.user_id === userId);
    if (unreadOnly) rows = rows.filter((n) => !n.read);
    return rows.slice(0, limit);
  },
  markRead(id) {
    const n = store.notifications.find((x) => x.id === Number(id));
    if (n) {
      n.read = true;
      persist();
    }
    return n;
  },
  markAllRead(userId) {
    for (const n of store.notifications) {
      if (!userId || !n.user_id || n.user_id === userId) n.read = true;
    }
    persist();
  },
  countUnread(userId) {
    return store.notifications.filter((n) => !n.read && (!userId || !n.user_id || n.user_id === userId))
      .length;
  },
};
