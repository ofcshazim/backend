import { env } from "../config/env.js";
import { dbSettings, dbAdminUsers, dbProperties } from "./database.js";
import { seedRoles } from "../services/rbac.service.js";
import { upsertCmsSection, CMS_SECTION_KEYS } from "../services/cms.service.js";
import { ROLES } from "../constants/rbac.js";
import { logger } from "../utils/logger.js";

const extendedSettings = {
  favicon_url: "",
  whatsapp_number: env.companyPhone,
  business_hours: "Mon–Sat 10:00 AM – 7:00 PM PKT",
  google_analytics_id: "",
  meta_pixel_id: "",
  google_search_console_url: "",
  smtp_host: "",
  smtp_port: "587",
  smtp_user: "",
  smtp_pass: "",
  seo_default_title: `${env.siteName} — Islamabad Property Advisors`,
  seo_default_description:
    "Trusted real estate advisory for Islamabad and Rawalpindi — verified societies, transparent guidance.",
};

const defaultCmsContent = {
  homepage_hero: {
    title: "Invest in Islamabad's Most Trusted Societies",
    subtitle: "Documented guidance for buyers and investors — no hype, no pressure.",
    cta_label: "Book a consultation",
    cta_href: "/contact",
    background_image: "",
  },
  about: {
    headline: "About Check In Property",
    body: "We help families and investors navigate Islamabad property with clarity, documentation checks, and honest comparisons.",
  },
  contact: {
    phone: env.companyPhone,
    email: env.companyEmail,
    address: env.companyAddress,
    whatsapp: env.companyPhone,
  },
  footer: {
    tagline: "Your trusted Islamabad property partner.",
    copyright: `© ${new Date().getFullYear()} ${env.siteName}`,
  },
  social: {
    facebook: "https://facebook.com/checkinproperty",
    instagram: "",
    linkedin: "",
  },
  seo_global: {
    title: extendedSettings.seo_default_title,
    description: extendedSettings.seo_default_description,
  },
  testimonials: { items: [] },
  faqs: { items: [] },
  team: { members: [] },
  cta: {
    title: "Ready to compare societies with confidence?",
    button: "Speak with an advisor",
    href: "/contact",
  },
  blogs: { items: [] },
  homepage_banners: { items: [] },
};

const defaultProperties = [
  {
    slug: "faisal-hills",
    name: "Faisal Hills",
    location: "Faisal Hills Islamabad",
    type: "Housing Society",
    status_label: "New Launch",
    availability: "available",
    price_range: "PKR 15 Lac - 95 Lac",
    payment_plan: "Installment-driven inventory",
    roi: "High growth potential over 3-5 years",
    summary: "Fast-growing residential community near major road links.",
    featured: true,
    publish_status: "published",
    img: "/assets/faisaltown.jpg",
  },
  {
    slug: "faisal-town",
    name: "Faisal Town",
    location: "Faisal Town Islamabad",
    type: "Housing Society",
    status_label: "Possession Ready",
    availability: "available",
    price_range: "PKR 35 Lac - 1.6 Crore",
    payment_plan: "Resale and possession-ready categories",
    roi: "Strong rental demand",
    summary: "Mature project with active possession and resale liquidity.",
    featured: true,
    publish_status: "published",
    img: "/assets/faisaltown.jpg",
  },
];

export const seedEnterprise = () => {
  seedRoles();

  const existing = dbSettings.all();
  for (const [key, value] of Object.entries(extendedSettings)) {
    if (!existing[key]) dbSettings.set(key, value);
  }

  for (const key of CMS_SECTION_KEYS) {
    if (!defaultCmsContent[key]) continue;
    upsertCmsSection(
      key,
      {
        title: key.replace(/_/g, " "),
        content: defaultCmsContent[key],
        draft_content: defaultCmsContent[key],
        status: "published",
      },
      { email: "system" }
    );
  }

  for (const prop of defaultProperties) {
    if (!dbProperties.findBySlug(prop.slug)) {
      dbProperties.insert({
        ...prop,
        features: [],
        gallery: prop.img ? [prop.img] : [],
        floor_plans: [],
        created_at: new Date().toISOString(),
      });
    }
  }

  const admin = dbAdminUsers.findByEmail(env.admin.email.toLowerCase());
  if (admin && !admin.role_key) {
    dbAdminUsers.update(admin.id, { role_key: ROLES.SUPER_ADMIN, status: "active" });
  }

  logger.info("[DB] Enterprise seed complete (roles, CMS, properties, settings)");
};
