import bcrypt from "bcryptjs";
import { env } from "../config/env.js";
import { dbTemplates, dbSettings, dbAdminUsers } from "./database.js";
import { seedEnterprise } from "./seed-enterprise.js";
import { ROLES } from "../constants/rbac.js";
import { logger } from "../utils/logger.js";
import { wrapBrandedEmail, escapeHtml } from "../templates/email/layout.js";

const defaultTemplates = () => [
  {
    id: "tpl_admin_inquiry",
    key: "admin_inquiry",
    name: "Admin — New inquiry",
    subject: "New Website Inquiry Received",
    category: "transactional",
    html: wrapBrandedEmail({
      title: "New property inquiry",
      preheader: "New lead from website",
      bodyHtml: `<p style="margin:0 0 16px;font-size:15px;line-height:1.6;">A new inquiry was submitted on your website.</p>
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f4f8f6;border-radius:8px;padding:16px;">
          <tr><td style="padding:8px 0;font-size:13px;color:#5c6b66;">Name</td><td style="padding:8px 0;font-size:14px;font-weight:600;">{{name}}</td></tr>
          <tr><td style="padding:8px 0;font-size:13px;color:#5c6b66;">Phone</td><td style="padding:8px 0;font-size:14px;">{{phone}}</td></tr>
          <tr><td style="padding:8px 0;font-size:13px;color:#5c6b66;">Email</td><td style="padding:8px 0;font-size:14px;">{{email}}</td></tr>
          <tr><td style="padding:8px 0;font-size:13px;color:#5c6b66;">Project</td><td style="padding:8px 0;font-size:14px;">{{project}}</td></tr>
          <tr><td style="padding:8px 0;font-size:13px;color:#5c6b66;">Budget</td><td style="padding:8px 0;font-size:14px;">{{budget}}</td></tr>
          <tr><td style="padding:8px 0;font-size:13px;color:#5c6b66;">Timeline</td><td style="padding:8px 0;font-size:14px;">{{timeline}}</td></tr>
          <tr><td style="padding:8px 0;font-size:13px;color:#5c6b66;">Source</td><td style="padding:8px 0;font-size:14px;">{{source}}</td></tr>
        </table>
        <p style="margin:20px 0 8px;font-size:14px;font-weight:600;">Message</p>
        <p style="margin:0;font-size:14px;line-height:1.6;color:#1a2e28;">{{message}}</p>
        <p style="margin:16px 0 0;font-size:12px;color:#8a9a94;">Reference: {{inquiry_id}} · {{submitted_at}}</p>`,
    }),
  },
  {
    id: "tpl_autoreply",
    key: "customer_autoreply",
    name: "Customer — Auto reply",
    subject: `We received your inquiry — ${env.siteName}`,
    category: "transactional",
    html: wrapBrandedEmail({
      title: "Thank you for reaching out",
      preheader: "We will respond within one business day",
      bodyHtml: `<p style="margin:0 0 16px;font-size:15px;line-height:1.6;">Hi {{name}},</p>
        <p style="margin:0 0 16px;font-size:15px;line-height:1.6;">Thank you for contacting <strong>${escapeHtml(env.siteName)}</strong>. We have received your inquiry regarding <strong>{{project}}</strong> and a property advisor will respond within one business day.</p>
        <p style="margin:0;font-size:14px;color:#5c6b66;">Reference: {{inquiry_id}}</p>`,
      cta: { href: env.siteUrl, label: "Explore our projects" },
    }),
  },
  {
    id: "tpl_welcome",
    key: "welcome",
    name: "Welcome email",
    subject: `Welcome to ${env.siteName}`,
    category: "marketing",
    html: wrapBrandedEmail({
      title: "Welcome",
      preheader: "Your trusted Islamabad property partner",
      bodyHtml: `<p style="margin:0;font-size:15px;line-height:1.6;">Hi {{name}}, welcome to ${escapeHtml(env.siteName)}. We help buyers in Islamabad and Rawalpindi make documented, confident property decisions.</p>`,
    }),
  },
  {
    id: "tpl_lead_confirm",
    key: "lead_confirmation",
    name: "Lead confirmation",
    subject: "Your property inquiry is confirmed",
    category: "transactional",
    html: wrapBrandedEmail({
      title: "Inquiry confirmed",
      preheader: "Your request is in our queue",
      bodyHtml: `<p style="margin:0;font-size:15px;line-height:1.6;">Hi {{name}}, your inquiry regarding <strong>{{project}}</strong> has been logged. Reference: <strong>{{inquiry_id}}</strong></p>`,
    }),
  },
  {
    id: "tpl_promo",
    key: "promotional",
    name: "Promotional update",
    subject: "Property opportunities in Islamabad",
    category: "marketing",
    html: wrapBrandedEmail({
      title: "Curated societies on our radar",
      preheader: "Premium opportunities for investors",
      bodyHtml: `<p style="margin:0;font-size:15px;line-height:1.6;">Hi {{name}}, here are societies we are comparing this month with strong documentation profiles.</p>`,
      cta: { href: `${env.siteUrl}/contact`, label: "Book a consultation" },
    }),
  },
  {
    id: "tpl_internal",
    key: "internal_copy",
    name: "Internal — Inquiry archive",
    subject: `[Archive] Website inquiry — {{name}}`,
    category: "internal",
    html: wrapBrandedEmail({
      title: "Internal inquiry copy",
      preheader: "Archived for records",
      bodyHtml: `<p style="margin:0 0 12px;font-size:14px;">This is an internal copy of a website submission.</p>
        <p style="margin:0;font-size:14px;line-height:1.6;"><strong>{{name}}</strong> · {{phone}} · {{email}}<br/>{{message}}</p>`,
    }),
  },
];

const defaultSettings = {
  site_name: env.siteName,
  site_url: env.siteUrl,
  company_phone: env.companyPhone,
  company_email: env.companyEmail,
  company_address: env.companyAddress,
  logo_url: env.logoUrl,
  facebook: "https://facebook.com/checkinproperty",
  instagram: "",
  linkedin: "",
  crm_agents: JSON.stringify(["Administrator", "Sales Agent 1"]),
};

export const seedDatabase = () => {
  const now = new Date().toISOString();

  for (const tpl of defaultTemplates()) {
    if (!dbTemplates.findByKey(tpl.key)) {
      dbTemplates.insert({ ...tpl, updated_at: now });
    }
  }

  const existing = dbSettings.all();
  for (const [key, value] of Object.entries(defaultSettings)) {
    if (!existing[key]) dbSettings.set(key, value);
  }

  if (!dbAdminUsers.findByEmail(env.admin.email)) {
    const hash = bcrypt.hashSync(env.admin.password, 12);
    dbAdminUsers.insert({
      email: env.admin.email.toLowerCase(),
      password_hash: hash,
      name: env.admin.name,
      role_key: ROLES.SUPER_ADMIN,
      status: "active",
      created_at: now,
    });
    logger.info("[DB] Default admin user created", { email: env.admin.email });
  }

  seedEnterprise();
};
