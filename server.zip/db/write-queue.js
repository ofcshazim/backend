/** Serializes all JSON DB writes to prevent concurrent corruption. */
let chain = Promise.resolve();

export const runExclusive = async (fn) => {
  const result = chain.then(() => fn());
  chain = result.then(
    () => undefined,
    () => undefined
  );
  return result;
};

export const flushQueue = () => chain;
