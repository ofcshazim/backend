/**
 * PM2 production config — run from server/:
 *   npm install -g pm2
 *   cd server && pm2 start ecosystem.config.cjs
 *   pm2 save && pm2 startup
 */
const clusterMode = process.env.CLUSTER_MODE === "true";

module.exports = {
  apps: [
    {
      name: "checkinproperty-api",
      script: "index.js",
      cwd: __dirname,
      exec_mode: clusterMode ? "cluster" : "fork",
      instances: clusterMode ? "max" : 1,
      autorestart: true,
      watch: false,
      max_memory_restart: "400M",
      min_uptime: "10s",
      max_restarts: 15,
      restart_delay: 3000,
      listen_timeout: 10000,
      kill_timeout: 10000,
      merge_logs: true,
      time: true,
      error_file: "./logs/pm2-error.log",
      out_file: "./logs/pm2-out.log",
      env: {
        NODE_ENV: "production",
        HOST: "0.0.0.0",
        PORT: "12176",
      },
      env_production: {
        NODE_ENV: "production",
        HOST: "0.0.0.0",
        PORT: "12176",
      },
    },
  ],
};
