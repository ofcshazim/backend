import { createApp } from "./app.js";
import { env, isSmtpConfigured, isWhatsAppConfigured } from "./config/env.js";
import { logger } from "./utils/logger.js";
import { bootstrapCore, bootstrapIntegrations, shutdown } from "./bootstrap.js";
import { printStartupBanner, API_VERSION } from "./utils/banner.js";
import { acquireProcessLock, detectPortConflict } from "./utils/port-lock.js";

let server = null;
let lockCleanup = null;
let shuttingDown = false;

const publicBase =
  process.env.API_PUBLIC_URL?.replace(/\/api\/?$/, "") || `http://93.115.101.102:${env.port}`;

const start = async () => {
  try {
    const portCheck = await detectPortConflict(env.host, env.port);
    if (!portCheck.available) {
      logger.error("[BOOT] Port conflict", portCheck);
      console.error("\n" + portCheck.message + "\n");
      process.exit(1);
    }

    lockCleanup = acquireProcessLock({ version: API_VERSION, port: env.port });
    bootstrapCore();

    const app = createApp();

    server = app.listen(env.port, env.host, () => {
      printStartupBanner();
      logger.info("[BOOT] Server listening", {
        bind: `${env.host}:${env.port}`,
        publicHealth: `${publicBase}/api/health`,
        publicAdmin: `${publicBase}/api/admin/login`,
        smtp: isSmtpConfigured(),
        whatsapp: isWhatsAppConfigured(),
      });

      bootstrapIntegrations()
        .then(({ smtpOk, wapiOk }) => {
          logger.info("[BOOT] Integrations ready", { smtpOk, wapiOk });
        })
        .catch((err) => {
          logger.error("[BOOT] Integration bootstrap failed", {
            error: err.message,
            stack: err.stack,
          });
        });
    });

    server.on("error", (err) => {
      if (err.code === "EADDRINUSE") {
        logger.error("[BOOT] Port already in use", { port: env.port });
      } else {
        logger.error("[BOOT] Server failed to start", { error: err.message });
      }
      process.exit(1);
    });
  } catch (err) {
    logger.error("[BOOT] Startup failed", { error: err.message, stack: err.stack });
    process.exit(1);
  }
};

const gracefulShutdown = async (signal) => {
  if (shuttingDown) return;
  shuttingDown = true;
  logger.info(`[BOOT] ${signal} received — graceful shutdown`);

  const forceTimer = setTimeout(() => {
    logger.error("[BOOT] Forced exit after timeout");
    process.exit(1);
  }, 15000);
  forceTimer.unref?.();

  if (server) {
    server.close(async () => {
      try {
        await shutdown();
        lockCleanup?.();
        clearTimeout(forceTimer);
        process.exit(0);
      } catch (err) {
        logger.error("[BOOT] Shutdown error", { error: err.message });
        process.exit(1);
      }
    });
  } else {
    await shutdown();
    lockCleanup?.();
    process.exit(0);
  }
};

process.on("SIGTERM", () => gracefulShutdown("SIGTERM"));
process.on("SIGINT", () => gracefulShutdown("SIGINT"));
process.on("uncaughtException", (err) => {
  logger.error("[BOOT] Uncaught exception — exiting for PM2 restart", {
    error: err.message,
    stack: err.stack,
  });
  process.exit(1);
});
process.on("unhandledRejection", (err) => {
  logger.error("[BOOT] Unhandled rejection", { error: err?.message || String(err) });
});

start();
