import { logSuspiciousRequest } from "../services/security.service.js";

const BOT_PATTERNS = [/curl/i, /python-requests/i, /scrapy/i, /httpclient/i];

export const antiBotMiddleware = (req, res, next) => {
  const ua = req.headers["user-agent"] || "";
  if (!ua && req.method === "POST") {
    logSuspiciousRequest(req, "missing_user_agent");
    return res.status(400).json({ success: false, message: "Invalid request." });
  }

  if (BOT_PATTERNS.some((p) => p.test(ua)) && req.path.includes("/admin")) {
    logSuspiciousRequest(req, "bot_user_agent");
  }

  next();
};
