import { logAdminAction } from "../services/audit.service.js";

export const auditAdminMutation = (action) => (req, res, next) => {
  const originalJson = res.json.bind(res);
  res.json = (body) => {
    if (res.statusCode < 400) {
      logAdminAction(req, action, { status: res.statusCode });
    }
    return originalJson(body);
  };
  next();
};
