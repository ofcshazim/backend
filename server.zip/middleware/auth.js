import { getSession } from "../services/session.service.js";
import { logger } from "../utils/logger.js";
import { env } from "../config/env.js";

export const requireAdmin = (req, res, next) => {
  const sessionId =
    req.headers["x-session-id"]?.toString().trim() ||
    req.headers["X-Session-Id"]?.toString().trim();

  const session = getSession(sessionId);

  if (!session) {
    if (env.nodeEnv !== "production" || process.env.AUTH_DEBUG === "true") {
      logger.warn("[AUTH] Session rejected", {
        path: req.path,
        hasHeader: Boolean(sessionId),
        prefix: sessionId ? sessionId.slice(0, 8) : null,
      });
    }
    return res.status(401).json({
      success: false,
      message: "Session expired or invalid. Please sign in again.",
      code: "AUTH_REQUIRED",
    });
  }

  req.admin = {
    id: session.userId,
    email: session.email,
    name: session.name,
    role_key: session.role_key,
    permissions: session.permissions || [],
    avatar_url: session.avatar_url,
  };
  next();
};
