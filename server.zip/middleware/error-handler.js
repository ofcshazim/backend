import { ZodError } from "zod";
import { logger } from "../utils/logger.js";
import { env } from "../config/env.js";

export const notFoundHandler = (req, res) => {
  res.status(404).json({
    success: false,
    message: `Route not found: ${req.method} ${req.originalUrl}`,
  });
};

export const errorHandler = (err, req, res, _next) => {
  logger.error(err.message, {
    stack: env.nodeEnv === "development" ? err.stack : undefined,
    path: req.originalUrl,
  });

  if (err instanceof ZodError) {
    return res.status(400).json({
      success: false,
      message: "Please check your form fields and try again.",
      errors: err.flatten().fieldErrors,
    });
  }

  if (err.code === "SMTP_NOT_CONFIGURED") {
    return res.status(503).json({
      success: false,
      message: "Contact service is temporarily unavailable.",
    });
  }

  const status = err.statusCode || err.status || 500;
  res.status(status).json({
    success: false,
    message:
      status === 500
        ? "Something went wrong. Please try again later."
        : err.message || "Request failed.",
  });
};
