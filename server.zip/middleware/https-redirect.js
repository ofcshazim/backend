import { env } from "../config/env.js";

export const httpsRedirectMiddleware = (req, res, next) => {
  if (env.nodeEnv !== "production") return next();

  const proto = req.headers["x-forwarded-proto"];
  if (proto && proto !== "https") {
    const host = req.headers.host;
    return res.redirect(301, `https://${host}${req.originalUrl}`);
  }
  next();
};
