import { getClientIp, isIpBanned, logSuspiciousRequest } from "../services/security.service.js";

export const ipBanMiddleware = (req, res, next) => {
  const ip = getClientIp(req);
  if (isIpBanned(ip)) {
    logSuspiciousRequest(req, "banned_ip");
    return res.status(403).json({
      success: false,
      message: "Access temporarily blocked due to suspicious activity.",
    });
  }
  req.clientIp = ip;
  next();
};
