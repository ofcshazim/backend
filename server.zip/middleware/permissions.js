import { userHasPermission } from "../services/rbac.service.js";
import { resolveAdminUser } from "../utils/admin-user.js";
import { logger } from "../utils/logger.js";

const loadFullUser = (req) => {
  if (req.adminUser) return req.adminUser;
  const user = resolveAdminUser(req);
  if (user) {
    req.adminUser = user;
    return user;
  }
  return null;
};

export const requirePermission =
  (...permissions) =>
  (req, res, next) => {
    const user = loadFullUser(req);
    if (!user) {
      return res.status(401).json({ success: false, message: "Not authenticated.", code: "AUTH_REQUIRED" });
    }
    if (user.status === "suspended") {
      return res.status(403).json({ success: false, message: "Account suspended." });
    }
    const allowed = permissions.some((p) => userHasPermission(user, p));
    if (!allowed) {
      logger.warn("[AUTH] Permission denied", {
        email: user.email,
        role: user.role_key,
        required: permissions,
        path: req.originalUrl,
      });
      return res.status(403).json({
        success: false,
        message: "You do not have permission for this action.",
        code: "FORBIDDEN",
        required: permissions,
      });
    }
    next();
  };

export const attachPermissions = (req, _res, next) => {
  const user = loadFullUser(req);
  if (user && req.admin) {
    req.admin.permissions = user.permissions;
    req.admin.role_key = user.role_key;
  }
  next();
};
