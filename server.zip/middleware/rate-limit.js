import rateLimit from "express-rate-limit";
import { env } from "../config/env.js";

const skipInDev = () => env.nodeEnv === "development";

export const contactRateLimit = rateLimit({
  windowMs: env.rateLimitWindowMs,
  max: env.rateLimitMax,
  standardHeaders: true,
  legacyHeaders: false,
  skip: skipInDev,
  message: {
    success: false,
    message: "Too many requests. Please wait a few minutes and try again.",
  },
});

const skipHealth = (req) =>
  req.path === "/health" ||
  req.path === "/ready" ||
  req.path === "/health/details" ||
  req.originalUrl === "/api/health";

export const apiRateLimit = rateLimit({
  windowMs: 60 * 1000,
  max: 200,
  standardHeaders: true,
  legacyHeaders: false,
  skip: (req) => skipInDev() || skipHealth(req),
});

export const adminLoginRateLimit = rateLimit({
  windowMs: 10 * 60 * 1000,
  max: 30,
  standardHeaders: true,
  legacyHeaders: false,
  skip: skipInDev,
  message: {
    success: false,
    message: "Too many login attempts. Please try again later.",
  },
});
