import crypto from "crypto";

export const requestIdMiddleware = (req, res, next) => {
  const id = req.headers["x-request-id"]?.toString() || crypto.randomUUID();
  req.id = id;
  res.setHeader("X-Request-Id", id);
  next();
};
