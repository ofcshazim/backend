import { logger } from "../utils/logger.js";

export const requestLogger = (req, res, next) => {
  const start = Date.now();
  res.on("finish", () => {
    logger.access(`${req.method} ${req.originalUrl}`, {
      requestId: req.id,
      status: res.statusCode,
      ms: Date.now() - start,
      ip: req.clientIp || req.ip,
    });
  });
  next();
};
