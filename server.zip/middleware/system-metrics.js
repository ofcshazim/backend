import { recordRequest } from "../services/system-monitor.service.js";

export const systemMetricsMiddleware = (req, res, next) => {
  const start = Date.now();
  res.on("finish", () => {
    recordRequest(req, res, Date.now() - start);
  });
  next();
};
