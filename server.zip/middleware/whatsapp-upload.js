import fs from "fs";
import path from "path";
import crypto from "crypto";
import multer from "multer";
import { env } from "../config/env.js";

const UPLOAD_DIR = path.join(process.cwd(), "uploads", "whatsapp");
const ALLOWED_MIME = new Set([
  "application/pdf",
  "image/jpeg",
  "image/jpg",
  "image/png",
  "image/webp",
  "video/mp4",
]);

const ALLOWED_EXT = new Set([".pdf", ".jpg", ".jpeg", ".png", ".webp", ".mp4"]);

export const ensureWhatsAppUploadDir = () => {
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
};

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    ensureWhatsAppUploadDir();
    cb(null, UPLOAD_DIR);
  },
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase() || ".bin";
    const safe = `${Date.now()}-${crypto.randomBytes(6).toString("hex")}${ext}`;
    cb(null, safe.replace(/[^a-z0-9._-]/gi, "-"));
  },
});

const fileFilter = (_req, file, cb) => {
  const ext = path.extname(file.originalname).toLowerCase();
  if (!ALLOWED_MIME.has(file.mimetype) && !ALLOWED_EXT.has(ext)) {
    return cb(new Error("Invalid file type. Allowed: PDF, JPG, PNG, WEBP, MP4"));
  }
  cb(null, true);
};

export const whatsappUpload = multer({
  storage,
  limits: { fileSize: 25 * 1024 * 1024 },
  fileFilter,
});

export const buildPublicUploadUrl = (filename) => {
  const origin = env.apiPublicUrl.replace(/\/api\/?$/, "");
  return `${origin}/uploads/whatsapp/${filename}`;
};

export const getUploadMeta = (file) => ({
  filename: file.filename,
  original_name: file.originalname,
  mime_type: file.mimetype,
  size_bytes: file.size,
  url: buildPublicUploadUrl(file.filename),
});
