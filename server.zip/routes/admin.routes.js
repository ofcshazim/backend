import { Router } from "express";
import { asyncHandler } from "../utils/async-handler.js";
import { requireAdmin } from "../middleware/auth.js";
import { attachPermissions } from "../middleware/permissions.js";
import enterpriseRoutes from "./enterprise.routes.js";
import {
  adminLogin,
  adminLogout,
  adminProfile,
  adminDashboard,
  adminListInquiries,
  adminPatchInquiry,
  adminRemoveInquiry,
  adminListTemplates,
  adminPutTemplate,
  adminPreviewTemplate,
  adminSendEmail,
  adminEmailLogs,
  adminResendEmail,
  adminSendWhatsApp,
  adminWhatsAppLogs,
  adminWhatsAppTemplates,
  adminGetSettings,
  adminPutSettings,
  adminSystemStatus,
  adminActivity,
} from "../controllers/admin.controller.js";
import { auditAdminMutation } from "../middleware/audit.js";
import { adminLoginRateLimit } from "../middleware/rate-limit.js";
import crmRoutes from "./crm.routes.js";

const router = Router();

// Public auth
router.post("/login", adminLoginRateLimit, asyncHandler(adminLogin));

// Protected — everything below requires session
router.use(requireAdmin);
router.use(attachPermissions);
router.use(enterpriseRoutes);
router.get("/auth/check", asyncHandler(adminProfile));
router.post("/logout", asyncHandler(adminLogout));
router.get("/profile", asyncHandler(adminProfile));
router.get("/system-status", asyncHandler(adminSystemStatus));
router.get("/activity", asyncHandler(adminActivity));
router.get("/dashboard", asyncHandler(adminDashboard));
router.get("/inquiries", asyncHandler(adminListInquiries));
router.patch("/inquiries/:id", asyncHandler(adminPatchInquiry));
router.delete("/inquiries/:id", asyncHandler(adminRemoveInquiry));
router.get("/templates", asyncHandler(adminListTemplates));
router.put("/templates/:id", asyncHandler(adminPutTemplate));
router.post("/templates/:id/preview", asyncHandler(adminPreviewTemplate));

// Email — canonical + alias paths
router.post("/email/send", auditAdminMutation("email_send"), asyncHandler(adminSendEmail));
router.post("/send-email", auditAdminMutation("email_send"), asyncHandler(adminSendEmail));
router.get("/email/logs", asyncHandler(adminEmailLogs));
router.post("/email/resend", asyncHandler(adminResendEmail));

// WhatsApp — canonical + alias paths
router.post("/whatsapp/send", auditAdminMutation("whatsapp_send"), asyncHandler(adminSendWhatsApp));
router.post("/send-whatsapp", auditAdminMutation("whatsapp_send"), asyncHandler(adminSendWhatsApp));
router.get("/whatsapp/logs", asyncHandler(adminWhatsAppLogs));
router.get("/whatsapp/templates", asyncHandler(adminWhatsAppTemplates));

router.get("/settings", asyncHandler(adminGetSettings));
router.put("/settings", asyncHandler(adminPutSettings));

router.use("/crm", crmRoutes);

export default router;
