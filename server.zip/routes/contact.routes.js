import { Router } from "express";
import { submitContact } from "../controllers/contact.controller.js";
import { contactRateLimit } from "../middleware/rate-limit.js";
import { asyncHandler } from "../utils/async-handler.js";

const router = Router();

router.post("/contact", contactRateLimit, asyncHandler(submitContact));

export default router;
