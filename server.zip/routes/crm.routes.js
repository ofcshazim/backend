import { Router } from "express";
import { asyncHandler } from "../utils/async-handler.js";
import { requirePermission } from "../middleware/permissions.js";
import { PERMISSIONS } from "../constants/rbac.js";
import { auditAdminMutation } from "../middleware/audit.js";
// CRM mounted under /api/admin (already session-protected)
import {
  crmMeta,
  crmListLeads,
  crmGetLead,
  crmUpdateLead,
  crmDeleteLead,
  crmAddNote,
  crmDeleteNote,
  crmPipeline,
  crmAnalytics,
  crmMonthlyReport,
  crmExportCsv,
  crmExportExcel,
  crmExportPdf,
  crmListCampaigns,
  crmGetCampaign,
  crmCreateCampaign,
  crmUpdateCampaign,
  crmDeleteCampaign,
  crmSendCampaign,
  crmTestEmail,
} from "../controllers/crm.controller.js";

const router = Router();

const campaignPerm = requirePermission(PERMISSIONS.MANAGE_CAMPAIGNS, PERMISSIONS.VIEW_LEADS);

router.get("/meta", requirePermission(PERMISSIONS.VIEW_LEADS, PERMISSIONS.MANAGE_CAMPAIGNS), asyncHandler(crmMeta));

router.get("/campaigns", campaignPerm, asyncHandler(crmListCampaigns));
router.post("/campaigns", campaignPerm, auditAdminMutation("crm_create_campaign"), asyncHandler(crmCreateCampaign));
router.get("/campaigns/:id", campaignPerm, asyncHandler(crmGetCampaign));
router.patch("/campaigns/:id", campaignPerm, auditAdminMutation("crm_update_campaign"), asyncHandler(crmUpdateCampaign));
router.delete("/campaigns/:id", campaignPerm, asyncHandler(crmDeleteCampaign));
router.post("/campaigns/:id/send", campaignPerm, auditAdminMutation("crm_send_campaign"), asyncHandler(crmSendCampaign));
router.post("/campaigns/test", campaignPerm, auditAdminMutation("crm_test_email"), asyncHandler(crmTestEmail));

router.use(requirePermission(PERMISSIONS.VIEW_LEADS));

router.get("/leads", asyncHandler(crmListLeads));
router.get("/leads/export/csv", asyncHandler(crmExportCsv));
router.get("/leads/export/excel", asyncHandler(crmExportExcel));
router.get("/leads/export/pdf", asyncHandler(crmExportPdf));
router.get("/leads/:id", asyncHandler(crmGetLead));
router.patch("/leads/:id", auditAdminMutation("crm_update_lead"), asyncHandler(crmUpdateLead));
router.delete("/leads/:id", auditAdminMutation("crm_delete_lead"), asyncHandler(crmDeleteLead));
router.post("/leads/:id/notes", auditAdminMutation("crm_add_note"), asyncHandler(crmAddNote));
router.delete("/leads/:id/notes/:noteId", asyncHandler(crmDeleteNote));

router.get("/pipeline", asyncHandler(crmPipeline));
router.get("/analytics", asyncHandler(crmAnalytics));
router.get("/reports/monthly", asyncHandler(crmMonthlyReport));

export default router;
