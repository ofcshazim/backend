import { Router } from "express";
import { asyncHandler } from "../utils/async-handler.js";
import { requirePermission } from "../middleware/permissions.js";
import { PERMISSIONS } from "../constants/rbac.js";
import {
  teamList,
  teamGet,
  teamCreate,
  teamUpdate,
  teamResetPassword,
  teamSuspend,
  teamReactivate,
  rolesList,
  rolesUpdate,
  cmsList,
  cmsGet,
  cmsPut,
  cmsPublish,
  cmsMediaList,
  cmsMediaUpload,
  cmsMediaDelete,
  propertiesList,
  propertiesGet,
  propertiesCreate,
  propertiesUpdate,
  propertiesDelete,
  notificationsList,
  notificationsRead,
  notificationsReadAll,
  analyticsDashboard,
  analyticsSocial,
  auditList,
  settingsGetExtended,
  settingsPutExtended,
} from "../controllers/enterprise.controller.js";

const router = Router();

// Team & RBAC
router.get("/team", requirePermission(PERMISSIONS.MANAGE_USERS), asyncHandler(teamList));
router.get("/team/:id", requirePermission(PERMISSIONS.MANAGE_USERS), asyncHandler(teamGet));
router.post("/team", requirePermission(PERMISSIONS.MANAGE_USERS), asyncHandler(teamCreate));
router.patch("/team/:id", requirePermission(PERMISSIONS.MANAGE_USERS), asyncHandler(teamUpdate));
router.post("/team/:id/reset-password", requirePermission(PERMISSIONS.MANAGE_USERS), asyncHandler(teamResetPassword));
router.post("/team/:id/suspend", requirePermission(PERMISSIONS.MANAGE_USERS), asyncHandler(teamSuspend));
router.post("/team/:id/reactivate", requirePermission(PERMISSIONS.MANAGE_USERS), asyncHandler(teamReactivate));
router.get("/roles", requirePermission(PERMISSIONS.MANAGE_USERS), asyncHandler(rolesList));
router.put("/roles/:key", requirePermission(PERMISSIONS.MANAGE_USERS), asyncHandler(rolesUpdate));

// CMS
router.get("/cms", requirePermission(PERMISSIONS.EDIT_WEBSITE), asyncHandler(cmsList));
router.get("/cms/:key", requirePermission(PERMISSIONS.EDIT_WEBSITE), asyncHandler(cmsGet));
router.put("/cms/:key", requirePermission(PERMISSIONS.EDIT_WEBSITE), asyncHandler(cmsPut));
router.post("/cms/:key/publish", requirePermission(PERMISSIONS.EDIT_WEBSITE), asyncHandler(cmsPublish));
router.get("/media", requirePermission(PERMISSIONS.EDIT_WEBSITE), asyncHandler(cmsMediaList));
router.post("/media/upload", requirePermission(PERMISSIONS.EDIT_WEBSITE), asyncHandler(cmsMediaUpload));
router.delete("/media/:id", requirePermission(PERMISSIONS.EDIT_WEBSITE), asyncHandler(cmsMediaDelete));

// Properties
router.get("/properties", requirePermission(PERMISSIONS.MANAGE_PROPERTIES, PERMISSIONS.VIEW_LEADS), asyncHandler(propertiesList));
router.get("/properties/:id", requirePermission(PERMISSIONS.MANAGE_PROPERTIES, PERMISSIONS.VIEW_LEADS), asyncHandler(propertiesGet));
router.post("/properties", requirePermission(PERMISSIONS.MANAGE_PROPERTIES), asyncHandler(propertiesCreate));
router.patch("/properties/:id", requirePermission(PERMISSIONS.MANAGE_PROPERTIES), asyncHandler(propertiesUpdate));
router.delete("/properties/:id", requirePermission(PERMISSIONS.MANAGE_PROPERTIES), asyncHandler(propertiesDelete));

// Notifications (all authenticated users with manage_notifications or view_leads)
router.get(
  "/notifications",
  requirePermission(PERMISSIONS.MANAGE_NOTIFICATIONS, PERMISSIONS.VIEW_LEADS, PERMISSIONS.MANAGE_USERS),
  asyncHandler(notificationsList)
);
router.post(
  "/notifications/:id/read",
  requirePermission(PERMISSIONS.MANAGE_NOTIFICATIONS, PERMISSIONS.VIEW_LEADS, PERMISSIONS.MANAGE_USERS),
  asyncHandler(notificationsRead)
);
router.post(
  "/notifications/read-all",
  requirePermission(PERMISSIONS.MANAGE_NOTIFICATIONS, PERMISSIONS.VIEW_LEADS, PERMISSIONS.MANAGE_USERS),
  asyncHandler(notificationsReadAll)
);

// Analytics
router.get("/analytics", requirePermission(PERMISSIONS.ANALYTICS), asyncHandler(analyticsDashboard));
router.get("/analytics/social", requirePermission(PERMISSIONS.ANALYTICS), asyncHandler(analyticsSocial));

// Audit
router.get("/audit", requirePermission(PERMISSIONS.VIEW_AUDIT), asyncHandler(auditList));

// Extended settings
router.get("/settings/extended", requirePermission(PERMISSIONS.SETTINGS), asyncHandler(settingsGetExtended));
router.put("/settings/extended", requirePermission(PERMISSIONS.SETTINGS), asyncHandler(settingsPutExtended));

export default router;
