import { Router } from "express";
import { getHealth, getHealthDetails, getReady } from "../controllers/health.controller.js";

const router = Router();

router.get("/health", getHealth);
router.get("/health/details", getHealthDetails);
router.get("/ready", getReady);

export default router;
