import { Router } from "express";
import healthRoutes from "./health.routes.js";
import contactRoutes from "./contact.routes.js";
import adminRoutes from "./admin.routes.js";
import publicRoutes from "./public.routes.js";

const router = Router();

router.get("/", (_req, res) => {
  res.json({
    success: true,
    message: "Check In Property API Running",
    version: "3.0.0",
    health: "/api/health",
    admin: "/api/admin/login",
  });
});

router.use(healthRoutes);
router.use(contactRoutes);
router.use(publicRoutes);
router.use("/admin", adminRoutes);

export default router;
