import { Router } from "express";
import { asyncHandler } from "../utils/async-handler.js";
import { getAllPublishedContent } from "../services/cms.service.js";
import { listPublishedProperties } from "../services/property.service.js";
import { getAllSettings } from "../services/settings.service.js";

const router = Router();

router.get("/cms", asyncHandler((_req, res) => {
  res.json({ success: true, content: getAllPublishedContent() });
}));

router.get("/properties", asyncHandler((_req, res) => {
  res.json({ success: true, properties: listPublishedProperties() });
}));

router.get("/site", asyncHandler((_req, res) => {
  const settings = getAllSettings();
  res.json({
    success: true,
    site: {
      name: settings.site_name,
      url: settings.site_url,
      phone: settings.company_phone,
      email: settings.company_email,
      address: settings.company_address,
      logo: settings.logo_url,
      favicon: settings.favicon_url,
      social: {
        facebook: settings.facebook,
        instagram: settings.instagram,
        linkedin: settings.linkedin,
        whatsapp: settings.whatsapp_number,
      },
      hours: settings.business_hours,
    },
  });
}));

export default router;
