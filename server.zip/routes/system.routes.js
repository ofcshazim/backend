import { Router } from "express";
import { requireAdmin } from "../middleware/auth.js";
import {
  systemHealth,
  systemPing,
  systemStats,
  systemUptime,
  systemAuthkeyStatus,
  systemErrors,
} from "../controllers/system.controller.js";

const router = Router();

router.use(requireAdmin);

router.get("/health", systemHealth);
router.get("/ping", systemPing);
router.get("/stats", systemStats);
router.get("/uptime", systemUptime);
router.get("/authkey-status", systemAuthkeyStatus);
router.get("/errors", systemErrors);

export default router;
