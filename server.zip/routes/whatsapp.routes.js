import { Router } from "express";
import rateLimit from "express-rate-limit";
import { asyncHandler } from "../utils/async-handler.js";
import { requireAdmin } from "../middleware/auth.js";
import { whatsappUpload } from "../middleware/whatsapp-upload.js";
import {
  whatsappDashboard,
  whatsappBalance,
  whatsappSend,
  whatsappSendMedia,
  whatsappBulkSend,
  whatsappSchedule,
  whatsappHistory,
  whatsappCampaigns,
  whatsappCreateCampaign,
  whatsappUpdateCampaign,
  whatsappDuplicateCampaign,
  whatsappTemplates,
  whatsappSaveTemplate,
  whatsappDeleteTemplate,
  whatsappContacts,
  whatsappCreateContact,
  whatsappUpdateContact,
  whatsappDeleteContact,
  whatsappImportContacts,
  whatsappExportContacts,
  whatsappUpload as whatsappUploadHandler,
  whatsappMediaList,
  whatsappScheduledList,
} from "../controllers/whatsapp.controller.js";

const router = Router();

const whatsappRateLimit = rateLimit({
  windowMs: 60 * 1000,
  max: 60,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: "Too many WhatsApp requests. Please wait." },
});

router.use(requireAdmin);
router.use(whatsappRateLimit);

router.get("/dashboard", asyncHandler(whatsappDashboard));
router.get("/balance", asyncHandler(whatsappBalance));
router.get("/history", asyncHandler(whatsappHistory));
router.get("/campaigns", asyncHandler(whatsappCampaigns));
router.post("/campaigns", asyncHandler(whatsappCreateCampaign));
router.patch("/campaigns/:id", asyncHandler(whatsappUpdateCampaign));
router.post("/campaigns/:id/duplicate", asyncHandler(whatsappDuplicateCampaign));
router.get("/templates", asyncHandler(whatsappTemplates));
router.post("/templates", asyncHandler(whatsappSaveTemplate));
router.delete("/templates/:id", asyncHandler(whatsappDeleteTemplate));
router.get("/contacts", asyncHandler(whatsappContacts));
router.post("/contacts", asyncHandler(whatsappCreateContact));
router.patch("/contacts/:id", asyncHandler(whatsappUpdateContact));
router.delete("/contacts/:id", asyncHandler(whatsappDeleteContact));
router.post("/contacts/import", asyncHandler(whatsappImportContacts));
router.get("/contacts/export", asyncHandler(whatsappExportContacts));
router.get("/media", asyncHandler(whatsappMediaList));
router.get("/scheduled", asyncHandler(whatsappScheduledList));

router.post("/send", asyncHandler(whatsappSend));
router.post("/send-media", asyncHandler(whatsappSendMedia));
router.post("/bulk-send", asyncHandler(whatsappBulkSend));
router.post("/schedule", asyncHandler(whatsappSchedule));
router.post("/upload", whatsappUpload.single("file"), asyncHandler(whatsappUploadHandler));

export default router;
