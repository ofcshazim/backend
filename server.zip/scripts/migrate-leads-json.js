/**
 * One-time migration: server/data/leads.json → JSON database inquiries.
 * Run from server/: npm run migrate:leads
 */
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { bootstrap, shutdown } from "../bootstrap.js";
import { dbInquiries } from "../db/database.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const leadsPath = path.join(__dirname, "..", "data", "leads.json");

await bootstrap();

if (!fs.existsSync(leadsPath)) {
  console.log("No leads.json found — nothing to migrate.");
  shutdown();
  process.exit(0);
}

const leads = JSON.parse(fs.readFileSync(leadsPath, "utf8"));
let migrated = 0;

for (const lead of leads) {
  if (dbInquiries.get(lead.id)) continue;
  dbInquiries.insert({
    id: lead.id,
    name: lead.name,
    phone: lead.phone,
    email: lead.email,
    budget: lead.budget ?? null,
    project: lead.project ?? null,
    timeline: lead.timeline ?? null,
    message: lead.message ?? "",
    source: lead.source ?? null,
    status: lead.status ?? "new",
    ip: lead.ip ?? null,
    user_agent: lead.userAgent ?? null,
    created_at: lead.createdAt,
    updated_at: lead.createdAt,
  });
  migrated += 1;
}

console.log(`Migrated ${migrated} of ${leads.length} leads from leads.json`);
shutdown();
process.exit(0);
