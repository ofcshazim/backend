/**
 * Emergency restore: copies latest backup over app.json
 * Usage: node scripts/restore-backup.js [--list]
 */
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { listBackups, restoreLatestBackup } from "../services/backup.service.js";
import { env } from "../config/env.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const targetPath = path.isAbsolute(env.dbPath)
  ? env.dbPath.replace(/\.db$/i, ".json")
  : path.join(process.cwd(), env.dbPath.replace(/\.db$/i, ".json"));

if (process.argv.includes("--list")) {
  console.log("Available backups:");
  for (const b of listBackups()) {
    console.log(`  ${b.name}  (${b.size} bytes)  ${b.mtime.toISOString()}`);
  }
  process.exit(0);
}

if (!listBackups().length) {
  console.error("No backups found in server/backups/");
  process.exit(1);
}

const corrupted = fs.existsSync(targetPath)
  ? `${targetPath}.corrupt-${Date.now()}`
  : null;
if (corrupted && fs.existsSync(targetPath)) {
  fs.renameSync(targetPath, corrupted);
  console.log("Moved corrupt file to", corrupted);
}

const restored = restoreLatestBackup(targetPath);
console.log("Restored:", restored, "→", targetPath);
