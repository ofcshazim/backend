import { dbInquiries, dbEmailLogs, dbCampaigns, dbAdminUsers, dbProperties } from "../db/database.js";
import { getCrmAnalytics } from "./crm.service.js";
import { dbSettings } from "../db/database.js";

const daysAgo = (n) => {
  const d = new Date();
  d.setDate(d.getDate() - n);
  return d.toISOString();
};

const groupByDay = (rows, dateField = "created_at", days = 30) => {
  const map = {};
  const start = new Date();
  start.setDate(start.getDate() - days);
  for (let i = 0; i <= days; i++) {
    const d = new Date(start);
    d.setDate(start.getDate() + i);
    map[d.toISOString().slice(0, 10)] = 0;
  }
  for (const row of rows) {
    const key = (row[dateField] || "").slice(0, 10);
    if (map[key] !== undefined) map[key] += 1;
  }
  return Object.entries(map).map(([date, count]) => ({ date, count }));
};

export const getEnterpriseAnalytics = () => {
  const crm = getCrmAnalytics();
  const allLeads = dbInquiries.list({ limit: 10000 });
  const last30 = allLeads.filter((l) => l.created_at >= daysAgo(30));
  const last7 = allLeads.filter((l) => l.created_at >= daysAgo(7));
  const today = allLeads.filter((l) => l.created_at >= daysAgo(1));

  const converted = allLeads.filter((l) => l.status === "converted").length;
  const conversionRate =
    allLeads.length > 0 ? Math.round((converted / allLeads.length) * 1000) / 10 : 0;

  const byProject = {};
  for (const l of allLeads) {
    const p = l.project || "Unspecified";
    byProject[p] = (byProject[p] || 0) + 1;
  }
  const topProperties = Object.entries(byProject)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10)
    .map(([name, count]) => ({ name, count }));

  const byCity = {};
  for (const l of allLeads) {
    const c = l.city || "Unknown";
    byCity[c] = (byCity[c] || 0) + 1;
  }
  const topLocations = Object.entries(byCity)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 8)
    .map(([name, count]) => ({ name, count }));

  const byAgent = {};
  for (const l of allLeads) {
    const a = l.assigned_agent || "Unassigned";
    byAgent[a] = (byAgent[a] || 0) + 1;
  }
  const topAgents = Object.entries(byAgent)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 8)
    .map(([name, leads]) => ({
      name,
      leads,
      conversions: allLeads.filter((l) => l.assigned_agent === name && l.status === "converted").length,
    }));

  const socialSources = ["facebook", "instagram", "meta", "google", "organic", "referral"];
  const bySource = {};
  for (const l of allLeads) {
    const s = (l.source || "website").toLowerCase();
    bySource[s] = (bySource[s] || 0) + 1;
  }

  const campaigns = dbCampaigns.list(50);
  const emailSent = dbEmailLogs.count("sent");

  const settings = dbSettings.all();

  return {
    overview: {
      totalInquiries: allLeads.length,
      today: today.length,
      last7Days: last7.length,
      last30Days: last30.length,
      conversionRate,
      converted,
      activeAgents: dbAdminUsers.list().filter((u) => u.status !== "suspended").length,
      publishedProperties: dbProperties.list({ publish_status: "published" }).length,
      emailsSent: emailSent,
    },
    trends: {
      daily: groupByDay(allLeads, "created_at", 30),
      weekly: groupByDay(allLeads, "created_at", 84),
    },
    funnel: Object.entries(crm.byStatus || {}).map(([stage, count]) => ({ stage, count })),
    pipeline: crm.pipeline || {},
    topProperties,
    topLocations,
    topAgents,
    sources: Object.entries(bySource).map(([name, count]) => ({ name, count })),
    social: {
      facebook: bySource.facebook || bySource.meta || 0,
      instagram: bySource.instagram || 0,
      website: bySource.website || 0,
      google: bySource.google || 0,
      referral: bySource.referral || 0,
      integrations: {
        metaPixelId: settings.meta_pixel_id || "",
        googleAnalyticsId: settings.google_analytics_id || "",
        searchConsoleLinked: Boolean(settings.google_search_console_url),
      },
    },
    campaigns: campaigns.map((c) => ({
      id: c.id,
      name: c.name,
      status: c.status,
      sent: c.sent_count || 0,
      opens: c.open_count || 0,
      clicks: c.click_count || 0,
    })),
    placeholders: {
      revenue: null,
      bounceRate: null,
      heatmap: null,
      audienceGrowth: null,
    },
  };
};

export const getSocialAnalytics = () => {
  const allLeads = dbInquiries.list({ limit: 10000 });
  const socialLeads = allLeads.filter((l) => {
    const s = (l.source || "").toLowerCase();
    return ["facebook", "instagram", "meta", "social", "linkedin", "twitter", "tiktok"].some((x) =>
      s.includes(x)
    );
  });

  const campaigns = dbCampaigns
    .list(20)
    .filter((c) => c.status === "sent")
    .map((c) => ({
      id: c.id,
      name: c.name,
      sent: c.sent_count || 0,
      clicks: c.click_count || 0,
      conversions: Math.round((c.click_count || 0) * 0.12),
    }));

  return {
    summary: {
      socialLeads: socialLeads.length,
      totalLeads: allLeads.length,
      sharePercent:
        allLeads.length > 0 ? Math.round((socialLeads.length / allLeads.length) * 1000) / 10 : 0,
      clicks: campaigns.reduce((s, c) => s + (c.clicks || 0), 0),
      conversions: socialLeads.filter((l) => l.status === "converted").length,
    },
    engagement: {
      facebook: { leads: allLeads.filter((l) => (l.source || "").toLowerCase().includes("facebook")).length, placeholder: true },
      instagram: { leads: allLeads.filter((l) => (l.source || "").toLowerCase().includes("instagram")).length, placeholder: true },
    },
    campaigns,
    trafficSources: Object.entries(
      allLeads.reduce((acc, l) => {
        const s = l.source || "website";
        acc[s] = (acc[s] || 0) + 1;
        return acc;
      }, {})
    ).map(([source, visits]) => ({ source, visits })),
    integrations: {
      metaPixel: { configured: Boolean(dbSettings.all().meta_pixel_id), note: "Connect Meta Pixel in Settings" },
      googleAnalytics: { configured: Boolean(dbSettings.all().google_analytics_id), note: "Add GA4 ID in Settings" },
      searchConsole: { configured: Boolean(dbSettings.all().google_search_console_url), note: "Add property URL in Settings" },
      facebookAds: { configured: false, note: "API token required for live Ads data" },
    },
  };
};
