import { dbAuditLogs } from "../db/database.js";

export const logAdminAction = (req, action, meta = {}) => {
  dbAuditLogs.insert({
    admin_id: req?.admin?.id,
    admin_email: req?.admin?.email || meta.actor || "system",
    action,
    ip: req?.ip || req?.headers?.["x-forwarded-for"] || meta.ip,
    path: req?.originalUrl || meta.path,
    method: req?.method || meta.method,
    ...meta,
  });
};

export const listAuditLogs = (limit = 100) => dbAuditLogs.list(limit);
