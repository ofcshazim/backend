import axios from "axios";
import { env, isAuthkeyConfigured } from "../config/env.js";
import { normalizeWhatsAppPhone } from "../utils/sanitize.js";
import { logger } from "../utils/logger.js";
import { recordAuthkeyFailure } from "./system-monitor.service.js";

const REQUEST_TIMEOUT = 45000;
const MAX_BULK_RECIPIENTS = 200;

export const authkeyStatus = {
  ready: false,
  lastError: null,
  verifiedAt: null,
  balance: null,
  balanceCheckedAt: null,
};

const client = () => {
  if (!isAuthkeyConfigured()) {
    throw Object.assign(new Error("Authkey is not configured"), { code: "AUTHKEY_NOT_CONFIGURED" });
  }
  return axios.create({
    timeout: REQUEST_TIMEOUT,
    headers: {
      Authorization: `Basic ${env.authkey.authKey}`,
      "Content-Type": "application/json",
      Accept: "application/json",
    },
  });
};

export const parsePhoneForAuthkey = (phone, defaultCountry = "92") => {
  const normalized = normalizeWhatsAppPhone(phone);
  if (!normalized) {
    throw Object.assign(new Error("Invalid phone number"), { code: "INVALID_PHONE" });
  }

  if (normalized.startsWith("92") && normalized.length >= 12) {
    return { country_code: "92", mobile: normalized.slice(2) };
  }

  if (normalized.length === 10 && normalized.startsWith("3")) {
    return { country_code: defaultCountry, mobile: normalized };
  }

  if (normalized.length > 10) {
    const country = normalized.slice(0, normalized.length - 10);
    return { country_code: country || defaultCountry, mobile: normalized.slice(-10) };
  }

  return { country_code: defaultCountry, mobile: normalized };
};

const handleAuthkeyError = (err, context) => {
  const message =
    err.response?.data?.message ||
    err.response?.data?.error ||
    err.response?.data?.status ||
    err.message ||
    "Authkey request failed";
  logger.whatsapp(`[AUTHKEY] ${context} failed`, {
    status: err.response?.status,
    message,
    data: err.response?.data,
  });
  throw Object.assign(new Error(message), {
    code: "AUTHKEY_ERROR",
    status: err.response?.status || 502,
    response: err.response?.data,
  });
};

const postJson = async (url, body, context) => {
  try {
    const res = await client().post(url, body);
    return res.data;
  } catch (err) {
    recordAuthkeyFailure(`${context}: ${err.message}`);
    handleAuthkeyError(err, context);
  }
};

const validateExpiration = (expirationTimeMs) => {
  if (!expirationTimeMs) return;
  const exp = Number(expirationTimeMs);
  if (!Number.isFinite(exp) || exp <= Date.now()) {
    throw Object.assign(new Error("Offer expiration time must be in the future"), {
      code: "EXPIRED_OFFER",
    });
  }
};

export const verifyAuthkeyConnection = async () => {
  if (!env.authkey.enabled || !isAuthkeyConfigured()) {
    authkeyStatus.ready = false;
    authkeyStatus.lastError = "Authkey not configured — set AUTHKEY_AUTH_KEY";
    logger.warn("[AUTHKEY] Skipped — missing AUTHKEY_AUTH_KEY");
    return false;
  }

  try {
    const balance = await getBalance();
    authkeyStatus.ready = true;
    authkeyStatus.lastError = null;
    authkeyStatus.verifiedAt = new Date().toISOString();
    authkeyStatus.balance = balance.balance ?? balance.credits ?? balance;
    authkeyStatus.balanceCheckedAt = new Date().toISOString();
    logger.info("[AUTHKEY] Connected", { balance: authkeyStatus.balance });
    return true;
  } catch (err) {
    authkeyStatus.ready = false;
    authkeyStatus.lastError = err.message;
    logger.warn("[AUTHKEY] Connection check failed", { error: err.message });
    return false;
  }
};

export const getBalance = async () => {
  if (!isAuthkeyConfigured()) {
    throw Object.assign(new Error("AUTHKEY_AUTH_KEY is not set"), { code: "AUTHKEY_NOT_CONFIGURED" });
  }

  try {
    const url = `${env.authkey.balanceUrl}?authkey=${encodeURIComponent(env.authkey.authKey)}`;
    const res = await axios.get(url, { timeout: 15000 });
    const data = res.data;
    authkeyStatus.balance = data?.balance ?? data?.credits ?? data;
    authkeyStatus.balanceCheckedAt = new Date().toISOString();
    return data;
  } catch (err) {
    handleAuthkeyError(err, "getBalance");
  }
};

export const sendTextTemplate = async ({
  phone,
  country_code,
  mobile,
  wid,
  bodyValues = {},
}) => {
  const parsed = mobile && country_code ? { country_code, mobile } : parsePhoneForAuthkey(phone);
  const body = {
    country_code: parsed.country_code,
    mobile: parsed.mobile,
    wid: String(wid),
    type: "text",
    bodyValues,
  };
  return postJson(env.authkey.apiUrl, body, "sendTextTemplate");
};

export const sendMediaTemplate = async ({
  phone,
  country_code,
  mobile,
  wid,
  bodyValues = {},
  headerValues = {},
}) => {
  const parsed = mobile && country_code ? { country_code, mobile } : parsePhoneForAuthkey(phone);
  const body = {
    country_code: parsed.country_code,
    mobile: parsed.mobile,
    wid: String(wid),
    type: "media",
    bodyValues,
    headerValues,
  };
  return postJson(env.authkey.apiUrl, body, "sendMediaTemplate");
};

export const sendDynamicButtonTemplate = async ({
  phone,
  country_code,
  mobile,
  wid,
  type = "media",
  bodyValues = {},
  headerValues = {},
  button_param_value,
}) => {
  const parsed = mobile && country_code ? { country_code, mobile } : parsePhoneForAuthkey(phone);
  const body = {
    version: "2.0",
    country_code: parsed.country_code,
    mobile: parsed.mobile,
    wid: String(wid),
    type,
    bodyValues,
    button_param_value,
  };
  if (Object.keys(headerValues).length) body.headerValues = headerValues;
  return postJson(env.authkey.apiUrl, body, "sendDynamicButtonTemplate");
};

export const sendCopyCodeTemplate = async ({
  phone,
  country_code,
  mobile,
  wid,
  type = "text",
  bodyValues = {},
  headerValues = {},
  copy_code_value,
  expiration_time_ms,
}) => {
  validateExpiration(expiration_time_ms);
  const parsed = mobile && country_code ? { country_code, mobile } : parsePhoneForAuthkey(phone);
  const body = {
    country_code: parsed.country_code,
    mobile: parsed.mobile,
    wid: String(wid),
    type,
    bodyValues,
    copy_code_value,
  };
  if (Object.keys(headerValues).length) body.headerValues = headerValues;
  if (expiration_time_ms) body.expiration_time_ms = Number(expiration_time_ms);
  return postJson(env.authkey.apiUrl, body, "sendCopyCodeTemplate");
};

export const sendLimitedTimeOfferTemplate = async ({
  phone,
  country_code,
  mobile,
  wid,
  type = "media",
  bodyValues = {},
  headerValues = {},
  expiration_time_ms,
  button_param_value,
}) => {
  validateExpiration(expiration_time_ms);
  const parsed = mobile && country_code ? { country_code, mobile } : parsePhoneForAuthkey(phone);
  const body = {
    version: "2.0",
    country_code: parsed.country_code,
    mobile: parsed.mobile,
    wid: String(wid),
    type,
    bodyValues,
    expiration_time_ms: Number(expiration_time_ms),
  };
  if (Object.keys(headerValues).length) body.headerValues = headerValues;
  if (button_param_value) body.button_param_value = button_param_value;
  return postJson(env.authkey.apiUrl, body, "sendLimitedTimeOfferTemplate");
};

const chunkArray = (arr, size) => {
  const chunks = [];
  for (let i = 0; i < arr.length; i += size) chunks.push(arr.slice(i, i + size));
  return chunks;
};

export const sendBulkTemplate = async ({
  wid,
  country_code = "92",
  type = "text",
  data = [],
  button_param_value,
  copy_code_value,
  expiration_time_ms,
}) => {
  if (expiration_time_ms) validateExpiration(expiration_time_ms);
  if (!Array.isArray(data) || !data.length) {
    throw Object.assign(new Error("Bulk data array is required"), { code: "INVALID_BULK" });
  }
  if (data.length > MAX_BULK_RECIPIENTS) {
    throw Object.assign(new Error(`Maximum ${MAX_BULK_RECIPIENTS} recipients per bulk request`), {
      code: "BULK_LIMIT",
    });
  }

  const body = {
    version: "2.0",
    country_code,
    wid: String(wid),
    type,
    data: data.map((row) => {
      const parsed = row.mobile
        ? { country_code: row.country_code || country_code, mobile: row.mobile }
        : parsePhoneForAuthkey(row.phone || row.to);
      return {
        mobile: parsed.mobile,
        bodyValues: row.bodyValues || {},
        ...(row.headerValues ? { headerValues: row.headerValues } : {}),
      };
    }),
  };
  if (button_param_value) body.button_param_value = button_param_value;
  if (copy_code_value) body.copy_code_value = copy_code_value;
  if (expiration_time_ms) body.expiration_time_ms = Number(expiration_time_ms);

  return postJson(env.authkey.bulkApiUrl, body, "sendBulkTemplate");
};

export const sendBulkMediaTemplate = async (payload) =>
  sendBulkTemplate({ ...payload, type: payload.type || "media" });

export const sendBulkInChunks = async (payload) => {
  const { data = [], ...rest } = payload;
  const chunks = chunkArray(data, MAX_BULK_RECIPIENTS);
  const results = [];
  for (const chunk of chunks) {
    const result = await sendBulkTemplate({ ...rest, data: chunk });
    results.push(result);
  }
  return { ok: true, chunks: results.length, results };
};
