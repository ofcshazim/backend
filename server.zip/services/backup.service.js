import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { logger } from "../utils/logger.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const BACKUP_DIR = path.join(__dirname, "..", "backups");
const MAX_BACKUPS = Number(process.env.BACKUP_RETENTION || 14);

export const getBackupDir = () => BACKUP_DIR;

export const ensureBackupDir = () => {
  fs.mkdirSync(BACKUP_DIR, { recursive: true });
};

const backupFilename = (date = new Date()) => {
  const stamp = date.toISOString().replace(/[:.]/g, "-").slice(0, 19);
  return `app-${stamp}.json`;
};

export const createBackup = (sourcePath, label = "manual") => {
  if (!fs.existsSync(sourcePath)) return null;

  ensureBackupDir();
  const dest = path.join(BACKUP_DIR, backupFilename());
  fs.copyFileSync(sourcePath, dest);
  rotateBackups();
  logger.info("[DB] Backup created", { file: path.basename(dest), label });
  return dest;
};

export const rotateBackups = () => {
  ensureBackupDir();
  const files = fs
    .readdirSync(BACKUP_DIR)
    .filter((f) => f.startsWith("app-") && f.endsWith(".json"))
    .map((f) => ({ name: f, time: fs.statSync(path.join(BACKUP_DIR, f)).mtimeMs }))
    .sort((a, b) => b.time - a.time);

  for (const file of files.slice(MAX_BACKUPS)) {
    fs.unlinkSync(path.join(BACKUP_DIR, file.name));
    logger.info("[DB] Old backup removed", { file: file.name });
  }
};

export const listBackups = () => {
  ensureBackupDir();
  return fs
    .readdirSync(BACKUP_DIR)
    .filter((f) => f.endsWith(".json"))
    .map((f) => {
      const full = path.join(BACKUP_DIR, f);
      return { name: f, path: full, size: fs.statSync(full).size, mtime: fs.statSync(full).mtime };
    })
    .sort((a, b) => b.mtime - a.mtime);
};

export const restoreLatestBackup = (targetPath) => {
  const backups = listBackups();
  if (!backups.length) throw new Error("No backups available to restore");

  const latest = backups[0].path;
  fs.copyFileSync(latest, targetPath);
  logger.warn("[DB] Restored from backup", { file: backups[0].name });
  return latest;
};

export const startDailyBackupSchedule = (sourcePath) => {
  const intervalMs = Number(process.env.BACKUP_INTERVAL_MS || 24 * 60 * 60 * 1000);
  createBackup(sourcePath, "startup");

  const timer = setInterval(() => createBackup(sourcePath, "scheduled"), intervalMs);
  timer.unref?.();
  return timer;
};
