import { dbCampaigns } from "../db/database.js";
import { sendCustomEmail } from "./email.service.js";
import { buildFromTemplate } from "./template.service.js";
import { listInquiries } from "./inquiry.service.js";
import { logger } from "../utils/logger.js";
import { notifyCampaignComplete } from "./notification.service.js";

export const listCampaigns = () => dbCampaigns.list(100);

export const getCampaign = (id) => dbCampaigns.get(id);

export const createCampaign = (data) =>
  dbCampaigns.insert({
    name: data.name,
    subject: data.subject,
    template_key: data.templateKey || "",
    html: data.html || "",
    audience: data.audience || "all",
    status: "draft",
    scheduled_at: data.scheduledAt || null,
  });

export const updateCampaign = (id, data) =>
  dbCampaigns.update(id, {
    name: data.name,
    subject: data.subject,
    template_key: data.templateKey,
    html: data.html,
    audience: data.audience,
    scheduled_at: data.scheduledAt,
    status: data.status,
  });

export const deleteCampaign = (id) => dbCampaigns.delete(id);

const resolveAudience = (audience) => {
  const all = listInquiries({ limit: 50000 });
  if (audience === "active") {
    return all.filter((l) => !["closed", "lost"].includes(l.status) && l.email);
  }
  if (audience === "new") {
    return all.filter((l) => l.status === "new" && l.email);
  }
  if (audience === "converted") {
    return all.filter((l) => l.status === "converted" && l.email);
  }
  return all.filter((l) => l.email);
};

export const sendCampaign = async (id) => {
  const campaign = dbCampaigns.get(id);
  if (!campaign) throw Object.assign(new Error("Campaign not found"), { statusCode: 404 });

  const recipients = resolveAudience(campaign.audience);
  let sent = 0;
  let failed = 0;

  for (const lead of recipients) {
    try {
      let subject = campaign.subject;
      let html = campaign.html;

      if (campaign.template_key) {
        const built = buildFromTemplate(campaign.template_key, {
          name: lead.name,
          project: lead.project || "our projects",
          email: lead.email,
        });
        if (built) {
          subject = built.subject;
          html = built.html;
        }
      }

      await sendCustomEmail({
        to: lead.email,
        subject,
        html,
        templateKey: campaign.template_key || "campaign",
        inquiryId: lead.id,
      });
      sent += 1;
    } catch (err) {
      failed += 1;
      logger.error("[CAMPAIGN] Send failed", { to: lead.email, error: err.message });
    }
  }

  const updated = dbCampaigns.update(id, {
    status: "sent",
    sent_at: new Date().toISOString(),
    sent_count: sent,
    failed_count: failed,
    recipient_count: recipients.length,
  });

  notifyCampaignComplete(updated);
  return updated;
};

export const sendTestCampaign = async ({ to, subject, html, templateKey, vars }) => {
  let finalSubject = subject;
  let finalHtml = html;
  if (templateKey) {
    const built = buildFromTemplate(templateKey, vars || { name: "Test User" });
    if (built) {
      finalSubject = built.subject;
      finalHtml = built.html;
    }
  }
  await sendCustomEmail({ to, subject: finalSubject, html: finalHtml, templateKey: templateKey || "test" });
  return { ok: true };
};
