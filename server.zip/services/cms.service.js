import { dbCmsSections, dbCmsMedia } from "../db/database.js";
import { logAdminAction } from "./audit.service.js";

export const CMS_SECTION_KEYS = [
  "homepage_hero",
  "homepage_banners",
  "about",
  "contact",
  "footer",
  "social",
  "seo_global",
  "testimonials",
  "faqs",
  "team",
  "cta",
  "blogs",
];

export const listCmsSections = () => dbCmsSections.list();

export const getCmsSection = (key) => dbCmsSections.findByKey(key);

export const getPublishedContent = (key) => {
  const section = dbCmsSections.findByKey(key);
  if (!section) return null;
  return section.status === "published" ? section.content : section.draft_content || section.content;
};

export const getAllPublishedContent = () => {
  const out = {};
  for (const section of dbCmsSections.list()) {
    if (section.status === "published" || section.content) {
      out[section.key] = getPublishedContent(section.key);
    }
  }
  return out;
};

export const upsertCmsSection = (key, payload, actor) => {
  const existing = dbCmsSections.findByKey(key);
  const now = new Date().toISOString();

  const row = {
    key,
    title: payload.title || key,
    content: payload.content ?? existing?.content ?? {},
    draft_content: payload.draft_content ?? payload.content ?? existing?.draft_content ?? {},
    status: payload.status || existing?.status || "draft",
    updated_at: now,
    updated_by: actor?.email || "system",
  };

  let result;
  if (existing) {
    result = dbCmsSections.update(key, row);
  } else {
    result = dbCmsSections.insert({ ...row, created_at: now });
  }

  logAdminAction({ admin: actor }, "cms_update", { section: key, status: row.status });
  return result;
};

export const publishCmsSection = (key, actor) => {
  const section = dbCmsSections.findByKey(key);
  if (!section) return null;
  const content = section.draft_content || section.content;
  return upsertCmsSection(
    key,
    { content, draft_content: content, status: "published", title: section.title },
    actor
  );
};

export const listMedia = (limit = 100) => dbCmsMedia.list(limit);

export const addMedia = (payload, actor) => {
  const record = dbCmsMedia.insert({
    filename: payload.filename,
    url: payload.url,
    mime_type: payload.mime_type || "image/jpeg",
    size_bytes: payload.size_bytes || 0,
    alt: payload.alt || "",
    uploaded_by: actor?.email || "system",
  });
  logAdminAction({ admin: actor }, "cms_media_upload", { mediaId: record.id });
  return record;
};

export const deleteMedia = (id, actor) => {
  dbCmsMedia.delete(id);
  logAdminAction({ admin: actor }, "cms_media_delete", { mediaId: id });
};
