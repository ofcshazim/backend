import { dbInquiries, dbLeadActivities, dbCampaigns } from "../db/database.js";
import { normalizeLead, CRM_STATUSES, PIPELINE_STAGES } from "../constants/crm.js";
import { countEmailLogs } from "./log.service.js";

export const getPipeline = () => {
  const all = dbInquiries.list({ limit: 10000 }).map(normalizeLead);
  const stages = PIPELINE_STAGES.map((stage) => ({
    ...stage,
    count: all.filter((l) => l.status === stage.key).length,
    leads: all.filter((l) => l.status === stage.key).slice(0, 50),
  }));
  return { stages, total: all.length };
};

export const getCrmAnalytics = () => {
  const all = dbInquiries.list({ limit: 10000 }).map(normalizeLead);
  const now = new Date();
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();

  const byStatus = {};
  for (const s of CRM_STATUSES) {
    byStatus[s] = all.filter((l) => l.status === s).length;
  }

  const bySource = {};
  for (const lead of all) {
    const src = lead.source || "website";
    bySource[src] = (bySource[src] || 0) + 1;
  }

  const byAgent = {};
  for (const lead of all) {
    const agent = lead.assigned_agent || "Unassigned";
    byAgent[agent] = (byAgent[agent] || 0) + 1;
  }

  const monthlyLeads = all.filter((l) => l.created_at >= monthStart).length;
  const converted = all.filter((l) => l.status === "converted").length;
  const active = all.filter((l) => !["closed", "lost", "converted"].includes(l.status)).length;
  const conversionRate = all.length ? Math.round((converted / all.length) * 100) : 0;

  const followUpsDue = all.filter(
    (l) => l.follow_up_at && new Date(l.follow_up_at) <= now && !["closed", "lost", "converted"].includes(l.status)
  ).length;

  const campaigns = dbCampaigns.list(20);
  const campaignsSent = campaigns.filter((c) => c.status === "sent").length;

  return {
    totalLeads: all.length,
    activeLeads: active,
    convertedLeads: converted,
    monthlyLeads,
    conversionRate,
    followUpsDue,
    byStatus,
    bySource,
    byAgent,
    emailsSent: countEmailLogs("sent"),
    campaignStats: {
      total: campaigns.length,
      sent: campaignsSent,
      drafts: campaigns.filter((c) => c.status === "draft").length,
    },
    recentActivity: dbLeadActivities.listRecent(15),
  };
};

export const getMonthlyReport = () => {
  const all = dbInquiries.list({ limit: 10000 }).map(normalizeLead);
  const months = {};

  for (const lead of all) {
    const d = new Date(lead.created_at);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    if (!months[key]) months[key] = { month: key, leads: 0, converted: 0 };
    months[key].leads += 1;
    if (lead.status === "converted") months[key].converted += 1;
  }

  return Object.values(months).sort((a, b) => b.month.localeCompare(a.month)).slice(0, 12);
};
