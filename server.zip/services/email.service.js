import { env } from "../config/env.js";
import { getMailTransport, smtpStatus } from "../utils/mail-transport.js";
import { withRetry } from "../utils/retry.js";
import { logger } from "../utils/logger.js";
import { logEmail } from "./log.service.js";
import { buildFromTemplate } from "./template.service.js";
import { buildAdminInquiryEmail } from "../templates/email/admin-inquiry.js";
import { buildCustomerAutoReplyEmail } from "../templates/email/customer-autoreply.js";

const formatTimestamp = () =>
  new Date().toLocaleString("en-PK", { timeZone: "Asia/Karachi", dateStyle: "medium", timeStyle: "short" });

const sendMail = async ({
  to,
  subject,
  html,
  text,
  replyTo,
  cc,
  bcc,
  inquiryId,
  templateKey,
  logLabel,
}) => {
  const transport = getMailTransport();

  try {
    await withRetry(
      () =>
        transport.sendMail({
          from: `"${env.siteName}" <${env.smtp.from}>`,
          to,
          cc: cc || undefined,
          bcc: bcc || undefined,
          replyTo: replyTo || env.companyEmail,
          subject,
          html,
          text: text || subject.replace(/<[^>]+>/g, ""),
          headers: {
            "X-Mailer": env.siteName,
            "X-Priority": "3",
          },
        }),
      { attempts: 3, delayMs: 1200, label: "sendMail" }
    );
    logEmail({ inquiryId, to, subject, templateKey, status: "sent" });
    if (logLabel) logger.info(`[MAIL] ${logLabel}`);
    return { ok: true };
  } catch (err) {
    logEmail({ inquiryId, to, subject, templateKey, status: "failed", error: err.message });
    logger.error("[MAIL] SMTP Failed", { to, subject, error: err.message, code: err.code });
    throw err;
  }
};

const inquiryVars = (lead) => ({
  name: lead.name,
  phone: lead.phone,
  email: lead.email,
  message: lead.message,
  project: lead.project || "—",
  budget: lead.budget || "—",
  timeline: lead.timeline || "—",
  source: lead.source || "/",
  inquiry_id: lead.id,
  submitted_at: formatTimestamp(),
});

export const sendAdminNotification = async (lead) => {
  const vars = inquiryVars(lead);
  const fromDb = buildFromTemplate("admin_inquiry", vars);
  const built = fromDb || buildAdminInquiryEmail(lead);
  const subject = "New Website Inquiry Received";

  await sendMail({
    to: env.contactReceiver,
    subject: fromDb ? built.subject : subject,
    html: built.html,
    text: built.text,
    replyTo: lead.email,
    inquiryId: lead.id,
    templateKey: "admin_inquiry",
    logLabel: "Admin Notification Sent",
  });
};

export const sendInternalCopy = async (lead) => {
  const receiver = env.internalCopyEmail || env.companyEmail;
  const adminReceiver = env.contactReceiver.toLowerCase();

  if (receiver.toLowerCase() === adminReceiver) {
    logger.info(`[MAIL] Internal Copy Sent to ${receiver} (included in admin notification)`);
    return { ok: true, skipped: true };
  }

  const vars = inquiryVars(lead);
  const fromDb = buildFromTemplate("internal_copy", vars);
  const built = fromDb || {
    subject: `[Archive] Website inquiry — ${lead.name}`,
    html: buildAdminInquiryEmail(lead).html,
  };

  await sendMail({
    to: receiver,
    subject: built.subject,
    html: built.html,
    replyTo: lead.email,
    inquiryId: lead.id,
    templateKey: "internal_copy",
    logLabel: `Internal Copy Sent to ${receiver}`,
  });
};

export const sendCustomerAutoReply = async (lead) => {
  if (!env.sendAutoReplyEmail) return;

  const vars = inquiryVars(lead);
  const fromDb = buildFromTemplate("customer_autoreply", vars);
  const built = fromDb || buildCustomerAutoReplyEmail(lead);

  await sendMail({
    to: lead.email,
    subject: built.subject,
    html: built.html,
    text: built.text,
    inquiryId: lead.id,
    templateKey: "customer_autoreply",
    logLabel: "Customer Auto Reply Sent",
  });
};

export const sendCustomEmail = async ({ to, subject, html, templateKey, inquiryId, cc, bcc, replyTo }) =>
  sendMail({
    to,
    subject,
    html,
    cc,
    bcc,
    replyTo: replyTo || env.companyEmail,
    inquiryId,
    templateKey,
    logLabel: "Email Sent",
  });

export const deliverInquiryEmails = async (lead) => {
  if (!smtpStatus.ready) {
    throw Object.assign(new Error("Email service is temporarily unavailable"), {
      code: "SMTP_NOT_READY",
      statusCode: 503,
    });
  }

  await sendAdminNotification(lead);
  await sendInternalCopy(lead);
  await sendCustomerAutoReply(lead);
};

export { smtpStatus };
