import { listInquiries } from "./inquiry.service.js";

const escapeCsv = (val) => {
  const s = String(val ?? "").replace(/"/g, '""');
  return `"${s}"`;
};

export const leadsToCsv = (leads) => {
  const headers = [
    "ID",
    "Name",
    "Phone",
    "Email",
    "Status",
    "Source",
    "Project",
    "Budget",
    "City",
    "Assigned Agent",
    "Priority",
    "Score",
    "Follow Up",
    "Message",
    "Created",
  ];

  const rows = leads.map((l) =>
    [
      l.id,
      l.name,
      l.phone,
      l.email,
      l.status,
      l.source,
      l.project,
      l.budget,
      l.city,
      l.assigned_agent,
      l.priority,
      l.score,
      l.follow_up_at || "",
      l.message,
      l.created_at,
    ]
      .map(escapeCsv)
      .join(",")
  );

  return `\uFEFF${headers.join(",")}\n${rows.join("\n")}`;
};

export const exportLeads = (filters = {}) => {
  const leads = listInquiries({ ...filters, limit: 50000 });
  return { leads, csv: leadsToCsv(leads) };
};

export const leadsToPdfHtml = (leads) => {
  const rows = leads
    .map(
      (l) => `<tr>
      <td>${l.name}</td><td>${l.phone}</td><td>${l.email}</td>
      <td>${l.status}</td><td>${l.source}</td><td>${l.project}</td>
      <td>${l.created_at?.slice(0, 10)}</td>
    </tr>`
    )
    .join("");

  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
  <style>
    body{font-family:Arial,sans-serif;padding:24px;color:#1a2e28}
    h1{color:#1f7a3e;font-size:22px}
    table{width:100%;border-collapse:collapse;margin-top:16px;font-size:11px}
    th,td{border:1px solid #e4ebe8;padding:8px;text-align:left}
    th{background:#0f3d2e;color:#fff}
    tr:nth-child(even){background:#f4f8f6}
  </style></head><body>
  <h1>Check In Property — Leads Export</h1>
  <p>Generated ${new Date().toLocaleString()}</p>
  <table><thead><tr>
    <th>Name</th><th>Phone</th><th>Email</th><th>Status</th><th>Source</th><th>Project</th><th>Date</th>
  </tr></thead><tbody>${rows}</tbody></table></body></html>`;
};
