import { dbInquiries, dbLeadActivities } from "../db/database.js";
import { normalizeLead, CRM_STATUSES } from "../constants/crm.js";
import { computeLeadScore } from "../utils/lead-score.js";
import { notifyInquiry, notifyLeadAssignment } from "./notification.service.js";
import { incrementPropertyInquiries } from "./property.service.js";

const genId = () => `lead_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;

export const logLeadActivity = (leadId, type, description, meta = {}) => {
  dbLeadActivities.insert({
    lead_id: leadId,
    type,
    description,
    meta: JSON.stringify(meta),
    actor: meta.actor || "system",
  });
};

export const createInquiry = (data) => {
  const now = new Date().toISOString();
  const id = genId();

  const lead = dbInquiries.insert({
    id,
    name: data.name,
    phone: data.phone,
    email: data.email,
    message: data.message,
    budget: data.budget || "",
    project: data.project || "",
    timeline: data.timeline || "",
    city: data.city || "Islamabad",
    source: data.source || "website",
    status: "new",
    assigned_agent: data.assigned_agent || "",
    priority: data.priority || "medium",
    score: 0,
    follow_up_at: null,
    converted_at: null,
    notes_summary: "",
    ip: data.ip || "",
    user_agent: data.user_agent || "",
    created_at: now,
    updated_at: now,
  });

  const scored = updateLeadScore(id);
  logLeadActivity(id, "created", "New lead received from website", { source: lead.source });

  notifyInquiry(scored);
  incrementPropertyInquiries(scored.project);
  return scored;
};

export const getInquiryById = (id) => {
  const row = dbInquiries.get(id);
  return row ? normalizeLead(row) : null;
};

export const listInquiries = (opts = {}) => {
  const rows = dbInquiries.list(opts);
  return rows.map(normalizeLead);
};

export const updateInquiry = (id, fields, actor = "admin") => {
  const current = dbInquiries.get(id);
  if (!current) return null;

  const allowed = [
    "status",
    "assigned_agent",
    "priority",
    "project",
    "budget",
    "timeline",
    "city",
    "source",
    "follow_up_at",
    "notes_summary",
  ];

  const patch = {};
  for (const key of allowed) {
    if (fields[key] !== undefined) patch[key] = fields[key];
  }

  if (fields.status && fields.status !== current.status) {
    if (!CRM_STATUSES.includes(fields.status)) {
      throw Object.assign(new Error("Invalid status"), { statusCode: 400 });
    }
    logLeadActivity(id, "status_change", `Status: ${current.status} → ${fields.status}`, {
      actor,
      from: current.status,
      to: fields.status,
    });
    if (fields.status === "converted") {
      patch.converted_at = new Date().toISOString();
    }
  }

  if (fields.assigned_agent !== undefined && fields.assigned_agent !== current.assigned_agent) {
    logLeadActivity(id, "assignment", `Assigned to ${fields.assigned_agent || "unassigned"}`, {
      actor,
    });
    notifyLeadAssignment(
      { ...current, id },
      fields.assigned_agent || "Unassigned",
      actor
    );
  }

  const updated = dbInquiries.update(id, patch);
  return updateLeadScore(id);
};

export const updateLeadScore = (id) => {
  const lead = dbInquiries.get(id);
  if (!lead) return null;
  const score = computeLeadScore(normalizeLead(lead));
  return normalizeLead(dbInquiries.update(id, { score }));
};

export const deleteInquiry = (id) => {
  dbInquiries.delete(id);
};

export const countInquiries = (filters) =>
  filters ? dbInquiries.countFiltered(filters) : dbInquiries.count();

export const countInquiriesByStatus = (status) => dbInquiries.count(status);
