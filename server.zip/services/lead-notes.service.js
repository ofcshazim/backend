import { dbLeadNotes } from "../db/database.js";
import { logLeadActivity } from "./inquiry.service.js";

export const addLeadNote = (leadId, text, author = "admin") => {
  const note = dbLeadNotes.insert({
    lead_id: leadId,
    text: text.trim(),
    author,
  });
  logLeadActivity(leadId, "note", "Note added", { author });
  return note;
};

export const listLeadNotes = (leadId) => dbLeadNotes.listByLead(leadId);

export const deleteLeadNote = (id, leadId) => {
  dbLeadNotes.delete(id);
  logLeadActivity(leadId, "note_deleted", "Note removed");
};
