import { dbEmailLogs, dbWhatsAppLogs } from "../db/database.js";

export const logEmail = ({ inquiryId, to, subject, templateKey, status, error }) =>
  dbEmailLogs.insert({
    inquiry_id: inquiryId || null,
    to_address: to,
    subject,
    template_key: templateKey || null,
    status,
    error: error || null,
    created_at: new Date().toISOString(),
  });

export const logWhatsApp = ({ inquiryId, to, message, templateKey, status, error }) =>
  dbWhatsAppLogs.insert({
    inquiry_id: inquiryId || null,
    to_phone: to,
    message,
    template_key: templateKey || null,
    status,
    error: error || null,
    created_at: new Date().toISOString(),
  });

export const listEmailLogs = (limit = 50) => dbEmailLogs.list(limit);

export const listWhatsAppLogs = (limit = 50) => dbWhatsAppLogs.list(limit);

export const countEmailLogs = (status) => dbEmailLogs.count(status);

export const countWhatsAppLogs = (status) => dbWhatsAppLogs.count(status);
