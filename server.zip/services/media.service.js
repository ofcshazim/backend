import fs from "fs";
import path from "path";
import crypto from "crypto";
import { env } from "../config/env.js";

const UPLOAD_DIR = path.join(process.cwd(), "uploads", "media");

export const ensureUploadDir = () => {
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
};

export const saveBase64Image = (base64, filenameHint = "upload") => {
  ensureUploadDir();
  const match = base64.match(/^data:(image\/[a-z+]+);base64,(.+)$/i);
  const mime = match?.[1] || "image/jpeg";
  const data = match?.[2] || base64;
  const ext = mime.split("/")[1]?.replace("jpeg", "jpg") || "jpg";
  const id = crypto.randomBytes(8).toString("hex");
  const filename = `${filenameHint}-${id}.${ext}`.replace(/[^a-z0-9._-]/gi, "-");
  const filePath = path.join(UPLOAD_DIR, filename);
  fs.writeFileSync(filePath, Buffer.from(data, "base64"));
  const origin =
    env.apiPublicUrl?.replace(/\/api\/?$/, "") || "http://93.115.101.102:12176";
  const publicUrl = `${origin}/uploads/media/${filename}`;
  return {
    filename,
    url: publicUrl,
    mime_type: mime,
    size_bytes: Buffer.byteLength(data, "base64"),
  };
};
