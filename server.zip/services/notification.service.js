import { dbNotifications } from "../db/database.js";

export const createNotification = ({
  type,
  title,
  message,
  user_id = null,
  meta = {},
  channel = "in_app",
}) => {
  return dbNotifications.insert({
    type,
    title,
    message,
    user_id,
    meta,
    channel,
    read: false,
  });
};

export const listNotifications = ({ userId, unreadOnly = false, limit = 50 } = {}) =>
  dbNotifications.list({ userId, unreadOnly, limit });

export const markNotificationRead = (id) => dbNotifications.markRead(id);

export const markAllRead = (userId) => dbNotifications.markAllRead(userId);

export const countUnread = (userId) => dbNotifications.countUnread(userId);

export const notifyInquiry = (inquiry) => {
  createNotification({
    type: "inquiry",
    title: "New website inquiry",
    message: `${inquiry.name} — ${inquiry.project || "General"} (${inquiry.phone})`,
    meta: { leadId: inquiry.id },
  });
};

export const notifyLeadAssignment = (lead, agentName, actorName) => {
  createNotification({
    type: "lead_assignment",
    title: "Lead assigned",
    message: `${lead.name} assigned to ${agentName} by ${actorName}`,
    meta: { leadId: lead.id, agent: agentName },
  });
};

export const notifyFollowUp = (lead) => {
  createNotification({
    type: "follow_up",
    title: "Follow-up due",
    message: `Follow up with ${lead.name} (${lead.project || "lead"})`,
    meta: { leadId: lead.id },
  });
};

export const notifyCampaignComplete = (campaign) => {
  createNotification({
    type: "campaign",
    title: "Campaign sent",
    message: `"${campaign.name}" delivered to ${campaign.sent_count || 0} recipients.`,
    meta: { campaignId: campaign.id },
  });
};

export const notifyLogin = (user, ip) => {
  createNotification({
    type: "login",
    title: "Admin sign-in",
    message: `${user.name || user.email} signed in from ${ip || "unknown IP"}.`,
    user_id: user.id,
    meta: { ip },
  });
};
