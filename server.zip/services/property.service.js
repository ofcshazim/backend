import { dbProperties } from "../db/database.js";
import { logAdminAction } from "./audit.service.js";

export const listProperties = (filters = {}) => dbProperties.list(filters);

export const getProperty = (idOrSlug) => dbProperties.get(idOrSlug);

export const listPublishedProperties = () =>
  dbProperties.list({ status: "published", limit: 200 });

export const createProperty = (payload, actor) => {
  const record = dbProperties.insert({
    slug: payload.slug || slugify(payload.name),
    name: payload.name,
    location: payload.location || "",
    location_access: payload.location_access || "",
    type: payload.type || "Housing Society",
    status_label: payload.status_label || "Available",
    availability: payload.availability || "available",
    price_range: payload.price_range || "",
    payment_plan: payload.payment_plan || "",
    roi: payload.roi || "",
    summary: payload.summary || "",
    features: payload.features || [],
    gallery: payload.gallery || [],
    floor_plans: payload.floor_plans || [],
    map_lat: payload.map_lat || null,
    map_lng: payload.map_lng || null,
    seo_title: payload.seo_title || payload.name,
    seo_description: payload.seo_description || "",
    featured: Boolean(payload.featured),
    inquiry_count: 0,
    publish_status: payload.publish_status || "draft",
    img: payload.img || "",
    who_should_buy: payload.who_should_buy || [],
    who_should_avoid: payload.who_should_avoid || [],
    risks: payload.risks || [],
    document_checklist: payload.document_checklist || [],
  });

  logAdminAction({ admin: actor }, "property_create", { propertyId: record.id, slug: record.slug });
  return record;
};

export const updateProperty = (id, patch, actor) => {
  const updated = dbProperties.update(id, {
    ...patch,
    updated_at: new Date().toISOString(),
  });
  if (updated) {
    logAdminAction({ admin: actor }, "property_update", { propertyId: id });
  }
  return updated;
};

export const deleteProperty = (id, actor) => {
  dbProperties.delete(id);
  logAdminAction({ admin: actor }, "property_delete", { propertyId: id });
};

export const incrementPropertyInquiries = (slugOrProject) => {
  const prop = dbProperties.findBySlug(slugOrProject) || dbProperties.findByNameMatch(slugOrProject);
  if (prop) {
    dbProperties.update(prop.id, { inquiry_count: (prop.inquiry_count || 0) + 1 });
  }
};

const slugify = (text) =>
  String(text)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
