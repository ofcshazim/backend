import { dbRoles, dbAdminUsers } from "../db/database.js";
import { DEFAULT_ROLE_DEFINITIONS, ROLES, ALL_PERMISSIONS, PERMISSIONS } from "../constants/rbac.js";
import { env } from "../config/env.js";

export const seedRoles = () => {
  for (const def of DEFAULT_ROLE_DEFINITIONS) {
    if (!dbRoles.findByKey(def.key)) {
      dbRoles.insert({
        key: def.key,
        name: def.name,
        permissions: def.permissions,
        is_system: def.is_system,
      });
    }
  }
};

export const listRoles = () => dbRoles.list();

export const getRoleByKey = (key) => dbRoles.findByKey(key);

export const updateRolePermissions = (key, permissions) => {
  const role = dbRoles.findByKey(key);
  if (!role) return null;
  const valid = permissions.filter((p) => ALL_PERMISSIONS.includes(p));
  return dbRoles.update(key, { permissions: valid });
};

export const resolveUserPermissions = (user) => {
  if (!user) return [];

  seedRoles();

  const envEmail = env.admin.email.trim().toLowerCase();
  const roleKey = user.role_key || ROLES.SALES_AGENT;

  if (roleKey === ROLES.SUPER_ADMIN) {
    return [...ALL_PERMISSIONS];
  }

  if (user.email === envEmail && (user.id === 1 || roleKey === ROLES.ADMIN)) {
    const role = dbRoles.findByKey(ROLES.SUPER_ADMIN) || dbRoles.findByKey(ROLES.ADMIN);
    if (role?.permissions?.length) return [...role.permissions];
    return [...ALL_PERMISSIONS];
  }

  const role = dbRoles.findByKey(roleKey);
  const base = role?.permissions?.length ? role.permissions : [];

  const override = Array.isArray(user.permissions_override) ? user.permissions_override : [];
  const merged = [...new Set([...base, ...override])];

  if (merged.length === 0 && roleKey === ROLES.ADMIN) {
    return ALL_PERMISSIONS.filter((p) => p !== PERMISSIONS.VIEW_AUDIT);
  }

  return merged;
};

export const userHasPermission = (user, permission) => {
  const perms = resolveUserPermissions(user);
  if (perms.includes(permission)) return true;
  if (perms.includes(ROLES.SUPER_ADMIN)) return true;
  const role = user?.role_key;
  if (role === ROLES.SUPER_ADMIN) return true;
  return false;
};

export const sanitizeUser = (user) => {
  if (!user) return null;
  const { password_hash, ...rest } = user;
  return {
    ...rest,
    permissions: resolveUserPermissions(user),
  };
};
