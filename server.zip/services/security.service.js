import { env } from "../config/env.js";
import { dbSecurityLogs } from "../db/database.js";
import { logger } from "../utils/logger.js";

const loginAttempts = new Map();
const bannedIps = new Map();

const isDev = () => env.nodeEnv === "development";

const MAX_ATTEMPTS = Number(process.env.ADMIN_LOGIN_MAX_ATTEMPTS || 10);
const LOCKOUT_MS = Number(process.env.ADMIN_LOGIN_LOCKOUT_MS || 10 * 60 * 1000);
const BAN_MS = Number(process.env.IP_BAN_DURATION_MS || 60 * 60 * 1000);

export const getClientIp = (req) =>
  req.headers["x-forwarded-for"]?.toString().split(",")[0]?.trim() ||
  req.socket?.remoteAddress ||
  "unknown";

export const isIpBanned = (ip) => {
  if (isDev()) return false;
  const ban = bannedIps.get(ip);
  if (!ban) return false;
  if (Date.now() > ban.until) {
    bannedIps.delete(ip);
    return false;
  }
  return true;
};

export const recordLoginFailure = (ip, email) => {
  if (isDev()) {
    return { locked: false, retryAfterMs: 0, attempts: 0 };
  }

  const entry = loginAttempts.get(ip) || { count: 0, firstAt: Date.now() };
  entry.count += 1;
  entry.lastAt = Date.now();
  entry.lastEmail = email;
  loginAttempts.set(ip, entry);

  dbSecurityLogs.insert({
    type: "login_failed",
    ip,
    email,
    attempts: entry.count,
  });
  logger.security("[SECURITY] Failed admin login", { ip, email, attempts: entry.count });

  if (entry.count >= MAX_ATTEMPTS * 2) {
    bannedIps.set(ip, { until: Date.now() + BAN_MS, reason: "brute_force" });
    logger.security("[SECURITY] IP banned", { ip, durationMs: BAN_MS });
  }

  return {
    locked: entry.count >= MAX_ATTEMPTS,
    retryAfterMs: entry.count >= MAX_ATTEMPTS ? LOCKOUT_MS : 0,
    attempts: entry.count,
  };
};

export const recordLoginSuccess = (ip, email) => {
  loginAttempts.delete(ip);
  if (!isDev()) {
    dbSecurityLogs.insert({ type: "login_success", ip, email });
  }
};

export const isLoginLocked = (ip) => {
  if (isDev()) return false;
  const entry = loginAttempts.get(ip);
  if (!entry) return false;
  if (entry.count < MAX_ATTEMPTS) return false;
  if (Date.now() - entry.lastAt > LOCKOUT_MS) {
    loginAttempts.delete(ip);
    return false;
  }
  return true;
};

export const clearLoginAttempts = (ip) => {
  loginAttempts.delete(ip);
  bannedIps.delete(ip);
};

export const logSuspiciousRequest = (req, reason) => {
  const ip = getClientIp(req);
  dbSecurityLogs.insert({
    type: "suspicious",
    ip,
    reason,
    path: req.originalUrl,
    method: req.method,
    userAgent: req.headers["user-agent"]?.slice(0, 200),
  });
  logger.security("[SECURITY] Suspicious request", { ip, reason, path: req.originalUrl });
};
