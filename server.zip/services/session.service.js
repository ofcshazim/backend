import crypto from "crypto";
import { env } from "../config/env.js";

/** In-memory admin sessions (no JWT). */
const activeSessions = new Map();
const SESSION_TTL_MS = Number(process.env.SESSION_TTL_MS || 7 * 24 * 60 * 60 * 1000);

export const createSession = (user) => {
  const sessionId = crypto.randomBytes(32).toString("hex");
  activeSessions.set(sessionId, {
    userId: user.id,
    email: user.email,
    name: user.name,
    role_key: user.role_key || "super_admin",
    permissions: user.permissions || [],
    avatar_url: user.avatar_url || "",
    createdAt: Date.now(),
  });
  return sessionId;
};

export const getSession = (sessionId) => {
  if (!sessionId) return null;
  const session = activeSessions.get(sessionId);
  if (!session) return null;
  if (Date.now() - session.createdAt > SESSION_TTL_MS) {
    activeSessions.delete(sessionId);
    return null;
  }
  return session;
};

export const updateSession = (sessionId, patch) => {
  const session = activeSessions.get(sessionId);
  if (!session) return null;
  Object.assign(session, patch);
  return session;
};

export const destroySession = (sessionId) => {
  if (sessionId) activeSessions.delete(sessionId);
};

export const clearAllSessions = () => activeSessions.clear();

export const getActiveSessionCount = () => activeSessions.size;
