import { dbSettings } from "../db/database.js";

export const getAllSettings = () => dbSettings.all();

export const updateSettings = (patch) => {
  dbSettings.setMany(patch);
  return getAllSettings();
};
