import fs from "fs";
import os from "os";
import path from "path";
import { getStore, getStorePath, dbWhatsAppMessages } from "../db/database.js";
import { getActiveSessionCount } from "./session.service.js";
import { authkeyStatus } from "./authkey.service.js";
import { smtpStatus } from "../utils/mail-transport.js";
import { getUptimeSeconds } from "../utils/uptime.js";
import { env, isAuthkeyConfigured, isSmtpConfigured, isWhatsAppConfigured } from "../config/env.js";
import { API_VERSION } from "../utils/banner.js";
import { getQueueStats } from "./whatsappQueue.service.js";
import { dbSecurityLogs } from "../db/database.js";

const MAX_LATENCY_SAMPLES = 120;
const MAX_ERROR_LOGS = 200;
const RPM_WINDOW_MS = 60_000;

const state = {
  startedAt: Date.now(),
  totalRequests: 0,
  failedRequests: 0,
  requestTimestamps: [],
  latencySamples: [],
  dbLatencySamples: [],
  authkeyLatencySamples: [],
  errors: [],
  lastHealthCheck: null,
  lastPingMs: null,
};

const pushSample = (arr, value, max = MAX_LATENCY_SAMPLES) => {
  arr.push(value);
  if (arr.length > max) arr.shift();
};

const latencyGrade = (ms) => {
  if (ms < 100) return { label: "Excellent", level: "excellent" };
  if (ms < 300) return { label: "Good", level: "good" };
  if (ms < 500) return { label: "Fair", level: "fair" };
  return { label: "Slow", level: "slow" };
};

const statsFromSamples = (samples) => {
  if (!samples.length) return { avg: 0, min: 0, max: 0, latest: 0 };
  const sum = samples.reduce((a, b) => a + b, 0);
  return {
    avg: Math.round(sum / samples.length),
    min: Math.min(...samples),
    max: Math.max(...samples),
    latest: samples[samples.length - 1],
  };
};

export const recordRequest = (req, res, durationMs) => {
  state.totalRequests += 1;
  state.requestTimestamps.push(Date.now());
  const cutoff = Date.now() - RPM_WINDOW_MS;
  state.requestTimestamps = state.requestTimestamps.filter((t) => t >= cutoff);

  if (res.statusCode >= 400) {
    state.failedRequests += 1;
    recordError({
      type: res.statusCode >= 500 ? "server_error" : "client_error",
      message: `${req.method} ${req.originalUrl} → ${res.statusCode}`,
      path: req.originalUrl,
      status: res.statusCode,
      ms: durationMs,
    });
  }

  if (!req.originalUrl.includes("/health") && !req.originalUrl.includes("/ping")) {
    pushSample(state.latencySamples, durationMs);
  }
};

export const recordError = (entry) => {
  state.errors.unshift({
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    timestamp: new Date().toISOString(),
    ...entry,
  });
  if (state.errors.length > MAX_ERROR_LOGS) state.errors.length = MAX_ERROR_LOGS;
};

export const recordAuthkeyFailure = (message) => {
  recordError({ type: "authkey_failure", message, source: "authkey" });
};

export const measureDatabasePing = () => {
  const start = Date.now();
  try {
    getStore();
    const ms = Date.now() - start;
    pushSample(state.dbLatencySamples, ms, 60);
    return { ok: true, ms, status: "connected" };
  } catch (err) {
    recordError({ type: "database", message: err.message, source: "database" });
    return { ok: false, ms: Date.now() - start, status: "disconnected", error: err.message };
  }
};

export const measureAuthkeyPing = async () => {
  if (!isAuthkeyConfigured()) {
    return { ok: false, ms: 0, status: "not_configured", skipped: true };
  }
  const start = Date.now();
  try {
    const url = `${env.authkey.balanceUrl}?authkey=${encodeURIComponent(env.authkey.authKey)}`;
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 8000);
    const res = await fetch(url, { signal: controller.signal });
    clearTimeout(timer);
    const ms = Date.now() - start;
    pushSample(state.authkeyLatencySamples, ms, 60);
    if (!res.ok) {
      recordAuthkeyFailure(`Authkey HTTP ${res.status}`);
      return { ok: false, ms, status: "unreachable", statusCode: res.status };
    }
    return { ok: true, ms, status: "reachable", statusCode: res.status };
  } catch (err) {
    const ms = Date.now() - start;
    recordAuthkeyFailure(err.message);
    return { ok: false, ms, status: "unreachable", error: err.message };
  }
};

const getDirectorySize = (dir) => {
  if (!fs.existsSync(dir)) return 0;
  let total = 0;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) total += getDirectorySize(full);
    else {
      try {
        total += fs.statSync(full).size;
      } catch {
        /* ignore */
      }
    }
  }
  return total;
};

export const getDiskInfo = () => {
  const storePath = getStorePath();
  let storeBytes = 0;
  try {
    if (fs.existsSync(storePath)) storeBytes = fs.statSync(storePath).size;
  } catch {
    /* ignore */
  }
  const uploadsBytes = getDirectorySize(path.join(process.cwd(), "uploads"));
  return {
    databaseFileBytes: storeBytes,
    uploadsBytes,
    totalDataBytes: storeBytes + uploadsBytes,
  };
};

export const getRecordCounts = () => {
  try {
    const store = getStore();
    return {
      inquiries: store.inquiries?.length ?? 0,
      emailLogs: store.email_logs?.length ?? 0,
      whatsappLogs: store.whatsapp_logs?.length ?? 0,
      whatsappMessages: store.whatsapp_messages?.length ?? 0,
      campaigns: store.whatsapp_campaigns?.length ?? 0,
      contacts: store.whatsapp_contacts?.length ?? 0,
      adminUsers: store.admin_users?.length ?? 0,
      total:
        (store.inquiries?.length ?? 0) +
        (store.email_logs?.length ?? 0) +
        (store.whatsapp_messages?.length ?? 0) +
        (store.whatsapp_logs?.length ?? 0),
    };
  } catch {
    return { total: 0, inquiries: 0 };
  }
};

export const getRequestsPerMinute = () => state.requestTimestamps.length;

export const getErrorLogs = ({ q, type, limit = 50 } = {}) => {
  let rows = [...state.errors];
  if (type) rows = rows.filter((e) => e.type === type);
  if (q) {
    const needle = q.toLowerCase();
    rows = rows.filter(
      (e) =>
        e.message?.toLowerCase().includes(needle) ||
        e.path?.toLowerCase().includes(needle) ||
        e.type?.toLowerCase().includes(needle)
    );
  }
  const security = dbSecurityLogs.list(30).map((s) => ({
    id: `sec-${s.id}`,
    timestamp: s.created_at,
    type: s.type || "security",
    message: s.detail || s.email || s.type,
    source: "security",
  }));
  return [...rows, ...security].slice(0, limit);
};

export const buildSystemHealth = async () => {
  const checkStart = Date.now();
  const dbPing = measureDatabasePing();
  const authkeyPing = await measureAuthkeyPing();
  const apiLatency = Date.now() - checkStart;

  state.lastHealthCheck = new Date().toISOString();
  state.lastPingMs = apiLatency;
  pushSample(state.latencySamples, apiLatency);

  const mem = process.memoryUsage();
  const load = os.loadavg();
  const apiStats = statsFromSamples(state.latencySamples);
  const dbStats = statsFromSamples(state.dbLatencySamples);
  const authkeyStats = statsFromSamples(state.authkeyLatencySamples);

  const online = true;
  const failedWhatsApp = dbWhatsAppMessages.count("failed");
  const lowBalance =
    authkeyStatus.balance != null &&
    Number(authkeyStatus.balance) < env.authkey.lowBalanceThreshold;

  const alerts = [];
  if (!online) alerts.push({ level: "critical", message: "API is offline" });
  if (apiStats.latest > 500) alerts.push({ level: "warning", message: "High API latency detected" });
  if (!dbPing.ok) alerts.push({ level: "critical", message: "Database disconnected" });
  if (lowBalance) alerts.push({ level: "warning", message: "Authkey balance is low" });
  if (!authkeyStatus.ready && isWhatsAppConfigured())
    alerts.push({ level: "warning", message: "Authkey integration offline" });

  return {
    status: online ? "online" : "offline",
    online,
    lastChecked: state.lastHealthCheck,
    responseStatusCode: 200,
    uptime: {
      seconds: getUptimeSeconds(),
      formatted: formatUptime(getUptimeSeconds()),
      startedAt: new Date(state.startedAt).toISOString(),
    },
    latency: {
      livePingMs: apiLatency,
      api: { ...apiStats, grade: latencyGrade(apiStats.latest || apiLatency) },
      database: { ...dbStats, grade: latencyGrade(dbPing.ms), lastMs: dbPing.ms },
      authkey: { ...authkeyStats, grade: latencyGrade(authkeyPing.ms || 0), lastMs: authkeyPing.ms },
    },
    server: {
      environment: env.nodeEnv,
      nodeVersion: process.version,
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      platform: process.platform,
      memory: {
        rss: mem.rss,
        heapUsed: mem.heapUsed,
        heapTotal: mem.heapTotal,
        systemTotal: os.totalmem(),
        systemFree: os.freemem(),
        usedPercent: Math.round((1 - os.freemem() / os.totalmem()) * 100),
      },
      cpu: {
        load1m: load[0],
        load5m: load[1],
        cores: os.cpus().length,
      },
      disk: getDiskInfo(),
    },
    requests: {
      total: state.totalRequests,
      failed: state.failedRequests,
      perMinute: getRequestsPerMinute(),
      activeSessions: getActiveSessionCount(),
    },
    database: {
      status: dbPing.ok ? "connected" : "disconnected",
      responseTimeMs: dbPing.ms,
      records: getRecordCounts(),
    },
    authkey: {
      configured: isWhatsAppConfigured(),
      reachable: authkeyPing.ok,
      ready: authkeyStatus.ready,
      balance: authkeyStatus.balance,
      balanceCheckedAt: authkeyStatus.balanceCheckedAt,
      lastError: authkeyStatus.lastError,
      verifiedAt: authkeyStatus.verifiedAt,
      failedCalls: failedWhatsApp,
      responseTimeMs: authkeyPing.ms,
      queue: getQueueStats(),
      lowBalance,
      lowBalanceThreshold: env.authkey.lowBalanceThreshold,
    },
    smtp: {
      configured: isSmtpConfigured(),
      ready: smtpStatus.ready,
      error: smtpStatus.lastError,
    },
    version: API_VERSION,
    alerts,
  };
};

const formatUptime = (seconds) => {
  const d = Math.floor(seconds / 86400);
  const h = Math.floor((seconds % 86400) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  if (d > 0) return `${d}d ${h}h ${m}m`;
  if (h > 0) return `${h}h ${m}m ${s}s`;
  return `${m}m ${s}s`;
};

export const getSystemPing = async () => {
  const start = Date.now();
  measureDatabasePing();
  const authkey = await measureAuthkeyPing();
  const ms = Date.now() - start;
  state.lastPingMs = ms;
  return {
    ok: true,
    pingMs: ms,
    grade: latencyGrade(ms),
    databaseMs: state.dbLatencySamples.at(-1) ?? 0,
    authkeyMs: authkey.ms,
    timestamp: new Date().toISOString(),
  };
};

export const getSystemStats = () => ({
  requests: {
    total: state.totalRequests,
    failed: state.failedRequests,
    perMinute: getRequestsPerMinute(),
    activeSessions: getActiveSessionCount(),
  },
  latency: {
    api: statsFromSamples(state.latencySamples),
    database: statsFromSamples(state.dbLatencySamples),
    authkey: statsFromSamples(state.authkeyLatencySamples),
  },
  records: getRecordCounts(),
  version: API_VERSION,
});

export const getSystemUptime = () => ({
  seconds: getUptimeSeconds(),
  formatted: formatUptime(getUptimeSeconds()),
  startedAt: new Date(state.startedAt).toISOString(),
});

export const getAuthkeyStatus = () => ({
  configured: isWhatsAppConfigured(),
  ready: authkeyStatus.ready,
  balance: authkeyStatus.balance,
  balanceCheckedAt: authkeyStatus.balanceCheckedAt,
  lastError: authkeyStatus.lastError,
  verifiedAt: authkeyStatus.verifiedAt,
  failedMessages: dbWhatsAppMessages.count("failed"),
  queue: getQueueStats(),
  lowBalance:
    authkeyStatus.balance != null &&
    Number(authkeyStatus.balance) < env.authkey.lowBalanceThreshold,
});

export const exportErrorLogs = () => state.errors;
