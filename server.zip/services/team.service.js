import bcrypt from "bcryptjs";
import { dbAdminUsers } from "../db/database.js";
import { env } from "../config/env.js";
import { ROLES } from "../constants/rbac.js";
import { resolveUserPermissions, sanitizeUser } from "./rbac.service.js";
import { logAdminAction } from "./audit.service.js";
import { createNotification } from "./notification.service.js";

export const authenticateTeamMember = (email, password) => {
  const normalizedEmail = email.trim().toLowerCase();
  const trimmedPassword = password.trim();
  const expectedEmail = env.admin.email.trim().toLowerCase();

  if (normalizedEmail === expectedEmail && trimmedPassword === env.admin.password) {
    let user = dbAdminUsers.findByEmail(expectedEmail);
    if (!user) {
      user = {
        id: 1,
        email: expectedEmail,
        name: env.admin.name,
        role_key: ROLES.SUPER_ADMIN,
        status: "active",
      };
    }
    if (user.status === "suspended") return { ok: false, reason: "suspended" };
    return {
      ok: true,
      user: {
        id: user.id || 1,
        email: expectedEmail,
        name: user.name || env.admin.name,
        role_key: user.role_key || ROLES.SUPER_ADMIN,
        avatar_url: user.avatar_url || "",
        permissions: resolveUserPermissions(user),
      },
    };
  }

  const dbUser = dbAdminUsers.findByEmail(normalizedEmail);
  if (!dbUser) return { ok: false, reason: "email" };
  if (dbUser.status === "suspended") return { ok: false, reason: "suspended" };
  if (!bcrypt.compareSync(trimmedPassword, dbUser.password_hash)) {
    return { ok: false, reason: "password" };
  }

  dbAdminUsers.update(dbUser.id, { last_login_at: new Date().toISOString() });

  return {
    ok: true,
    user: {
      id: dbUser.id,
      email: dbUser.email,
      name: dbUser.name,
      role_key: dbUser.role_key || ROLES.SALES_AGENT,
      avatar_url: dbUser.avatar_url || "",
      permissions: resolveUserPermissions(dbUser),
    },
  };
};

export const listTeamMembers = () =>
  dbAdminUsers.list().map((u) => sanitizeUser(u));

export const getTeamMember = (id) => sanitizeUser(dbAdminUsers.findById(id));

export const createTeamMember = (payload, actor) => {
  const email = payload.email?.trim().toLowerCase();
  if (!email || !payload.password) throw new Error("Email and password required.");
  if (dbAdminUsers.findByEmail(email)) throw new Error("Email already exists.");

  const record = dbAdminUsers.insert({
    email,
    password_hash: bcrypt.hashSync(payload.password, 12),
    name: payload.name?.trim() || email.split("@")[0],
    role_key: payload.role_key || ROLES.SALES_AGENT,
    status: "active",
    phone: payload.phone || "",
    title: payload.title || "",
    avatar_url: payload.avatar_url || "",
    permissions_override: payload.permissions_override || [],
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  });

  logAdminAction(
    { admin: actor },
    "team_create",
    { targetId: record.id, email: record.email }
  );

  createNotification({
    type: "user_activity",
    title: "New team member added",
    message: `${record.name} (${record.email}) was created by ${actor?.name || "Admin"}.`,
    meta: { userId: record.id },
  });

  return sanitizeUser(record);
};

export const updateTeamMember = (id, patch, actor) => {
  const user = dbAdminUsers.findById(id);
  if (!user) return null;

  const updates = { updated_at: new Date().toISOString() };
  if (patch.name !== undefined) updates.name = patch.name.trim();
  if (patch.phone !== undefined) updates.phone = patch.phone;
  if (patch.title !== undefined) updates.title = patch.title;
  if (patch.role_key !== undefined) updates.role_key = patch.role_key;
  if (patch.status !== undefined) updates.status = patch.status;
  if (patch.avatar_url !== undefined) updates.avatar_url = patch.avatar_url;
  if (patch.permissions_override !== undefined) updates.permissions_override = patch.permissions_override;

  if (patch.password) {
    updates.password_hash = bcrypt.hashSync(patch.password, 12);
  }

  const updated = dbAdminUsers.update(id, updates);
  logAdminAction({ admin: actor }, "team_update", { targetId: id, fields: Object.keys(updates) });
  return sanitizeUser(updated);
};

export const resetTeamPassword = (id, newPassword, actor) => {
  if (!newPassword || newPassword.length < 8) throw new Error("Password must be at least 8 characters.");
  return updateTeamMember(id, { password: newPassword }, actor);
};

export const suspendTeamMember = (id, actor) =>
  updateTeamMember(id, { status: "suspended" }, actor);

export const reactivateTeamMember = (id, actor) =>
  updateTeamMember(id, { status: "active" }, actor);
