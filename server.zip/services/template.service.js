import { dbTemplates } from "../db/database.js";

export const renderTemplate = (html, vars = {}) => {
  let out = html;
  for (const [key, value] of Object.entries(vars)) {
    out = out.replaceAll(`{{${key}}}`, String(value ?? ""));
  }
  return out;
};

export const getTemplateByKey = (key) => dbTemplates.findByKey(key);

export const listTemplates = () => dbTemplates.list();

export const updateTemplate = (id, { name, subject, html }) =>
  dbTemplates.update(id, {
    name,
    subject,
    html,
    updated_at: new Date().toISOString(),
  });

export const buildFromTemplate = (key, vars) => {
  const tpl = getTemplateByKey(key);
  if (!tpl) return null;
  return {
    subject: renderTemplate(tpl.subject, vars),
    html: renderTemplate(tpl.html, vars),
  };
};
