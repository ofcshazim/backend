/** @deprecated Use whatsappService.js */
export * from "./whatsappService.js";
