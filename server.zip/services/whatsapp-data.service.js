import {
  dbWhatsAppMessages,
  dbWhatsAppCampaigns,
  dbWhatsAppTemplates,
  dbWhatsAppContacts,
  dbUploadedMedia,
  dbScheduledMessages,
} from "../db/database.js";

export const recordWhatsAppMessage = (row) => dbWhatsAppMessages.insert(row);

export const getWhatsAppStats = () => {
  const msgStats = dbWhatsAppMessages.stats();
  const campaigns = dbWhatsAppCampaigns.list({ limit: 1000 });
  return {
    ...msgStats,
    campaigns: campaigns.length,
    activeCampaigns: campaigns.filter((c) => c.status === "running" || c.status === "scheduled").length,
    contacts: dbWhatsAppContacts.count(),
    templates: dbWhatsAppTemplates.list().length,
    scheduledPending: dbScheduledMessages.list({ status: "pending" }).length,
  };
};

export const listMessageHistory = (filters) => dbWhatsAppMessages.list(filters);

export const listCampaigns = (filters) => dbWhatsAppCampaigns.list(filters);

export const getCampaign = (id) => dbWhatsAppCampaigns.get(id);

export const createCampaign = (data) => dbWhatsAppCampaigns.insert(data);

export const updateCampaign = (id, data) => dbWhatsAppCampaigns.update(id, data);

export const duplicateCampaign = (id) => dbWhatsAppCampaigns.duplicate(id);

export const listLocalTemplates = () => dbWhatsAppTemplates.list();

export const saveLocalTemplate = (data) => {
  const existing = data.key ? dbWhatsAppTemplates.findByKey(data.key) : null;
  if (existing) return dbWhatsAppTemplates.update(existing.id, data);
  return dbWhatsAppTemplates.insert(data);
};

export const deleteLocalTemplate = (id) => dbWhatsAppTemplates.delete(id);

export const listContacts = (filters) => dbWhatsAppContacts.list(filters);

export const saveContact = (data) => dbWhatsAppContacts.insert(data);

export const updateContact = (id, data) => dbWhatsAppContacts.update(id, data);

export const deleteContact = (id) => dbWhatsAppContacts.delete(id);

export const importContacts = (rows) => dbWhatsAppContacts.bulkInsert(rows);

export const exportContacts = () => dbWhatsAppContacts.list({ limit: 100000 });

export const recordUploadedMedia = (data) => dbUploadedMedia.insert(data);

export const listUploadedMedia = (limit) => dbUploadedMedia.list({ limit });

export const scheduleMessage = (data) => dbScheduledMessages.insert(data);

export const listScheduledMessages = (status) => dbScheduledMessages.list({ status });

export const markScheduledSent = (id, result) =>
  dbScheduledMessages.update(id, {
    status: "sent",
    sent_at: new Date().toISOString(),
    result,
  });

export const markScheduledFailed = (id, error) =>
  dbScheduledMessages.update(id, {
    status: "failed",
    error: String(error),
  });

export const getDueScheduledMessages = () => dbScheduledMessages.due();
