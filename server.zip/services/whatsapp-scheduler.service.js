import { logger } from "../utils/logger.js";
import { getDueScheduledMessages, markScheduledSent, markScheduledFailed } from "./whatsapp-data.service.js";
import { sendWhatsAppMessage, sendBulkCampaign } from "./whatsappService.js";

let timer = null;

const processScheduled = async () => {
  const due = getDueScheduledMessages();
  for (const job of due) {
    try {
      const payload = job.payload || {};
      let result;
      if (payload.bulk && Array.isArray(payload.data)) {
        result = await sendBulkCampaign(payload);
      } else {
        result = await sendWhatsAppMessage(payload);
      }
      markScheduledSent(job.id, result);
      logger.whatsapp("[AUTHKEY] Scheduled message sent", { id: job.id });
    } catch (err) {
      markScheduledFailed(job.id, err.message);
      logger.error("[AUTHKEY] Scheduled message failed", { id: job.id, error: err.message });
    }
  }
};

export const startWhatsAppScheduler = () => {
  if (timer) return;
  timer = setInterval(() => {
    processScheduled().catch((err) =>
      logger.error("[AUTHKEY] Scheduler error", { error: err.message })
    );
  }, 30_000);
  timer.unref?.();
  logger.info("[AUTHKEY] WhatsApp scheduler started (30s interval)");
};

export const stopWhatsAppScheduler = () => {
  if (timer) clearInterval(timer);
  timer = null;
};
