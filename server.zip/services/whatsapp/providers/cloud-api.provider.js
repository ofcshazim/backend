import { env } from "../../../config/env.js";
import { normalizeWhatsAppPhone } from "../../../utils/sanitize.js";
import { logger } from "../../../utils/logger.js";

const API = "https://graph.facebook.com/v19.0";

export const cloudApiProvider = {
  name: "cloud-api",

  async sendMessage({ to, body }) {
    const phone = normalizeWhatsAppPhone(to);
    if (!phone) throw new Error("Invalid WhatsApp recipient");

    const url = `${API}/${env.whatsapp.cloudPhoneId}/messages`;
    const res = await fetch(url, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${env.whatsapp.cloudToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        messaging_product: "whatsapp",
        to: phone,
        type: "text",
        text: { body },
      }),
    });

    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      logger.error("WhatsApp Cloud API error", { status: res.status, data });
      throw new Error(data?.error?.message || "WhatsApp Cloud API failed");
    }
    return { ok: true, data };
  },
};
