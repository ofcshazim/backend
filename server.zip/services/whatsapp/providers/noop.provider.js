export const noopProvider = {
  name: "none",
  async sendMessage() {
    return { ok: false, skipped: true, reason: "WhatsApp provider not configured" };
  },
};
