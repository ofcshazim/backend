import { env } from "../../../config/env.js";
import { normalizeWhatsAppPhone } from "../../../utils/sanitize.js";
import { logger } from "../../../utils/logger.js";

export const twilioProvider = {
  name: "twilio",

  async sendMessage({ to, body }) {
    const phone = normalizeWhatsAppPhone(to);
    if (!phone) throw new Error("Invalid WhatsApp recipient");

    const toWhatsApp = `whatsapp:+${phone}`;
    const from = env.whatsapp.twilioFrom.startsWith("whatsapp:")
      ? env.whatsapp.twilioFrom
      : `whatsapp:${env.whatsapp.twilioFrom}`;

    const auth = Buffer.from(`${env.whatsapp.twilioSid}:${env.whatsapp.twilioToken}`).toString("base64");
    const params = new URLSearchParams({ To: toWhatsApp, From: from, Body: body });

    const res = await fetch(
      `https://api.twilio.com/2010-04-01/Accounts/${env.whatsapp.twilioSid}/Messages.json`,
      {
        method: "POST",
        headers: {
          Authorization: `Basic ${auth}`,
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: params,
      }
    );

    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      logger.error("Twilio WhatsApp error", { status: res.status, data });
      throw new Error(data?.message || "Twilio WhatsApp failed");
    }
    return { ok: true, data };
  },
};
