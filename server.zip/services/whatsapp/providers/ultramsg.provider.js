import { env } from "../../../config/env.js";
import { normalizeWhatsAppPhone } from "../../../utils/sanitize.js";
import { logger } from "../../../utils/logger.js";

export const ultramsgProvider = {
  name: "ultramsg",

  async sendMessage({ to, body }) {
    const phone = normalizeWhatsAppPhone(to);
    if (!phone) throw new Error("Invalid WhatsApp recipient");

    const url = `https://api.ultramsg.com/${env.whatsapp.ultramsgInstance}/messages/chat`;
    const params = new URLSearchParams({
      token: env.whatsapp.ultramsgToken,
      to: `+${phone}`,
      body,
    });

    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: params,
    });

    const data = await res.json().catch(() => ({}));
    if (!res.ok || data.sent === false) {
      logger.error("UltraMsg error", { status: res.status, data });
      throw new Error(data?.error || "UltraMsg failed");
    }
    return { ok: true, data };
  },
};
