import { env, isWhatsAppConfigured } from "../../config/env.js";
import { logger } from "../../utils/logger.js";
import { noopProvider } from "./providers/noop.provider.js";
import { cloudApiProvider } from "./providers/cloud-api.provider.js";
import { twilioProvider } from "./providers/twilio.provider.js";
import { ultramsgProvider } from "./providers/ultramsg.provider.js";

const providers = {
  none: noopProvider,
  "cloud-api": cloudApiProvider,
  twilio: twilioProvider,
  ultramsg: ultramsgProvider,
};

const getProvider = () => {
  const key = env.whatsapp.provider;
  return providers[key] || noopProvider;
};

/** Low-level send — swap provider via WHATSAPP_PROVIDER env */
export const sendWhatsAppMessage = async ({ to, body }) => {
  if (!isWhatsAppConfigured()) {
    return { ok: false, skipped: true };
  }
  const provider = getProvider();
  try {
    const result = await provider.sendMessage({ to, body });
    logger.info("WhatsApp message sent", { provider: provider.name, to });
    return result;
  } catch (err) {
    logger.error("WhatsApp send failed", { provider: provider.name, error: err.message });
    throw err;
  }
};

const formatLeadMessage = (lead) =>
  [
    `🏠 *New inquiry — ${env.siteName}*`,
    ``,
    `*Name:* ${lead.name}`,
    `*Phone:* ${lead.phone}`,
    `*Email:* ${lead.email}`,
    lead.budget ? `*Budget:* ${lead.budget}` : null,
    lead.timeline ? `*Timeline:* ${lead.timeline}` : null,
    lead.project ? `*Project:* ${lead.project}` : null,
    ``,
    `*Message:*`,
    lead.message,
    ``,
    `_Source: ${lead.source} · ${lead.createdAt}_`,
  ]
    .filter(Boolean)
    .join("\n");

/** Notify admin team numbers when a lead arrives */
export const sendLeadNotification = async (lead) => {
  const phones = env.whatsapp.adminPhones;
  if (!phones.length) {
    logger.warn("WHATSAPP_ADMIN_PHONES not set — skipping admin WhatsApp notification");
    return { ok: false, skipped: true };
  }

  const body = formatLeadMessage(lead);
  const results = [];

  for (const phone of phones) {
    try {
      results.push(await sendWhatsAppMessage({ to: phone, body }));
    } catch (err) {
      results.push({ ok: false, phone, error: err.message });
    }
  }

  return { ok: results.some((r) => r.ok), results };
};

/** Optional auto-reply to customer WhatsApp (same number they entered) */
export const sendAutoReply = async (lead) => {
  if (!env.whatsapp.sendCustomerAutoReply || !lead.phone) {
    return { ok: false, skipped: true };
  }

  const firstName = lead.name.split(/\s+/)[0] || "there";
  const body = [
    `Hi ${firstName}, thank you for contacting ${env.siteName}.`,
    `We received your property inquiry and will respond within one business day.`,
    `For urgent matters call ${env.companyPhone}.`,
  ].join("\n\n");

  return sendWhatsAppMessage({ to: lead.phone, body });
};

export const notifyLeadViaWhatsApp = async (lead) => {
  const admin = await sendLeadNotification(lead);
  let customer = { ok: false, skipped: true };
  try {
    customer = await sendAutoReply(lead);
  } catch (err) {
    logger.warn("WhatsApp customer auto-reply failed", { error: err.message });
  }
  return { admin, customer };
};
