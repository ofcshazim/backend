import crypto from "crypto";
import { env } from "../config/env.js";
import { logger } from "../utils/logger.js";
import { authkeyStatus } from "./authkey.service.js";
import { logWhatsApp } from "./log.service.js";
import { recordWhatsAppMessage } from "./whatsapp-data.service.js";

const queue = [];
let processing = false;
const recentHashes = new Map();
const DEDUPE_WINDOW_MS = 60_000;
const MAX_RETRIES = 3;
const RETRY_DELAY_MS = 2000;

const dedupeKey = (to, message) =>
  crypto.createHash("sha256").update(`${to}:${message}`).digest("hex").slice(0, 16);

const isDuplicate = (key) => {
  const last = recentHashes.get(key);
  return Boolean(last && Date.now() - last < DEDUPE_WINDOW_MS);
};

const markSent = (key) => recentHashes.set(key, Date.now());
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const processQueue = async () => {
  if (processing) return;
  processing = true;

  while (queue.length) {
    const job = queue.shift();
    const key = dedupeKey(job.to, job.message);

    if (isDuplicate(key)) {
      logger.whatsapp("[AUTHKEY] Duplicate send prevented", { to: job.to });
      job.resolve?.({ ok: false, skipped: true, reason: "duplicate" });
      continue;
    }

    if (!env.authkey.enabled || !authkeyStatus.ready) {
      logWhatsApp({
        inquiryId: job.inquiryId,
        to: job.to,
        message: job.message,
        templateKey: job.templateKey,
        status: "queued",
        delivery_status: "offline",
        error: authkeyStatus.lastError || "Authkey offline",
      });
      recordWhatsAppMessage({
        to_phone: job.to,
        template_key: job.templateKey,
        inquiry_id: job.inquiryId,
        message_type: job.requestPayload?.type || "text",
        request_payload: job.requestPayload,
        status: "queued",
        delivery_status: "offline",
        error: authkeyStatus.lastError || "Authkey offline",
      });
      job.resolve?.({ ok: false, skipped: true, reason: "authkey_offline" });
      continue;
    }

    let lastError = null;
    for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
      try {
        const result = await job.sendFn();
        logWhatsApp({
          inquiryId: job.inquiryId,
          to: job.to,
          message: job.message,
          templateKey: job.templateKey,
          status: "sent",
          delivery_status: "delivered",
          attempts: attempt,
        });
        markSent(key);
        logger.whatsapp("[AUTHKEY] Message sent", { to: job.to, attempt });
        job.resolve?.({ ok: true, result });
        lastError = null;
        break;
      } catch (err) {
        lastError = err;
        if (attempt < MAX_RETRIES) await sleep(RETRY_DELAY_MS * attempt);
      }
    }

    if (lastError) {
      logWhatsApp({
        inquiryId: job.inquiryId,
        to: job.to,
        message: job.message,
        templateKey: job.templateKey,
        status: "failed",
        delivery_status: "failed",
        error: lastError.message,
        attempts: MAX_RETRIES,
      });
      recordWhatsAppMessage({
        to_phone: job.to,
        template_key: job.templateKey,
        inquiry_id: job.inquiryId,
        message_type: job.requestPayload?.type || "text",
        request_payload: job.requestPayload,
        status: "failed",
        delivery_status: "failed",
        error: lastError.message,
        retries: MAX_RETRIES,
      });
      job.resolve?.({ ok: false, error: lastError.message });
    }
  }

  processing = false;
};

export const enqueueWhatsApp = (job) =>
  new Promise((resolve) => {
    queue.push({ ...job, resolve, reject: resolve });
    processQueue().catch((err) => logger.error("[AUTHKEY] Queue error", { error: err.message }));
  });

export const getQueueStats = () => ({
  pending: queue.length,
  processing,
});
