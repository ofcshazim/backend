import { env, isWhatsAppConfigured } from "../config/env.js";
import { validatePhoneNumber } from "../utils/sanitize.js";
import { logger } from "../utils/logger.js";
import { enqueueWhatsApp } from "./whatsappQueue.service.js";
import { getWhatsAppTemplate } from "../templates/whatsapp/messages.js";
import {
  authkeyStatus,
  verifyAuthkeyConnection,
  sendTextTemplate,
  sendMediaTemplate,
  sendDynamicButtonTemplate,
  sendCopyCodeTemplate,
  sendLimitedTimeOfferTemplate,
  sendBulkInChunks,
  parsePhoneForAuthkey,
} from "./authkey.service.js";
import { recordWhatsAppMessage } from "./whatsapp-data.service.js";
import { listLocalTemplates } from "./whatsapp-data.service.js";

export { authkeyStatus };
export const wapiStatus = authkeyStatus;
export const verifyWapiConnection = verifyAuthkeyConnection;

const buildTextPayload = ({ to, wid, bodyValues, inquiryId, templateKey, campaignId }) => ({
  phone: to,
  wid,
  bodyValues,
  meta: { inquiryId, templateKey, campaignId, type: "text" },
});

const dispatchAuthkey = async (payload) => {
  const { type = "text", meta = {} } = payload;

  let response;
  if (type === "media") {
    response = await sendMediaTemplate(payload);
  } else if (type === "button") {
    response = await sendDynamicButtonTemplate(payload);
  } else if (type === "copy_code") {
    response = await sendCopyCodeTemplate(payload);
  } else if (type === "lto") {
    response = await sendLimitedTimeOfferTemplate(payload);
  } else {
    response = await sendTextTemplate(payload);
  }

  recordWhatsAppMessage({
    to_phone: payload.phone || `${payload.country_code}${payload.mobile}`,
    template_key: meta.templateKey,
    template_wid: payload.wid,
    inquiry_id: meta.inquiryId,
    campaign_id: meta.campaignId,
    message_type: type,
    request_payload: payload,
    response_payload: response,
    status: "sent",
    delivery_status: "sent",
  });

  return response;
};

export const sendWhatsAppMessage = async ({
  to,
  message,
  inquiryId,
  templateKey,
  wid,
  bodyValues,
  type = "text",
  headerValues,
  button_param_value,
  copy_code_value,
  expiration_time_ms,
  campaignId,
}) => {
  if (!env.authkey.enabled || !isWhatsAppConfigured()) {
    logger.whatsapp("[AUTHKEY] Skipped — not configured");
    return { ok: false, skipped: true, reason: "Authkey not configured" };
  }

  const validation = validatePhoneNumber(to);
  if (!validation.valid) {
    throw new Error(validation.error || "Invalid phone number");
  }

  const phone = validation.normalized;
  const templateWid = wid || env.whatsapp.defaultTextWid;

  if (!templateWid && !message) {
    throw new Error("Template ID (wid) is required for Authkey WhatsApp messages");
  }

  const values =
    bodyValues ||
    (message
      ? { 1: message }
      : getWhatsAppTemplate(templateKey, {}) && { 1: getWhatsAppTemplate(templateKey, {}) });

  const payload = {
    phone,
    wid: templateWid,
    bodyValues: values || { 1: message || "Hello" },
    type,
    headerValues,
    button_param_value,
    copy_code_value,
    expiration_time_ms,
    meta: { inquiryId, templateKey, campaignId, type },
  };

  return enqueueWhatsApp({
    to: phone,
    message: message || JSON.stringify(values),
    inquiryId,
    templateKey,
    requestPayload: payload,
    sendFn: () => dispatchAuthkey(payload),
  });
};

export const sendTemplateMessage = async ({ to, templateKey, variables, inquiryId, wid }) => {
  const local = listLocalTemplates().find((t) => t.key === templateKey);
  const templateWid = wid || local?.wid || env.whatsapp.defaultTextWid;
  const localTemplate = getWhatsAppTemplate(templateKey, variables);
  const bodyValues = {};
  if (variables && typeof variables === "object") {
    Object.entries(variables).forEach(([key, val], idx) => {
      bodyValues[String(idx + 1)] = String(val);
      if (/^\d+$/.test(key)) bodyValues[key] = String(val);
    });
  }
  if (localTemplate && !Object.keys(bodyValues).length) {
    bodyValues["1"] = localTemplate;
  }
  return sendWhatsAppMessage({
    to,
    templateKey,
    inquiryId,
    wid: templateWid,
    bodyValues,
    type: local?.type || "text",
  });
};

export const sendMediaMessage = async (payload) =>
  sendWhatsAppMessage({ ...payload, type: "media" });

export const sendBulkCampaign = async (payload) => {
  if (!isWhatsAppConfigured()) {
    return { ok: false, skipped: true, reason: "Authkey not configured" };
  }
  const result = await sendBulkInChunks(payload);
  recordWhatsAppMessage({
    to_phone: "bulk",
    template_wid: payload.wid,
    campaign_id: payload.campaignId,
    message_type: payload.type || "text",
    request_payload: payload,
    response_payload: result,
    status: "sent",
    delivery_status: "sent",
    recipient_count: payload.data?.length || 0,
  });
  return { ok: true, result };
};

export const sendInquiryNotification = async (lead) => {
  const phones = env.whatsapp.adminPhones;
  if (!phones.length) {
    logger.warn("[AUTHKEY] WHATSAPP_ADMIN_PHONES is empty");
    return { ok: false };
  }

  const bodyValues = {
    1: lead.name,
    2: lead.project || "General inquiry",
    3: lead.phone,
    4: lead.message?.slice(0, 200) || "—",
  };

  const results = [];
  for (const phone of phones) {
    try {
      results.push(
        await sendWhatsAppMessage({
          to: phone,
          inquiryId: lead.id,
          templateKey: "admin_notification",
          wid: env.whatsapp.defaultTextWid,
          bodyValues,
        })
      );
    } catch (err) {
      results.push({ ok: false, error: err.message });
    }
  }
  return { ok: results.some((r) => r.ok), results };
};

export const sendAutoReply = async (lead) => {
  if (!env.whatsapp.sendCustomerAutoReply) {
    return { ok: false, skipped: true };
  }

  const first = lead.name.split(/\s+/)[0] || "there";
  return sendWhatsAppMessage({
    to: lead.phone,
    inquiryId: lead.id,
    templateKey: "customer_autoreply",
    wid: env.whatsapp.defaultTextWid,
    bodyValues: {
      1: first,
      2: env.siteName,
      3: env.companyPhone,
    },
  });
};

export const notifyLeadViaWhatsApp = async (lead) => {
  if (!env.authkey.enabled || !isWhatsAppConfigured()) {
    return { admin: { ok: false, skipped: true }, customer: { ok: false, skipped: true } };
  }

  if (!authkeyStatus.ready) {
    logger.whatsapp("[AUTHKEY] Offline — skipping WhatsApp (inquiry saved)");
    return {
      admin: { ok: false, skipped: true, reason: "offline" },
      customer: { ok: false, skipped: true },
    };
  }

  const admin = await sendInquiryNotification(lead);
  const customer = await sendAutoReply(lead);
  return { admin, customer };
};

export { parsePhoneForAuthkey };
export default sendWhatsAppMessage;
