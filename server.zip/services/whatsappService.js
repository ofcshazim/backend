import { env, isWapiConfigured } from "../config/env.js";
import {
  normalizeWhatsAppPhone,
  toWhatsAppChatId,
  validatePhoneNumber,
} from "../utils/sanitize.js";
import { logger } from "../utils/logger.js";
import { enqueueWhatsApp } from "./whatsappQueue.service.js";
import { getWhatsAppTemplate } from "../templates/whatsapp/messages.js";

export const wapiStatus = {
  ready: false,
  lastError: null,
  verifiedAt: null,
};

const resolveWaApiBase = () => {
  let base = (env.whatsapp.wapi.baseUrl || "https://waapi.app/api").replace(/\/$/, "");
  if (base.includes("wapi.app") && !base.includes("waapi.app")) {
    base = base.replace("wapi.app", "waapi.app");
  }
  return base;
};

const buildSendUrl = () => {
  const base = resolveWaApiBase();
  const instanceId = env.whatsapp.wapi.instanceId;
  if (base.includes("/v1/instances")) {
    return `${base}/${instanceId}/client/action/send-message`;
  }
  return `${base}/v1/instances/${instanceId}/client/action/send-message`;
};

const buildStatusUrl = () => {
  const base = resolveWaApiBase();
  const instanceId = env.whatsapp.wapi.instanceId;
  return `${base}/v1/instances/${instanceId}`;
};

export const verifyWapiConnection = async () => {
  if (!env.wapiEnabled || env.whatsapp.provider === "none" || !env.whatsapp.provider) {
    wapiStatus.ready = false;
    wapiStatus.lastError = "WhatsApp disabled (WAPI_ENABLED=false or provider none)";
    logger.info("[WAPI] Skipped — disabled in configuration");
    return false;
  }

  if (!isWapiConfigured()) {
    wapiStatus.ready = false;
    wapiStatus.lastError = "Missing WAPI_API_KEY or WAPI_INSTANCE_ID";
    logger.warn("[WAPI] Invalid Credentials — set WAPI_API_KEY and WAPI_INSTANCE_ID");
    return false;
  }

  try {
    const res = await fetch(buildStatusUrl(), {
      method: "GET",
      headers: {
        accept: "application/json",
        authorization: `Bearer ${env.whatsapp.wapi.apiKey}`,
      },
      signal: AbortSignal.timeout(15000),
    });

    if (!res.ok) {
      const body = await res.text().catch(() => "");
      throw new Error(`HTTP ${res.status} ${body.slice(0, 120)}`);
    }

    wapiStatus.ready = true;
    wapiStatus.lastError = null;
    wapiStatus.verifiedAt = new Date().toISOString();
    logger.info("[WAPI] Connected", {
      instanceId: env.whatsapp.wapi.instanceId,
      base: resolveWaApiBase(),
    });
    return true;
  } catch (err) {
    wapiStatus.ready = false;
    wapiStatus.lastError = err.message;
    logger.warn("[WAPI] Request Failed — startup check", { error: err.message });
    return false;
  }
};

const wapiPost = async (chatId, message) => {
  const res = await fetch(buildSendUrl(), {
    method: "POST",
    headers: {
      accept: "application/json",
      "content-type": "application/json",
      authorization: `Bearer ${env.whatsapp.wapi.apiKey}`,
    },
    body: JSON.stringify({ chatId, message }),
    signal: AbortSignal.timeout(30000),
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const msg = data.message || data.error || data.detail || `HTTP ${res.status}`;
    throw new Error(msg);
  }
  return data;
};

export const sendWhatsAppMessage = async ({ to, message, inquiryId, templateKey }) => {
  if (!env.wapiEnabled || !isWapiConfigured()) {
    logger.whatsapp("[WAPI] Skipped — not configured or disabled");
    return { ok: false, skipped: true, reason: "WAPI not configured" };
  }

  const validation = validatePhoneNumber(to);
  if (!validation.valid) {
    throw new Error(validation.error || "Invalid phone number");
  }

  const phone = validation.normalized;
  const chatId = toWhatsAppChatId(phone);

  return enqueueWhatsApp({
    to: phone,
    message,
    inquiryId,
    templateKey,
    sendFn: () => wapiPost(chatId, message),
  });
};

export const sendTemplateMessage = async ({ to, templateKey, variables, inquiryId }) => {
  const message = getWhatsAppTemplate(templateKey, variables);
  if (!message) throw new Error(`Unknown WhatsApp template: ${templateKey}`);
  return sendWhatsAppMessage({ to, message, inquiryId, templateKey });
};

export const sendInquiryNotification = async (lead) => {
  const phones = env.whatsapp.adminPhones;
  if (!phones.length) {
    logger.warn("[WAPI] WHATSAPP_ADMIN_PHONES is empty");
    return { ok: false };
  }

  const message = getWhatsAppTemplate("admin_notification", {
    siteName: env.siteName,
    name: lead.name,
    phone: lead.phone,
    email: lead.email,
    project: lead.project || "—",
    message: lead.message,
    source: lead.source || "/",
  });

  const results = [];
  for (const phone of phones) {
    try {
      results.push(
        await sendWhatsAppMessage({
          to: phone,
          message,
          inquiryId: lead.id,
          templateKey: "admin_notification",
        })
      );
    } catch (err) {
      results.push({ ok: false, error: err.message });
    }
  }
  return { ok: results.some((r) => r.ok), results };
};

export const sendAutoReply = async (lead) => {
  if (!env.whatsapp.sendCustomerAutoReply) {
    return { ok: false, skipped: true };
  }

  const first = lead.name.split(/\s+/)[0] || "there";
  const message = getWhatsAppTemplate("customer_autoreply", {
    firstName: first,
    siteName: env.siteName,
    phone: env.companyPhone,
  });

  return sendWhatsAppMessage({
    to: lead.phone,
    message,
    inquiryId: lead.id,
    templateKey: "customer_autoreply",
  });
};

export const notifyLeadViaWhatsApp = async (lead) => {
  if (!env.wapiEnabled || env.whatsapp.provider !== "wapi" || !isWapiConfigured()) {
    return { admin: { ok: false, skipped: true }, customer: { ok: false, skipped: true } };
  }

  if (!wapiStatus.ready) {
    logger.whatsapp("[WAPI] Offline — skipping WhatsApp (inquiry saved, email sent)");
    return { admin: { ok: false, skipped: true, reason: "offline" }, customer: { ok: false, skipped: true } };
  }

  const admin = await sendInquiryNotification(lead);
  const customer = await sendAutoReply(lead);
  return { admin, customer };
};

// Re-export for backward compatibility
export { sendWhatsAppMessage as default };
