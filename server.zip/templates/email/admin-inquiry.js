import { wrapBrandedEmail, emailRow, escapeHtml } from "./layout.js";
import { env } from "../../config/env.js";

const formatTime = (iso) => {
  try {
    return new Intl.DateTimeFormat("en-PK", {
      dateStyle: "medium",
      timeStyle: "short",
      timeZone: "Asia/Karachi",
    }).format(new Date(iso));
  } catch {
    return iso;
  }
};

export const buildAdminInquiryEmail = (lead) => {
  const table = `
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;margin-top:16px;">
      ${emailRow("Name", lead.name)}
      ${emailRow("Email", lead.email)}
      ${emailRow("Phone", lead.phone)}
      ${emailRow("Budget", lead.budget)}
      ${emailRow("Timeline", lead.timeline)}
      ${emailRow("Project", lead.project)}
      ${emailRow("Source", lead.source)}
      ${emailRow("Submitted", formatTime(lead.createdAt))}
      ${emailRow("IP", lead.ip)}
    </table>
    <div style="margin-top:24px;padding:18px;background:#f4f8f6;border-radius:8px;border-left:4px solid #1f7a3e;">
      <p style="margin:0 0 8px;font-size:12px;font-weight:600;color:#5c6b66;text-transform:uppercase;letter-spacing:0.05em;">Message</p>
      <p style="margin:0;font-size:14px;color:#1a2e28;line-height:1.65;white-space:pre-wrap;">${escapeHtml(lead.message)}</p>
    </div>`;

  const html = wrapBrandedEmail({
    title: "New property inquiry",
    preheader: `${lead.name} submitted a contact form`,
    bodyHtml: `<p style="margin:0;font-size:15px;color:#1a2e28;line-height:1.6;">A new lead was received from your website.</p>${table}`,
    cta: {
      href: `mailto:${lead.email}`,
      label: "Reply to customer",
    },
  });

  const text = `New inquiry — ${lead.name}\n\n${lead.message}\n\nEmail: ${lead.email}\nPhone: ${lead.phone}`;

  return {
    subject: `[${env.siteName}] New inquiry: ${lead.name}`,
    html,
    text,
  };
};
