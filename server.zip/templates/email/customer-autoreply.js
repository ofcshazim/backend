import { wrapBrandedEmail, escapeHtml } from "./layout.js";
import { env } from "../../config/env.js";

export const buildCustomerAutoReplyEmail = (lead) => {
  const firstName = lead.name.split(/\s+/)[0] || lead.name;

  const bodyHtml = `
    <p style="margin:0 0 16px;font-size:15px;color:#1a2e28;line-height:1.65;">
      Hi ${escapeHtml(firstName)},
    </p>
    <p style="margin:0 0 16px;font-size:15px;color:#1a2e28;line-height:1.65;">
      Thank you for contacting <strong>${escapeHtml(env.siteName)}</strong>. We have received your inquiry about property options in Islamabad and Rawalpindi.
    </p>
    <p style="margin:0;font-size:15px;color:#1a2e28;line-height:1.65;">
      Our team typically responds within <strong>one business day</strong> with a practical shortlist and documentation guidance—no pressure to book on the first call.
    </p>`;

  const html = wrapBrandedEmail({
    title: "We received your inquiry",
    preheader: "We will respond within one business day",
    bodyHtml,
    cta: {
      href: `${env.siteUrl}/projects`,
      label: "Browse housing societies",
    },
  });

  const text = `Hi ${firstName},\n\nThank you for contacting ${env.siteName}. We received your inquiry and will respond within one business day.\n\n${env.companyPhone}`;

  return {
    subject: `We received your inquiry — ${env.siteName}`,
    html,
    text,
  };
};
