import { env } from "../../config/env.js";

export const escapeHtml = (value) =>
  String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");

const BRAND = {
  primary: "#1f7a3e",
  primaryDark: "#0f3d2e",
  primaryLight: "#39a887",
  accent: "#2d9b6a",
  text: "#1a2e28",
  muted: "#5c6b66",
  border: "#e4ebe8",
  bg: "#f4f8f6",
  gradient: "linear-gradient(135deg, #0f3d2e 0%, #1f7a3e 50%, #39a887 100%)",
};

export const getEmailLogoUrl = () => {
  const settingsLogo = env.logoUrl;
  if (settingsLogo && !settingsLogo.includes("og-default")) return settingsLogo;
  const site = (env.siteUrl || "https://checkinproperty.pk").replace(/\/$/, "");
  return `${site}/favicon.ico`;
};

export const emailRow = (label, value) => {
  if (!value) return "";
  return `
    <tr>
      <td style="padding:10px 0;color:${BRAND.muted};font-size:13px;width:130px;vertical-align:top;font-family:Arial,sans-serif;">${escapeHtml(label)}</td>
      <td style="padding:10px 0;color:${BRAND.text};font-size:14px;line-height:1.5;font-family:Arial,sans-serif;">${escapeHtml(value)}</td>
    </tr>`;
};

export const wrapBrandedEmail = ({ title, preheader, bodyHtml, cta }) => {
  const logoUrl = getEmailLogoUrl();
  const logoBlock = `<img src="${escapeHtml(logoUrl)}" alt="${escapeHtml(env.siteName)}" width="48" height="48" style="display:inline-block;vertical-align:middle;width:48px;height:48px;border-radius:8px;border:0;" />
      <span style="display:inline-block;vertical-align:middle;margin-left:12px;font-size:20px;font-weight:700;color:#ffffff;font-family:Georgia,serif;">${escapeHtml(env.siteName)}</span>`;

  const ctaBlock = cta
    ? `<table role="presentation" cellpadding="0" cellspacing="0" style="margin:28px 0 0;">
        <tr>
          <td style="border-radius:8px;background:${BRAND.primary};">
            <a href="${escapeHtml(cta.href)}" style="display:inline-block;padding:14px 32px;color:#ffffff;font-size:14px;font-weight:600;text-decoration:none;font-family:Arial,sans-serif;">${escapeHtml(cta.label)}</a>
          </td>
        </tr>
      </table>`
    : "";

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <title>${escapeHtml(title)}</title>
</head>
<body style="margin:0;padding:0;background:${BRAND.bg};font-family:Arial,Helvetica,sans-serif;-webkit-font-smoothing:antialiased;">
  <span style="display:none;max-height:0;overflow:hidden;mso-hide:all;">${escapeHtml(preheader)}</span>
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:${BRAND.bg};padding:32px 16px;">
    <tr>
      <td align="center">
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:600px;background:#ffffff;border-radius:12px;overflow:hidden;border:1px solid ${BRAND.border};box-shadow:0 4px 24px rgba(15,61,46,0.08);">
          <tr>
            <td style="background:${BRAND.gradient};padding:28px 32px;">
              ${logoBlock}
            </td>
          </tr>
          <tr>
            <td style="padding:32px;">
              <h1 style="margin:0 0 16px;font-size:24px;font-weight:600;color:${BRAND.text};font-family:Georgia,serif;line-height:1.3;">${escapeHtml(title)}</h1>
              ${bodyHtml}
              ${ctaBlock}
            </td>
          </tr>
          <tr>
            <td style="padding:24px 32px;background:${BRAND.bg};border-top:1px solid ${BRAND.border};">
              <p style="margin:0 0 8px;font-size:13px;color:${BRAND.muted};line-height:1.5;">
                <strong style="color:${BRAND.text};">${escapeHtml(env.siteName)}</strong><br />
                ${escapeHtml(env.companyAddress)}
              </p>
              <p style="margin:0;font-size:13px;color:${BRAND.muted};">
                <a href="tel:${escapeHtml(env.companyPhone.replace(/\s/g, ""))}" style="color:${BRAND.primary};text-decoration:none;">${escapeHtml(env.companyPhone)}</a>
                &nbsp;·&nbsp;
                <a href="mailto:${escapeHtml(env.companyEmail)}" style="color:${BRAND.primary};text-decoration:none;">${escapeHtml(env.companyEmail)}</a>
              </p>
              <p style="margin:12px 0 0;font-size:11px;color:#8a9a94;">
                © ${new Date().getFullYear()} ${escapeHtml(env.siteName)} · Islamabad property advisory
              </p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;
};

export { BRAND };
