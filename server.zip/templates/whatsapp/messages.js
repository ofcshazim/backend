const templates = {
  admin_notification: (v) =>
    [
      `🏠 *New inquiry — ${v.siteName}*`,
      ``,
      `*Name:* ${v.name}`,
      `*Phone:* ${v.phone}`,
      `*Email:* ${v.email}`,
      `*Project:* ${v.project}`,
      `*Source:* ${v.source}`,
      ``,
      v.message,
      ``,
      `_Reply from admin panel or call the client within one business day._`,
    ].join("\n"),

  customer_autoreply: (v) =>
    [
      `Hi ${v.firstName},`,
      ``,
      `Thank you for contacting *${v.siteName}*.`,
      `We received your inquiry and will respond within one business day.`,
      ``,
      `📞 ${v.phone}`,
      ``,
      `_Check In Property — Islamabad property advisory_`,
    ].join("\n"),

  inquiry_received: (v) =>
    `Hi ${v.name}, your inquiry about *${v.project}* has been received. Reference: ${v.inquiryId}`,

  lead_confirmation: (v) =>
    `✅ *Inquiry confirmed*\n\nHi ${v.name}, we logged your request for *${v.project}*. Our team will call you shortly.`,

  property_inquiry: (v) =>
    `Thank you for your interest in *${v.project}*. A ${v.siteName} advisor will share verified documentation options with you soon.`,

  contact_followup: (v) =>
    `Hi ${v.name}, following up on your message to ${v.siteName}. When is a good time for a quick call?`,
};

export const getWhatsAppTemplate = (key, vars = {}) => {
  const fn = templates[key];
  if (!fn) return null;
  return typeof fn === "function" ? fn(vars) : fn;
};

export const listWhatsAppTemplateKeys = () => Object.keys(templates);
