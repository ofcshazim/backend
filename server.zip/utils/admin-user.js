import { dbAdminUsers } from "../db/database.js";
import { env } from "../config/env.js";
import { ROLES } from "../constants/rbac.js";
import { resolveUserPermissions } from "../services/rbac.service.js";

/**
 * Resolve the full admin user record for RBAC (DB, env bootstrap, or session fallback).
 */
export const resolveAdminUser = (sessionOrReq) => {
  const session = sessionOrReq?.admin || sessionOrReq;
  if (!session?.email) return null;

  let user =
    (session.userId && dbAdminUsers.findById(session.userId)) ||
    dbAdminUsers.findByEmail(session.email);

  const envEmail = env.admin.email.trim().toLowerCase();

  if (!user && session.email?.toLowerCase() === envEmail) {
    user = {
      id: session.userId || 1,
      email: envEmail,
      name: session.name || env.admin.name,
      role_key: ROLES.SUPER_ADMIN,
      status: "active",
    };
  }

  if (!user && session.userId === 1) {
    user = {
      id: 1,
      email: session.email,
      name: session.name,
      role_key: ROLES.SUPER_ADMIN,
      status: "active",
    };
  }

  if (!user) {
    user = {
      id: session.userId,
      email: session.email,
      name: session.name,
      role_key: session.role_key || ROLES.SALES_AGENT,
      status: "active",
    };
  }

  return {
    ...user,
    permissions: resolveUserPermissions(user),
  };
};

export const toPublicAdminUser = (user) => ({
  id: user.id,
  email: user.email,
  name: user.name,
  role_key: user.role_key || ROLES.SUPER_ADMIN,
  permissions: user.permissions || resolveUserPermissions(user),
  avatar_url: user.avatar_url || "",
  status: user.status || "active",
});
