import { env, isSmtpConfigured, isWhatsAppConfigured } from "../config/env.js";
import { smtpStatus } from "./mail-transport.js";
import { wapiStatus } from "../services/whatsappService.js";

const API_VERSION = "3.0.0";

export const printStartupBanner = () => {
  const smtp = isSmtpConfigured() && smtpStatus.ready ? "CONNECTED" : "OFFLINE";
  const wapi =
    env.whatsapp.provider === "none"
      ? "DISABLED"
      : isWhatsAppConfigured() && wapiStatus.ready
        ? "CONNECTED"
        : "OFFLINE";

  const lines = [
    "================================",
    `CHECK IN PROPERTY API v${API_VERSION}`,
    "================================",
    `PORT: ${env.port}`,
    "STATUS: RUNNING",
    "ADMIN ROUTES: LOADED",
    `SMTP: ${smtp}`,
    `WAPI: ${wapi}`,
    "DATABASE: CONNECTED",
    "================================",
  ];

  console.log(lines.join("\n"));
  return API_VERSION;
};

export { API_VERSION };
