export const computeLeadScore = (lead) => {
  let score = 10;
  if (lead.email) score += 10;
  if (lead.phone?.length >= 10) score += 10;
  if (lead.budget) score += 15;
  if (lead.project) score += 15;
  if (lead.message?.length > 50) score += 10;

  const statusBoost = {
    new: 0,
    contacted: 10,
    interested: 25,
    site_visit: 35,
    negotiation: 45,
    converted: 50,
    closed: 20,
    lost: 0,
  };
  score += statusBoost[lead.status] || 0;
  if (lead.priority === "high") score += 10;
  if (lead.priority === "urgent") score += 20;
  return Math.min(100, score);
};
