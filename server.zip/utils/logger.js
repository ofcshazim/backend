import fs from "fs";
import path from "path";
import winston from "winston";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const LOG_DIR = path.join(__dirname, "..", "logs");

fs.mkdirSync(LOG_DIR, { recursive: true });

const lineFormat = winston.format.combine(
  winston.format.timestamp(),
  winston.format.errors({ stack: true }),
  winston.format.printf(({ timestamp, level, message, stack, ...meta }) => {
    const extra = Object.keys(meta).length ? ` ${JSON.stringify(meta)}` : "";
    return `[${timestamp}] [${level.toUpperCase()}] ${stack || message}${extra}`;
  })
);

const makeFileTransport = (filename, level) =>
  new winston.transports.File({
    filename: path.join(LOG_DIR, filename),
    level,
    maxsize: 5 * 1024 * 1024,
    maxFiles: 5,
    format: lineFormat,
  });

const winstonLogger = winston.createLogger({
  level: process.env.LOG_LEVEL || "info",
  format: lineFormat,
  transports: [
    new winston.transports.Console({ format: lineFormat }),
    makeFileTransport("error.log", "error"),
    makeFileTransport("access.log", "info"),
    makeFileTransport("security.log", "warn"),
    makeFileTransport("mail.log", "info"),
    makeFileTransport("whatsapp.log", "info"),
  ],
});

export const logger = {
  error: (message, meta) => winstonLogger.error(message, meta),
  warn: (message, meta) => winstonLogger.warn(message, meta),
  info: (message, meta) => winstonLogger.info(message, meta),
  debug: (message, meta) => winstonLogger.debug(message, meta),
  mail: (message, meta) => winstonLogger.info(message, { channel: "mail", ...meta }),
  whatsapp: (message, meta) => winstonLogger.info(message, { channel: "whatsapp", ...meta }),
  security: (message, meta) => winstonLogger.warn(message, { channel: "security", ...meta }),
  access: (message, meta) => winstonLogger.info(message, { channel: "access", ...meta }),
};

export const getLogDir = () => LOG_DIR;
