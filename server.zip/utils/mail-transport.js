import nodemailer from "nodemailer";
import { env, isSmtpConfigured } from "../config/env.js";
import { logger } from "./logger.js";
import { withRetry } from "./retry.js";

let transporter = null;

export const smtpStatus = {
  ready: false,
  lastError: null,
  verifiedAt: null,
};

const buildTransportOptions = () => ({
  host: env.smtp.host,
  port: env.smtp.port,
  secure: env.smtp.secure,
  auth: {
    user: env.smtp.user,
    pass: env.smtp.pass,
  },
  connectionTimeout: env.smtp.connectionTimeout,
  greetingTimeout: env.smtp.greetingTimeout,
  socketTimeout: env.smtp.socketTimeout,
  tls: {
    rejectUnauthorized: env.smtp.tlsRejectUnauthorized,
    minVersion: "TLSv1.2",
  },
  pool: true,
  maxConnections: 3,
  maxMessages: 50,
});

export const resetMailTransport = () => {
  if (transporter) {
    try {
      transporter.close();
    } catch {
      /* ignore */
    }
  }
  transporter = null;
  smtpStatus.ready = false;
};

export const getMailTransport = () => {
  if (!isSmtpConfigured()) {
    throw Object.assign(new Error("SMTP is not configured"), { code: "SMTP_NOT_CONFIGURED" });
  }
  if (!smtpStatus.ready) {
    throw Object.assign(
      new Error(smtpStatus.lastError || "SMTP is not ready"),
      { code: "SMTP_NOT_READY" }
    );
  }
  if (!transporter) {
    transporter = nodemailer.createTransport(buildTransportOptions());
  }
  return transporter;
};

export const verifySmtpConnection = async () => {
  if (!isSmtpConfigured()) {
    smtpStatus.ready = false;
    smtpStatus.lastError = "Missing SMTP_HOST, SMTP_USER, SMTP_PASS, SMTP_FROM, or CONTACT_RECEIVER";
    logger.warn("[MAIL] SMTP Failed — not configured");
    return false;
  }

  resetMailTransport();
  const testTransport = nodemailer.createTransport(buildTransportOptions());

  try {
    await withRetry(() => testTransport.verify(), {
      attempts: 3,
      delayMs: 1000,
      label: "SMTP verify",
    });
    transporter = testTransport;
    smtpStatus.ready = true;
    smtpStatus.lastError = null;
    smtpStatus.verifiedAt = new Date().toISOString();
    logger.info("[MAIL] SMTP Connected", {
      host: env.smtp.host,
      port: env.smtp.port,
      secure: env.smtp.secure,
      user: env.smtp.user,
    });
    return true;
  } catch (err) {
    smtpStatus.ready = false;
    smtpStatus.lastError = err.message;
    logger.error("[MAIL] SMTP Failed", {
      error: err.message,
      code: err.code,
      host: env.smtp.host,
      port: env.smtp.port,
    });
    try {
      testTransport.close();
    } catch {
      /* ignore */
    }
    return false;
  }
};
