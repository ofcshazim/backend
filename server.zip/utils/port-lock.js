import net from "net";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { logger } from "./logger.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const LOCK_FILE = path.join(__dirname, "..", "data", ".api.lock");

export const checkPortAvailable = (host, port) =>
  new Promise((resolve, reject) => {
    const tester = net
      .createServer()
      .once("error", (err) => reject(err))
      .once("listening", () => tester.close(() => resolve(true)))
      .listen(port, host);
  });

export const acquireProcessLock = (meta) => {
  fs.mkdirSync(path.dirname(LOCK_FILE), { recursive: true });

  if (fs.existsSync(LOCK_FILE)) {
    try {
      const existing = JSON.parse(fs.readFileSync(LOCK_FILE, "utf8"));
      if (existing.pid && existing.pid !== process.pid) {
        try {
          process.kill(existing.pid, 0);
          const err = new Error(
            `Another API instance may be running (PID ${existing.pid}, v${existing.version || "?"}). Stop it before starting v3.`
          );
          err.code = "EADDRINUSE";
          err.existing = existing;
          throw err;
        } catch (killErr) {
          if (killErr.code === "EADDRINUSE" || killErr.existing) throw killErr;
          logger.warn("[BOOT] Stale lock file — replacing", { oldPid: existing.pid });
        }
      }
    } catch (err) {
      if (err.existing || err.code === "EADDRINUSE") throw err;
    }
  }

  fs.writeFileSync(
    LOCK_FILE,
    JSON.stringify({ pid: process.pid, startedAt: new Date().toISOString(), ...meta }, null, 2)
  );

  const cleanup = () => {
    try {
      if (fs.existsSync(LOCK_FILE)) {
        const current = JSON.parse(fs.readFileSync(LOCK_FILE, "utf8"));
        if (current.pid === process.pid) fs.unlinkSync(LOCK_FILE);
      }
    } catch {
      /* ignore */
    }
  };

  process.on("exit", cleanup);
  return cleanup;
};

export const detectPortConflict = async (host, port) => {
  try {
    await checkPortAvailable(host, port);
    return { available: true };
  } catch (err) {
    return {
      available: false,
      error: err.code,
      message: `Port ${port} is already in use. Stop the old API process (often v2.0.0) in your hosting panel.`,
    };
  }
};
