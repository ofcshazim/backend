export const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

export const withRetry = async (fn, { attempts = 3, delayMs = 800, label = "operation" } = {}) => {
  let lastError;
  for (let i = 1; i <= attempts; i++) {
    try {
      return await fn();
    } catch (err) {
      lastError = err;
      if (i < attempts) {
        await sleep(delayMs * i);
      }
    }
  }
  lastError.message = `${label} failed after ${attempts} attempts: ${lastError.message}`;
  throw lastError;
};
