export const sanitizeText = (value, maxLength = 500) =>
  String(value ?? "")
    .replace(/[\u0000-\u001F\u007F]/g, "")
    .trim()
    .slice(0, maxLength);

export const sanitizeEmail = (value) => sanitizeText(value, 254).toLowerCase();

export const sanitizePhone = (value) => sanitizeText(value, 30).replace(/[^\d\s+\-()]/g, "");

/** Pakistan-focused normalization: 03001234567 → 923001234567 */
export const normalizeWhatsAppPhone = (phone) => {
  let digits = String(phone || "").replace(/\D/g, "");
  if (!digits) return "";

  if (digits.startsWith("00")) digits = digits.slice(2);
  if (digits.startsWith("92") && digits.length >= 12) return digits;
  if (digits.startsWith("0") && digits.length === 11) return `92${digits.slice(1)}`;
  if (digits.length === 10 && digits.startsWith("3")) return `92${digits}`;

  return digits;
};

export const toWhatsAppChatId = (normalizedPhone) => {
  const digits = normalizeWhatsAppPhone(normalizedPhone);
  if (!digits) return "";
  return `${digits}@c.us`;
};

export const validatePhoneNumber = (phone) => {
  const normalized = normalizeWhatsAppPhone(phone);
  if (!normalized) {
    return { valid: false, error: "Phone number is required." };
  }
  if (normalized.length < 10 || normalized.length > 15) {
    return { valid: false, error: "Phone number length is invalid." };
  }
  if (!/^92\d{10}$/.test(normalized) && !/^\d{10,15}$/.test(normalized)) {
    return { valid: false, error: "Phone number format is invalid." };
  }
  return { valid: true, normalized };
};
