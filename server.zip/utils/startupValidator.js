import { env, isSmtpConfigured, isAuthkeyConfigured, isWhatsAppConfigured } from "../config/env.js";
import { logger } from "./logger.js";

const errors = [];
const warnings = [];

const requireField = (label, value) => {
  if (!value || String(value).trim() === "") errors.push(`${label} is required`);
};

export const validateStartup = () => {
  errors.length = 0;
  warnings.length = 0;

  requireField("ADMIN_EMAIL", env.admin.email);
  requireField("ADMIN_PASSWORD", env.admin.password);

  if (!isSmtpConfigured()) {
    errors.push("SMTP is not fully configured (host, user, pass, from, CONTACT_RECEIVER)");
  }

  if (env.authkey.enabled && !isAuthkeyConfigured()) {
    warnings.push("AUTHKEY_AUTH_KEY missing — WhatsApp will stay offline until configured");
  }

  if (!env.authkey.enabled) {
    warnings.push("WhatsApp disabled — set WHATSAPP_ENABLED=true and AUTHKEY_AUTH_KEY");
  }

  if (env.port < 1 || env.port > 65535) {
    errors.push(`Invalid PORT: ${env.port}`);
  }

  if (env.host !== "0.0.0.0") {
    warnings.push(`HOST is ${env.host} — production should bind 0.0.0.0`);
  }

  if (errors.length) {
    for (const e of errors) logger.error("[BOOT] Validation failed", { error: e });
    throw new Error(`Startup validation failed:\n- ${errors.join("\n- ")}`);
  }

  for (const w of warnings) logger.warn("[BOOT] Validation warning", { warning: w });

  return { ok: true, warnings };
};
