import { env, isSmtpConfigured, isWapiConfigured, isWhatsAppConfigured } from "../config/env.js";
import { logger } from "./logger.js";

const errors = [];
const warnings = [];

const requireField = (label, value) => {
  if (!value || String(value).trim() === "") errors.push(`${label} is required`);
};

export const validateStartup = () => {
  errors.length = 0;
  warnings.length = 0;

  requireField("ADMIN_EMAIL", env.admin.email);
  requireField("ADMIN_PASSWORD", env.admin.password);

  if (!isSmtpConfigured()) {
    errors.push("SMTP is not fully configured (host, user, pass, from, CONTACT_RECEIVER)");
  }

  if (env.wapiEnabled && env.whatsapp.provider === "wapi" && isWhatsAppConfigured() && !isWapiConfigured()) {
    warnings.push("WAPI enabled but WAPI_API_KEY or WAPI_INSTANCE_ID missing — WhatsApp will stay offline");
  }

  if (!env.wapiEnabled) {
    warnings.push("WAPI_ENABLED=false — WhatsApp messaging disabled (email-only mode)");
  }

  if (env.port < 1 || env.port > 65535) {
    errors.push(`Invalid PORT: ${env.port}`);
  }

  if (errors.length) {
    for (const e of errors) logger.error("[BOOT] Validation failed", { error: e });
    throw new Error(`Startup validation failed:\n- ${errors.join("\n- ")}`);
  }

  for (const w of warnings) logger.warn("[BOOT] Validation warning", { warning: w });

  return { ok: true, warnings };
};
