const bootedAt = Date.now();

export const getUptimeSeconds = () => Math.floor((Date.now() - bootedAt) / 1000);
