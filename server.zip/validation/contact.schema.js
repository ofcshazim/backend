import { z } from "zod";

export const contactBodySchema = z.object({
  name: z.string().trim().min(2).max(120),
  phone: z
    .string()
    .trim()
    .min(7)
    .max(30)
    .regex(/^[\d\s+\-()]+$/),
  email: z.string().trim().email().max(254),
  budget: z.string().trim().max(80).optional().default(""),
  project: z.string().trim().max(120).optional().default(""),
  timeline: z.string().trim().max(80).optional().default(""),
  message: z.string().trim().min(10).max(2000),
  source: z.string().trim().max(120).optional().default("website"),
  city: z.string().trim().max(80).optional().default("Islamabad"),
  website: z.string().max(0).optional(),
});
